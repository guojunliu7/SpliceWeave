# SpliceWeave

## 长短读联合差异剪接（0.1.6，2026-11-24）

新增 `spliceweave diff-splicing-joint`：统一两分支事件目录，在生物学样本层面同步置换长短读标签，分别报告组间变化、双平台同方向支持与平台交互/冲突。支持 BAM 或计数表、独立组或配对设计，保留低覆盖及 IR 不可观测状态。默认 BY 多重校正；不把读段数量当生物学重复。

```bash
spliceweave diff-splicing-joint --samples samples.tsv \
  --short-counts short.tsv --long-counts long.tsv --catalog events.tsv \
  --reference control --comparison treatment --out-dir output/joint_differential
```

公式、BAM 输入、样本设计及输出列见 [联合差异剪接说明](src/spliceweave/JOINT_DIFFERENTIAL.md)。已运行正式模拟统计基准与 NT/PF 六靶点原始 BAM 审计；该模块尚未取得独立真实差异真值验证，不能声称优于其他差异剪接工具。当前固定目录事件召回不等于从头结构发现召回。

## 联合定量（0.1.5，2026-11-24）

正式新增 `spliceweave quantify`，采用六文库最新比较的 **geometry_MAP_joint**：原生短读片段几何概率、有效采样暴露量、按基因留出的片段长度背景、短读 MAP 初始化及长短读联合似然。无需调用竞争工具；不使用混合比例真值或方向门控。

```bash
python -m pip install ".[quantification]"
spliceweave quantify --gtf transcripts.gtf --short-bam short.bam \
  --long-bam long.bam --sample sample1 --out-dir output/quantification
```

输出 `abundance.tsv`（联合 TPM、短读对照 TPM 和输入支持标记）、可重放的 `geometry.json.gz` 和收敛/输入哈希审计 `summary.json`。模型公式、输入限制与复现命令见 [联合定量说明](src/spliceweave/QUANTIFICATION.md)。当前完整目录比较支持与 MPAQT 接近的精度，不证明显著超过 MPAQT 或联合相对短读存在大幅增益。

## 完整链重建与证据仲裁（0.1.4，2026-11-24）

`spliceweave assemble-chains` 已纳入正式包，默认采用本轮定稿的 **joint**：先保留原始链与校正链，再按校正目标内的原始链竞争、完美侧翼见证和整链方向约束作决策。旧 `evidence_replay` 可通过 `--mode baseline` 明确复现。`correct` 仍保持 SW unguarded 的坐标校正行为。

```bash
spliceweave assemble-chains --long-bam original.long.bam --short-bam short.bam \
  --reference genome.fa --gtf inference.gtf \
  --corrected-bed corrected/corrected.bed --out-dir output/chains
```

安装用 `python -m pip install '.[assembly]'`。方法、核心公式、输入契约和逐读段审计输出见 [完整链模块说明](src/spliceweave/ASSEMBLY.md)。当前指定手稿为 `07Manuscript/正式保留的结果/Manuscript_20261124_SpliceWeave.docx`。0.1.4 发布核对在项目 `Output/SpliceWeave_release_0.1.4_20261124`；原始研究结果在 `Output/SpliceWeave_chain_arbitration_v2_20261123`。

本轮精确整链指标不代表端点准确性、来源判别或丰度全面提升；旧模块结果保留原始运行身份。默认规则不按数据集改变。

## 原生剪接位点校正：`correct`（0.1.3，2026-11-23）

已选定 **SW unguarded** 作为 `correct` 的唯一正式实现。独立 Python 命令读取 BED12 和 GTF／短读剪接连接证据，保护可信原位、检查完整连接配对，并逐连接记录校正或待判。全读段输出保留未解决坐标；完全受可信连接支持的输出单列。无需调用 FLAIR 或 bedtools。安装后运行：

```bash
spliceweave correct --query reads.bed --gtf annotation.gtf \
  --junction-tab sample.SJ.out.tab --out-dir output/correct_new
```

输入要求、公式、文件含义与适用边界见[correct 使用说明](src/spliceweave/CORRECT.md)。guarded 已从运行入口移除，不再需要也不再接受 `--original-support`。可信原位保护、供受体成对选择、歧义待判和几何检查继续保留。历史冻结模型和其他命令的行为保持可复现。

这次是默认实现的选择与发布，不是新增精度证明。unguarded 在小鼠来源测试中仍有 3,141 次“正确改错”，不能仅根据目录一致性宣称全面领先。完整比较（含退役 guarded）保存在项目根目录 `Output/SpliceWeave_FLAIR_source_study_20261123`；0.1.3 发布与输出等价核对见 `Output/SpliceWeave_correct_release_0.1.3_20261123`。当时对应手稿为 `07Manuscript/SpliceWeave_正式稿_20261123/Manuscript_20261123_SW_unguarded.docx`，已同步当前模块、6 个可编辑公式、当前校正比较及其适用限制。

## 两组差异可变剪接

在 Python 3.10 或以上的环境中，从本目录运行 `python -m pip install .`，然后使用 `spliceweave diff-splicing`。若要从 BAM 计数，安装 `python -m pip install '.[bam]'`。差异分析可读取任意物种、样本名和条件名，分支顺序在所有样本中须一致。最小示例、BAM 工作流、配对设计与结果列见[差异剪接使用说明](src/spliceweave/DIFFERENTIAL.md)。

~~~bash
spliceweave diff-splicing --samples samples.tsv --counts branch_counts.tsv \
  --reference control --comparison treatment --out-dir analysis
~~~

The portable demo runs the Stage 3 structural candidate generator. This directory also includes the JointSpliceCal development scripts and research workflows. It reads a source GTF, observed long-read intron chains, short- and long-read junction support, and a JSON configuration. It writes a candidate table and a summary. The bundled input is synthetic and is only for checking the command and file formats.

## 2026 年 11 月 11 日实现与公式

[SpliceWeave 理论算法（可编辑 Word 公式）](../../02算法设计/SpliceWeave_理论算法20261111.docx) 与当前分子证据晋级版对应。读段校正与混合组装是独立入口。

| 理论章节 | 代码入口 | 可复核的输出 |
|---|---|---|
| 当前读段坐标校正 | `src/spliceweave/correct.py` 的 `correct_read`、`run_correct` | `junction_decisions.tsv.gz` 与 `read_status.tsv` |
| 历史序列／DEOU 提案校正 | `scripts/correct_junctions_integrated.py` 的 `propose`、`adjudicate`（历史复现入口） | 历史 `read_decisions.tsv.gz`，不作为当前 correct 成绩 |
| 候选路径与评分 | `src/branch_paths.py` 的 `PathGraph.evaluate`、`extensions` | `path_decisions.tsv` 的 score 与长读、短读对支持 |
| 分子证据晋级与嵌套短链 | `src/branch_paths.py` 的 `decide_paths`、`classify_nested` | 状态、缺证边序号、父链与独立端点 |
| 长短读联合丰度估计 | `src/mixed_assembly.py` 的 `equivalence_classes`、`fit_abundance` | `assembled_chains.tsv` 的 LR_assigned、SR_assigned、TPM |

[逐重复与并集评测](../../04RawData/投稿前验证/20261111_分叉分子证据晋级/整链评测.tsv)及[运行版本校验值](../../04RawData/投稿前验证/20261111_分叉分子证据晋级/算法SHA256.txt)对应同一实现。模块回归测试可在本目录执行 `python3 -m unittest discover -s tests`。

## Requirements

- Python 3.10 or newer. The candidate generator uses only the Python standard library.
- No reference genome, BAM, or external software is needed for the bundled demo.

## Run the demo

From the repository root:

```bash
bash run_demo.sh
python3 tests/test_candidate_relations.py
python3 tests/test_end_to_end.py
```

The demo writes `output/demo/candidate_catalog_v2.tsv` and `output/demo/candidate_catalog_v2.summary.json`. The one synthetic alternative donor candidate should have `diagnostic_action=review` and `formal_GTF_edit=False`.

For your own inputs, copy `config/candidate_generator.example.json`, adjust the thresholds for your study, and run:

```bash
python3 src/generate_stage3_candidate_catalog_v2.py \
  --source-gtf SOURCE.gtf \
  --observed-chains OBSERVED.tsv \
  --junction-support SUPPORT.tsv \
  --config CONFIG.json \
  --out-dir output/my_run
```

The small files in `tests/data/` show the required TSV headers. `--truth-gtf` is optional and is used only for a post-generation diagnostic join. Do not use truth labels to construct the observed input.

## Interpretation

`review` marks a candidate meeting the configured support and endpoint checks. It is not an accepted transcript, a calibrated probability, or a decision to edit the GTF. The structural rank field is a proxy, not a numerical read-compatibility matrix rank. No differential splicing significance is computed here.

The candidate generator is adapted from the local JointSpliceCal Stage 3 development script. The original Stage 3 release evaluated additional IR and quantification modules; the imported development scripts are available separately from the portable demo.

## Data and upload policy

Only the synthetic files in `tests/data/` belong in this repository. Real FASTQ/BAM/CRAM files, reference genomes, run outputs, server path manifests, and credentials are excluded by `.gitignore` or omitted from the package.

## JointSpliceCal 脚本目录

- `scripts/`、`tests/`、`config/` 保留开发树中的脚本、测试和配置。文件来源和 SHA-256 见 `migration_manifest.tsv`。
- `04RawData/` 保留阶段 1–4、PRJNA889675 和投稿前验证的脚本相对目录。实验数据、参考基因组、BAM 和服务器软件环境需按对应工作流提供。部分历史驱动使用原服务器绝对路径或以实验目录为工作目录，运行前核对输入和输出位置。
- 当前候选生成入口为 `src/generate_stage3_candidate_catalog_v2.py`。

## JointSpliceCal 逐读段串联校正（2026-11-11）

`scripts/correct_junctions_integrated.py` 先由长读补救规则提出 A/B 候选，再由精度优先规则决定是否执行。输入为同一样本的两个 TSV（支持 gzip），用 `gene` 和 `rid` 配对。运行此入口需要 Python 和 Biopython。以下命令在 SpliceWeave 目录执行，使用本项目已冻结的人源留出样本作为示例。输出目录须为新目录。

```bash
inputs="../../04RawData/投稿前验证/20261111_串联校正/inputs/day13b_precision_20261111"
python3 scripts/correct_junctions_integrated.py \
  --features "$inputs/locked.human.features.gz" \
  --evidence "$inputs/test.human.cohort.gz" \
  --output output/human_integrated_calls
```

- 特征表包含原位 C、候选 A/B、两遍比对提议、短读支持、相位及局部序列。已有 BAM 工作流可用 `scripts/extract_other_molecule_evidence.py` 从索引 BAM 和参考 FASTA 提取证据表（依赖 pysam）。证据计数排除待判分子自身，坐标为 0-based 半开内含子区间。
- `read_decisions.tsv.gz` 逐条记录原始、候选、最终坐标和判定原因。`apply` 执行校正，`review` 暂缓并保留候选，`retain` 表示没有校正提议。
- `branch_support.tsv` 汇总本模块对 A/B 的增量支持。仅 `apply` 计入 A/B，`review` 和 `retain` 均单列为未解决。计算 PSI 还需与原本归入 A/B 的读段按样本和读名去重合并。

官方 ESPRESSO 两种设置的逐读段配对评分脚本位于 `04RawData/投稿前验证/20261111_串联校正/compare_espresso.py`。复现实测对照需要原验证目录中的冻结预测、标签和串联输出。

## Python 长短读混合组装

`src/assemble_mixed.py` 是 SpliceWeave 自己的组装入口，`src/mixed_assembly.py` 实现剪接路径构造、证据分配和定量。从同一样本、同一参考上排好坐标序的短读和长读 BAM 开始运行。两个 BAM 的参考序列字典及顺序须一致。Python 3.10+，pysam 负责 BAM 文件读取，NumPy 和 SciPy 提供数组与稀疏矩阵运算。

```bash
python3 -m pip install pysam numpy scipy
python3 src/assemble_mixed.py --short-bam short.sorted.bam \
  --long-bam long.sorted.bam --fragment-length 200 --threads 4 \
  --out-dir output/python_mixed_sample
python3 tests/test_python_mixed_assembly.py
```

组装按基因组上连续重叠的比对区间处理。默认使用 MAPQ ≥20 的主比对；各内含子两侧各需 ≥8 个连续比对碱基。使用 XS 或按反向比对标志换算的 ts 确定转录链。单条长读的有序内含子链保留其分子连接信息；当前按文库内的 read group 和读名识别长读，请使用已去重的分子 BAM。短读配对按片段对每个连接计一次。缺乏方向标签的片段可用于与现有模型的相容性分配。

**分叉选路和局部链晋级（Python）。** 在每个比对区间按链向构建内含子图。两个内含子在同一条比对上连续出现、且有至少两个分子或片段支持时，才加入延伸边。配对短读两端间的未测区间可以约束路线，但不能凭空建边。局部区间借助共享的内含子和实测边建立联系，未使用参考 gene_id 划分重叠基因。旧版的长读整链、唯一重叠、短读无分叉路径和单外显子模型仍提供起始候选。新增的来源标记为 `graph_extension`。

每次汇合按整条候选前缀保留最多 `--beam-width` 条延伸（默认 16，最小 2）。在图的终点与起始候选汇总。一条长读只要在其比对范围内与候选相容，即可给覆盖到的相邻连接贡献支持。配对证据要求至少一端观察到有方向的剪接、两端均与路径相容且整个片段跨过至少两个连接。未剪接的短读对仍可进入后续定量。

对有序路径，以每个连接的长读数加短读片段数为 D，每对相邻连接上的相容长读数与相容短读对数分别为 L 和 P。排序分数是三个分量之和：连接上的 mean(log(1+D))、相邻连接上的 mean(log(1+L)) 和 mean(log(1+P))。空分量记零。分数仅用于排序；若候选数未达到上限，所有候选均进入结构判定。多个分叉的选择按基因组顺序排列，相邻两个选择之间须有同一分子或同一短读对实际观测到两处所选连接。缺少这种连接证据的推断链标为 `unphased_branches`。多处分叉仍依赖相邻选择的分段连接，不能保证整个转录本被单分子覆盖。

图搜索生成的 `graph_extension` 在进入 GTF 前还需通过分子证据核查。对路径上每一对相邻内含子，要求至少一条相容长读直接观察到两者，或至少两个相容的双端短读片段分别观察到两者。对有分叉的边（多入边或多出边），要求有长读直接观察到所选边。整条延伸至少有一对相邻内含子获长读直接支持。此前远端选择之间的相位检查继续执行。单纯跨过两个位点的插入片段只能贡献排序证据。失败的候选写入 `path_decisions.tsv`，状态为 `extension_needs_molecular_support`，并列出缺少直接支持的边与缺少长读的分叉边（1 起始；第 i 项指相邻的第 i、i+1 个内含子）。该判定在短链归类之前执行，待判长链不能压下已有短链。

**双端短读引导的局部延伸。** 推荐用 `--paired-review` 查看新增候选及证据。此模式仅扩展审计表，新增路线不能压下已有短链，GTF 与 TPM 沿用原规则。`--paired-extension` 是单独的晋级试验模式，二者互斥。两种模式均可在同一样本内用两个或以上片段提出缺边候选。要求两端各有同链向的剪接坐标，观察到的外显子区间与拼接相容。程序保留原候选，再在有短读对约束的两个节点之间搜索直接连接及原候选中已见的中间路线；候选前缀、后缀和路线的保留数受搜索宽度限制。对新提出的直接边，至少两个双端片段须与整条候选相容，并须有一条相容的单次比对真正连续观察到这两个内含子；未满足时记 `mate_gap_adjacency_unresolved`。通过这一关后仍需满足原有的相位、分子证据和嵌套端点规则。启用后审计表附加列记录两锚点在链中的序号、相容片段数和是否有连续观测到该锚点对的比对。更多候选会影响待判表规模；默认运行沿用已评测的分子证据晋级版。

在 HCC827 的三个重复并集中，局部延伸新增 33 条真值链候选和 4,244 条目录外候选，正式 GTF 的真链数仍为 33。H1 直接晋级试验的整链 F1 从 0.672 降至 0.603，两个原本命中的短链因更长父链而转入待判。按运行模式分别核对[候选和正式 GTF](../../04RawData/投稿前验证/20261111_配对局部延伸/候选与正式GTF评测.tsv)及[仅复核模式的一致性](../../04RawData/投稿前验证/20261111_配对局部延伸/仅复核模式一致性.tsv)。

对于同链向、被已通过结构判定的更长链连续包含的有剪接短链，记录 `fragment_or_short_isoform`。按缺失侧检查独立端点，内部片段需要两端证据，负链按转录方向交换 5′/3′。匹配默认容差为 20 nt，证据必须在候选的相应末端外显子方向上，并能与延伸父链的同侧端点区分。通过者记为 `end_supported_short_isoform`。没有提供独立证据时，待判短链保存在审计表中。单外显子和方向未知的模型沿用原有规则。该步骤识别的是完整内含子链候选，普通比对的首尾仍是推定边界。

独立端点文件通过 `--end-evidence ends.tsv` 指定，表头为制表符分隔的 `contig strand end_type position_1based source`。端型为 `5p` 或 `3p`，坐标为 1-based 的末端碱基，来源列记录独立实验或数据轨道。用 `--end-tolerance` 调整窗口。评测时将结构真值与端点输入隔离。

**联合定量。** 对长读和短读片段分别生成相容转录本集合；一对短读的两个比对端必须与同一模型相容。在 E 步，同一集合中的候选按相对分子丰度分得读段，在 M 步按两种文库各自的采样量更新丰度。长读使用每分子一次的暴露量；短读使用有效长度 `max(1, 转录本外显子长度 − 平均插入片段长度 + 1)`。`--fragment-length` 应使用实验文库的平均插入片段长度。可分配读段的总质量在两文库分别守恒，TPM 在有可分配质量时对全样本归一至一百万。模型未校准逆转录截断、启动位点或3′偏好；标准品上的结构评测与定量精度评测是不同终点。

**输出。** `path_decisions.tsv` 记录进入结构判定的路径、分数、长短读支持、最弱分叉连接支持、包含它的长链、所需端型和命中的独立证据；超过搜索宽度而被剪枝的前缀不在表内。仅通过判定的候选进入 GTF 和联合定量。 `mixed.gtf` 含 transcript/exon、稳定的局部模型 ID、TPM 和来源。`assembled_chains.tsv` 保留原有列，并增加本样本观测到的整链长读数、最弱连接的短读片段数、拼接见证数、两库分配量和 TPM。可选 `--observed-chains` 将原项目的外部整链/重复数附到结果中。GTF 和 TSV 内含子使用 1-based 闭区间。`--threads` 用于 BAM 解压；输出使用新目录，全部写好后才发布。

`third_party/stringtie-3.0.3` 与 `scripts/build_stringtie.sh` 保留为历史对照，Python 组装入口直接在上述 Python 依赖下运行。独立 StringTie3 的实测数据继续按原方法名称记录。

### 同锚点的片段长度评分

`src/rank_mate_routes.py` 读取一个文库的坐标排序短读 BAM 和配套的双端路线审计表，单独输出 `route_ranks.tsv` 与 `calibration.tsv`。示例：

```bash
python3 src/rank_mate_routes.py --short-bam short.sorted.bam \
  --path-decisions output/paired_review/path_decisions.tsv --out-dir output/length_review
```

每对锚点按精确内含子坐标和链向分组，去重两个锚点间的有序路线。对同一批相容片段，从基因组跨度减去两端实际观察到的内含子及候选中间内含子的长度，得到转录本坐标上的片段长度。校准使用本库中已枚举路线唯一、且有长读整链候选包含该局部路线的片段。每次评分扣除目标重叠基因组区间的全部训练计数，至少需要其他两个区间、100 个训练片段及两个可比测试片段。长度按 10 nt 分箱，邻域平滑权重为 1、2、3、2、1；对平滑计数加 0.5 后取自然对数，再按片段求平均。列 mean_log_density 是省略公共归一化常数的长度分数，仅在同一组比较；同长路线可能并列。该模块只对已枚举出竞争路线的局部锚点对排序，独立于 GTF 和 TPM 输出。

[三个数据集的冻结评测](../../04RawData/投稿前验证/20261112_竞争路径片段长度评分/排名对比.tsv)使用标准品真值做事后标注。分母为存在真路线和目录外路线且可评分的样本－锚点组，并列第一按其中真路线的比例计分。相同锚点在不同重复中可多次计入。

### 单条直接连接的长度相容性

`src/check_single_route.py` 的输入参数与上节相同。输出新目录中的 `adjacencies.tsv`。每行对应同一文库、链向和一对内含子锚点。程序检查“中间序列全部保留为外显子”这一种局部解释，即使候选目录只有一条接法也可以计算。它只产生诊断表。

参考分布使用本库中只有一种已枚举局部解释、且有观测长链支持该解释的片段，扣除受检锚点所属重叠区域的全部计数。至少需要其他 2 个区域和 100 个校准片段。把测试片段按直接连接投影到转录本坐标，比较其长度与参考分布第 2.5 至 97.5 百分位。至少 5 个可用片段时，≥80% 在区间内标为 length_consistent，≥80% 在区间外标为 length_conflict，其余标为 mixed_lengths。样本量或校准不足单列。这些是固定的描述性规则，不代表结构概率或显著性检验。

[匹配对照评测](../../04RawData/投稿前验证/20261112_单条连接长度检验/匹配对照汇总.tsv)按文库、重复匹配，双端片段数与锚点间基因组距离分别相差至多两倍，一对一不放回。single 仅使用原目录中确实只有直接接法的锚点；masked_skip_challenge 用原本有其他路线的错误跳接单独构成压力测试，结果应分别解释。三个数据集的压力测试中，163 个真实阳性有 67 个出现长度冲突。此规则可用于安排逐连接复核，当前不据此晋级或剔除正式模型。[31 条候选逐重复结果](../../04RawData/投稿前验证/20261112_单条连接长度检验/31条链逐重复.tsv)中的链级状态取待核缺边中最保守的结果。

### 固定转录本目录定量

`python3 src/quantify_fixed.py --gtf reference.gtf --long-bam pacbio.bam --short-bam illumina.bam --out fixed_quant` 直接使用给定外显子和转录本 ID。两个坐标排序 BAM 应具有相同参考字典。可选 `--fragment-length` 指定短读平均插入片段长度，默认 200 nt。同一次运行在同一目录下分别估计长读、短读和联合 TPM，并记录联合分配量；两库各自基因总量均大于零时才计算基因内等权平均。审计 JSON 记录各库可用与分配数、停止时的丰度变化、迭代数及收敛情况。


### 事件保真位点复核（20261123，实验性入口）

新增 `spliceweave review-junctions`，支持可变候选、原位点公平竞争、其他原始分子的局部相位证据、饱和支持及有界跨平台补救。输出逐读段 KEEP / APPLY / REVIEW 和理由，不修改 BAM/GTF 或定量结果。开发用平衡配置见 `configs/event_preserving_balanced_20261123.json`；接口、公式、证据约束和已知限制见 [CORRECTION.md](src/spliceweave/CORRECTION.md)。人鼠 240 个基因已经用于本轮研发，不能继续作为独立测试。

## 2026-11-25 release 0.1.7

The selected joint molecular estimator is retained. `diff-splicing-counts` now
exposes the frozen replicate-aware observed-fragment beta-binomial bootstrap
model as a separate command, with gene-excluded dispersion priors, explicit
untested states and input hashes. See `src/spliceweave/COUNT_DIFFERENTIAL.md`.
It does not attach count P values to molecular DeltaPSI. The existing
`diff-splicing-joint` platform-conflict test remains available. Eleven-tool
benchmark results use native event, transcript, exon and cluster endpoints
separately; they do not establish an overall eleven-tool winner.

## 0.1.8 可选的差异剪接覆盖补救

运行 `diff-splicing-counts` 时，用户可加 `--coverage-rescue event_usage.tsv` 启用丰度补救。省略参数时使用标准计数检验。输入为同一事件目录和样本的 `event-psi` 输出。新增的 `coverage_rescue.tsv` 提供逐事件证据来源和探索性候选排序。[安装与使用示例](src/spliceweave/COUNT_DIFFERENTIAL.md#optional-coverage-rescue)
