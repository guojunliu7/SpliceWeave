"""Run with the frozen wheel installed. Compare all four outputs per condition."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from importlib.metadata import version

base=Path(__file__).resolve().parent
if version("SpliceWeave")!="0.1.8":
    raise RuntimeError("Install the supplied SpliceWeave 0.1.8 wheel before replay.")
with tempfile.TemporaryDirectory() as tmp:
    for scene in ("full3","n2","depth25"):
        data=base/scene
        dest=Path(tmp)/scene
        cmd=[sys.executable,"-I","-m","spliceweave","diff-splicing-counts",
             "--samples",str(data/"samples.tsv"),"--counts",str(data/"short_counts.tsv"),
             "--catalog",str(base/"canonical_events.tsv"),"--reference","Mix_A","--comparison","Mix_B",
             "--coverage-rescue",str(data/"event_usage.tsv"),"--seed-prefix","majiq_review_20261125_"+scene,
             "--out-dir",str(dest)]
        subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
        expected=json.loads((data/"expected.json").read_text())
        actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir()}
        if actual!=expected:raise RuntimeError(f"{scene}: output digest mismatch: {actual}")
        print(scene, "all four archived outputs reproduced")
