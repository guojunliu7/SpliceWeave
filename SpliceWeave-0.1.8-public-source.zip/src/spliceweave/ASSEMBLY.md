# Complete chain reconstruction with evidence arbitration

Release 0.1.4 adds `assemble-chains` with `joint` as the default policy (`sw-chain-family-arbitration-v2`). The `correct` command keeps the selected SW unguarded policy and its outputs unchanged. Assembly retains both original alignment geometry and proposed correction; it does not rewrite BAM sequences or CIGARs.

Install `python -m pip install '.[assembly]'` from the repository. Then:

```bash
spliceweave correct --query original.bed --gtf inference.gtf \
  --junction-tab sample.SJ.out.tab --out-dir corrected
spliceweave assemble-chains --long-bam original.long.bam \
  --short-bam short.bam --reference genome.fa --gtf inference.gtf \
  --corrected-bed corrected/corrected.bed --out-dir chains
```

Use the all-read `corrected.bed`, not `confident.bed`. Both BAMs must be coordinate sorted with identical reference dictionaries. FASTA must be indexed. BAM input need not be indexed because this command streams alignments. Reference, annotation and BED must use the same genome and coordinate convention. A long-read name must be unique per contig, including across read groups; collisions are rejected. BED must preserve original ends, strand and intron count. Missing BED records retain original geometry and are counted in `summary.json`. Do not supply withheld truth as inference annotation.

## Released decisions and formulas

Eligible primary reads have MAPQ >=20 and NH=1 if present. Long-read adjacent CIGAR blocks require >=1 aligned base; short-read blocks require >=8. Each short-read template votes at most once per stranded junction. Exact witnesses require 10 identical A/C/G/T query/reference bases on each original junction flank.

An annotated complete chain requires at least one span-compatible read (35 nt outside-boundary tolerance). An unannotated chain requires >=2 complete-chain reads; every junction needs >=2 perfect same-chain witnesses, or >=1 witness plus >=3 short fragments. Nested unannotated chains explainable by accepted longer chains are retained as `fragment_or_short_isoform` rather than emitted. Internal containment tolerance is 6 nt and outer tolerance 35 nt. This is a chain model, not proof of complete transcript termini or fragment origin.

First apply `evidence_replay`: recover an eligible raw chain when every moved raw junction has its own perfect witness, >=2 same-chain perfect witnesses and >=3 short-fragment supports, with matching strand/intron count. This is the previous designated baseline.

The new recovery branch compares raw geometries within each corrected target chain. For raw chain c, let n_c count its reads and n_r be the largest competing raw-chain count in that corrected family (zero if absent):

    S(c) = (n_c - n_r)^2 / [2 (n_c + n_r)] if n_c > n_r; otherwise 0.
    Recover only if S(c) >= ln(100).

Family geometry ignores strand labels; the subsequent strand decision is separate. Recovery additionally requires the original selection and perfect-witness gates. Every changed junction must have smaller raw than corrected global edit distance, comparing the same query window and fixed outer reference anchors (10–20 contiguous aligned bases per side), on the focal read and >=2 same-chain witnesses. Unscorable windows and ties retain the baseline. This optional recovery branch does not demand the baseline's three short fragments, but retains its prior accepted recoveries. Each read has exactly one final geometry.

For direction, combine canonical reference motif signs (GT–AG, GC–AG, AT–AC and reverse complements) with annotation junction signs. A site with conflicting signs is neutral. Informative sites must agree: >=2 coherent sites, or >=1 plus a unique span-compatible annotated whole-chain direction. Otherwise keep the original direction. Never use a majority vote to overrule contradictory informative sites.

These support scores are not calibrated probabilities, P values or FDR. Read IDs are not necessarily independent UMI-resolved molecules. New exact chains do not establish accurate transcript ends or abundance.

## Outputs and controls

`models.gtf`: accepted chain representatives, 1-based closed exon intervals. Annotated representatives use supported annotation spans; novel ends are lower medians of observed ends.
`chain_decisions.tsv`: accepted and withheld candidate decisions.
`read_evidence.tsv.gz`: original, corrected and final chain/strand per eligible read.
`baseline_decisions.tsv.gz`, `geometry_decisions.tsv.gz`, `direction_decisions.tsv.gz`: per-read reasons and support counts.
`witnesses.json`: original exact-flank evidence.
`summary.json`: parameters, input SHA256 hashes, version, counts and sequence comparisons.

`--mode baseline` reproduces evidence_replay. `sequence_only`, `direction_only`, `no_sequence_gate`, and `no_family_gate` are explicit matched ablations; they are not alternate recommended defaults. Outputs must go to a new directory. This command produces structure models only; it does not rerun joint abundance or differential splicing.

The frozen 2026-11-23 study contains 25 inputs, with 29 additional true-chain observations, no lost true chains or added unmatched chains, and nine removed unmatched observations relative to baseline. Ten gains repeat one SIRV catalog chain. The 19 mouse gains span 14 source genes; five new-region gains span two genes. SIRV remains below ESPRESSO. Removing family competition added 388 unmatched observations without extra recovery; removing the edit-distance gate left exact chain sets unchanged on all 25 inputs. This release preserves the tested joint rule without claiming an incremental benefit from the redundant gate.
