# Native `spliceweave correct` (release 0.1.3, 2026-11-23)

The selected implementation is **SW unguarded**, the trusted-pair local correction
algorithm previously frozen as v1. It is now the sole implementation of `correct`.
The repeated-original-branch guard and `--original-support` option have been removed
from the active package. Existing scripts using that option must remove it; obsolete
options fail explicitly rather than silently changing their meaning. Historical
guarded source snapshots, results and limitations remain in the research archive.

“Unguarded” refers only to removing the repeated-original-branch gate. Exact trusted
coordinates, chromosome/strand compatibility, complete junction pairing, ambiguous
candidate handling, terminal span checks and chain geometry checks remain active.

This independent Python implementation learns the trusted-site workflow from
FLAIR correct. It does not call or embed FLAIR. Attribution: BrooksLabUCSC/FLAIR
3.0.1, BSD-3-Clause, https://github.com/BrooksLabUCSC/flair.

## Run

Install from the SpliceWeave directory with `python -m pip install .`:

```bash
spliceweave correct --query reads.bed --gtf annotation.gtf \
  --junction-tab sample.SJ.out.tab --window 10 --out-dir output/correct_new
```

Supply annotation and/or independent junction evidence. The junction BED alternative
is `--junction-bed junctions.bed`: exactly six columns, 0-based half-open intron,
score = supporting fragments, transcript strand +/-. BED12 exon blocks are **not**
junction guidance. STAR uses its 1-based inclusive intron endpoints; the parser
converts them and thresholds unique-read support (column 7). `--min-support` is 1
by default. Duplicate evidence rows are not summed. GTF exon coordinates are
converted to 0-based half-open coordinates. All files may be gzipped.

Input reads are BED12, one primary alignment per read ID, with **transcript strand**.
This is not always the BAM alignment flag strand. Unknown strand `.` is retained
unresolved. Convert BAM with a transcript-strand-aware adapter first; this command
does not perform base realignment or rewrite BAM CIGARs. No FLAIR, bedtools, reference
FASTA, Biopython or pysam is required for the correction calculation.

## Rules

1. Exact trusted intron pairs are immutable. An individually trusted original
   boundary is also protected. A new pairing of two trusted boundaries is retained
   for review, not snapped into a known transcript.
2. Candidates must be **complete observed/annotated intron pairs**, on the same
   chromosome and strand, with each boundary within `--window` (default 10 nt).
   Opposite-strand and independent nearest-boundary combinations cannot compete.
3. Select the unique minimum of `|left-left_original| + |right-right_original|`.
   Tied candidates remain unresolved. This distance is not a probability or
   significance score. Evidence support admits candidates, not a major-isoform
   abundance prior used to force ambiguous choices.
4. A moved junction requires at least `--end-anchor` (default 8) genomic bases
   between its outer boundaries and the read ends. This is a span guard, not a
   test of exact aligned bases. Simultaneous moves must leave every exon positive
   in length. Conflicting proposals are reverted together, independent of order.
5. Each junction is decided separately. An unresolved junction retains its original
   coordinates; valid corrections elsewhere in that read are retained and audited.
   Read endpoints, strand, block count and BED extra columns are preserved.

For original intron r=(l,r), let C(r) contain only trusted complete intron pairs on
the same chromosome/strand whose two coordinate displacements are each <= w, and
which preserve every individually trusted original boundary. The selected candidate
is the unique minimizer of D(j,r)=|j_left-r_left|+|j_right-r_right| over C(r).
An exact trusted pair is KEEP. No candidate, a distance tie, an unpaired combination
of two trusted original boundaries, unknown strand, insufficient terminal span, or
a chain-geometry conflict is REVIEW with unchanged coordinates. Otherwise APPLY.
This is a deterministic distance rule, not a learned or calibrated probability.

## Outputs

* `corrected.bed`: **all** input reads; accepted local changes plus unchanged
  unresolved coordinates. Never treat every junction here as independently verified.
* `confident.bed`: reads whose junctions are all exact trusted pairs or accepted
  moves. “Confident” means catalog support, not calibrated biological correctness.
* `unresolved.bed`: complementary reads, including unspliced reads.
* `junction_decisions.tsv.gz`: original/final coordinates, KEEP/APPLY/REVIEW, reason,
  and nearby compatible candidate pairs. Index is 0-based along genomic coordinates.
* `read_status.tsv`: read-level status and action counts; unspliced is separate.
* `summary.json`: configuration, reason counts, input/source/output SHA-256,
  release version 0.1.3, schema version 3, algorithm ID
  `sw-correct-trusted-pair-local-v1`, and `original_branch_guard: false`.

Existing output directories are refused. Invalid BED/GTF, duplicate read IDs or
inputs changing during the run abort without publishing a partial result.

## Scope and evaluation

This is the selected `correct` implementation; `review-junctions`, the archived integrated correction
script, differential analysis and frozen benchmarks retain their earlier behavior.
The module cannot discover a missing microexon, introduce an unobserved splice site,
resolve a true novel intron absent from its guidance, or prove transcript completeness.
Trusted annotations may be wrong; protecting them is a prior, not independent truth.

Compare both all-read coordinate retention and wholly trusted output. FLAIR rejected
reads can retain local corrections; include that combined-output diagnostic as a
fair control. Catalog-consistency gains with the same annotation supplied to all
tools are not source-molecule accuracy, biological discovery, or calibrated FDR.
New-library Sequin validation reuses constructs; genuinely independent source/gene
validation remains necessary. Release selection does not establish superiority.

Known source-labelled results of the selected algorithm: human simulation, 86
incorrect-to-correct repairs, 0 correct-to-incorrect changes and 17 wrong-to-wrong
changes; mouse simulation, 331 repairs, **3,141 correct-to-incorrect changes** and
153 wrong-to-wrong changes. These are read-window observations, not unique genes.
Both are previously revealed development panels. The favorable Sequin catalog
consistency results do not override the mouse failure or prove source accuracy.

The original prototype (v1) and retired branch-protected revision (v2) remain frozen
in `Output/SpliceWeave_FLAIR_source_study_20261123`. Release 0.1.3 is a packaging and
default-selection update of v1, not another trained model. Its equivalence checks
and provenance are in `Output/SpliceWeave_correct_release_0.1.3_20261123`.
The matching manuscript is
`07Manuscript/SpliceWeave_正式稿_20261123/Manuscript_20261123_SW_unguarded.docx`.
It includes six editable equations for the current decision function, current
Figure 2 correction panels, Table_S20, and the source-accuracy limitations.
Other module benchmarks keep their original run identities; they were not rerun
end to end with these corrected BED files.
