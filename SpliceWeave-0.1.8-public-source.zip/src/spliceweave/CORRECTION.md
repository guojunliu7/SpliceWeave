# Event-preserving junction review (experimental, 2026-11-23)

This opt-in module reviews proposed local junction coordinates. It writes tables;
it does not edit BAM/GTF files, promote transcript structures, or change abundance
estimates. The existing integrated correction script and differential-splicing
command keep their previous behavior.

Install the `correction` extra and run from the repository:

```bash
python -m pip install -e '.[correction]'
spliceweave review-junctions --input evidence.jsonl.gz \
  --config configs/event_preserving_balanced_20261123.json \
  --out-dir results/new_junction_review
```

The dated configuration is the **development-selected balanced configuration**.
Defaults are more conservative and are not identical to this configuration.
Neither is independently validated or probability-calibrated.

## Input contract

Each JSONL record contains `gene`, `rid`, `molecule_id`, `original`, `query`, and
a variable-length `candidates` list, which must include the original coordinate.
Each candidate contains a unique `id`, a spliced reference `path`, its `boundary`
within that path, `short_support` (deduplicated short-read fragments, or null),
`phase_molecules` (library-qualified molecule IDs), and optional `splice_motif`
(four genomic donor/acceptor bases oriented to the transcript strand).
All candidate paths and the query must use the same outer genomic anchors.

`phase_molecules` must come from **uncorrected** reads with matching strand,
MAPQ >=20, eight exact genomic bases on both sides of the candidate junction,
and at least one shared neighboring junction outside the disputed site. Shared
neighbors must not conflict where both molecules cover them. This is local
phasing evidence, not proof of a complete transcript or biological replication.
The current molecule and duplicate IDs are excluded. A PacBio ZMW must be counted
once across its subreads; MI identifiers, if available, take precedence over read
names. Library identity must be included. Do not feed corrected reads back as
independent evidence.

The benchmark extractor retains at most two IDs **after** exclusion, which is
enough for the saturation rule; its extra total-count field records the uncapped
count. The generic reviewer itself deduplicates and excludes self as well.

Example schema (illustrative sequence, not experimental data):

```json
{"gene":"g","rid":"read1","molecule_id":"lib|read1","original":"100-200","query":"ACGTACGT","candidates":[{"id":"100-200","path":"ACGTACGT","boundary":4,"short_support":null,"phase_molecules":[],"splice_motif":"GTAG"},{"id":"101-200","path":"ACGTTACGT","boundary":5,"short_support":4,"phase_molecules":["lib|read2","lib|read3"],"splice_motif":"GTAG"}]}
```

## Decision rule

For candidate j, let f(r,j) be the seven archived sequence-alignment features,
h(r,j) the number of other phased molecules, and s(j) the short-fragment support.
With phi(n)=min(n/2,1), the balanced development score is:

    S(r,j) = w_seq^T f(r,j) + 8 phi(h(r,j)) + 2 phi(s(j))
             + 6 I[h(r,j)>=2 and s(j)>=4 and canonical(j)].

The sequence coefficients are inherited from the archived 20261120 scorer. The
old original-position penalty and unbounded relative abundance terms are removed.
Every candidate, including the original, receives the same evidence terms.
Support saturates at two independent molecules: a major branch cannot dominate
solely because it has hundreds more reads. This is a prototype for protecting
discriminating event observations; it is not yet a formally calibrated DEOU loss.

An alternative may compete if it has at least two phased molecules, two short
fragments, or a raw local alignment-score gain of at least five over the original.
Unsupported alternatives remain in the audit and are not silently erased. This
rule does not prove that an excluded candidate is false.

The best admitted candidate must beat its nearest competitor by at least two
score units. Changing the coordinate additionally requires either a positive
raw sequence-score gain, or a bounded independent-evidence rescue:

1. At least two phased target molecules, no phased original molecules, no short
   support for the original, and raw alignment loss no greater than eight.
2. Or a canonical target with both phased and short-fragment support, an observed
   noncanonical original with no short support, and the same bounded loss.

An exact original query/path match is protected from these rescue overrides.
Missing motif or short-read evidence is kept distinct from an observed negative.
Neither missing signal alone justifies moving a site. These engineering settings
were explored on revealed development genes; they are not universal cutoffs.

Outputs are `KEEP`, `APPLY`, or `REVIEW`. REVIEW retains the original in `final`,
and preserves plausible alternative IDs in the detailed JSONL. No unsupported
fraction is forced into a transcript estimate. `unknown_possible` flags unusable
sequence; it does **not** detect every case with truth absent from the catalog.
`candidate_catalog_exhaustive` is always false. Scores are neither probabilities
nor quantification likelihoods; do not insert them into Q or treat them as FDR.

## Validation and limitations

The 20261123 human/mouse 240-gene assessment had already been revealed before this
development began. All results here are diagnostic and cannot be renamed an
independent test. The original all-read denominators, truth source, four external
tool outputs, old model, strict sequence gate, feature ablations, and discarded
development configurations are retained in the dated Output directory.

Independent testing must freeze this code/configuration before opening new labels,
exclude prior loci and source molecules, report all candidates (including missing
truth), and cluster uncertainty by genes or independent libraries. Fewer correct-
to-wrong changes does not establish high correction precision: wrong-to-wrong
changes are separately counted and still require work.
