# Replicate-aware observed-count testing

SpliceWeave 0.1.7 adds `diff-splicing-counts`, the packaged frozen beta-binomial
bootstrap score model (`sw-count-bootstrap-v1`). This is a separate command:
`event-psi` retains molecular usage from geometry_MAP_joint abundance, and
`diff-splicing-joint` retains synchronized platform/conflict permutation tests.
The count model does not generate a P value for molecular DeltaPSI.

```
spliceweave diff-splicing-counts --samples samples.tsv --counts short_counts.tsv \
  --reference Mix_A --comparison Mix_B --out-dir count_results
```

Inputs use the existing event/count format: event_id, sample_id, Unit,
A_only_fragments, B_only_fragments; gene_names or ensembl_gene_ids must identify
one gene. An optional `--catalog` supplies annotations. At least two independent
biological samples per group are required. Paired designs are not supported by
this command; use the existing permutation interface for paired observations.
The default requires 20 informative fragments in every sample. Existing IR
observability checks remain active. Missing or ambiguous gene assignments,
unobservable branches, and absent cross-gene priors remain explicitly untested.

For event e, sample s, y is B-only count, n is A+B. The observed effect is the
difference of unweighted biological-sample means of y/n. Within-group excess
variance gives a moment dispersion rho_raw. In each IR/nonIR family, first
average raw dispersions within gene, then average over all OTHER eligible genes
to obtain rho_prior. With nu=N-2, the frozen shrinkage is
rho = clip((nu*rho_raw + 4*rho_prior)/(nu+4), 1e-6, .95).
For group c, mu_c=mean((y+.5)/(n+1));
V=sum_c sum_s mu_c*(1-mu_c)*(rho+(1-rho)/n_s)/N_c^2;
T=delta_observed^2/max(V,1e-15).

Under the fitted null, mu0=clip(mean(y/n),1e-6,1-1e-6) and
rho0=max(rho,rho_prior). Simulate a Beta latent fraction and Binomial counts
per sample, refit the dispersion and score in every draw. B=9999 by default;
p=(1+number(T_sim>=T_observed))/(B+1), inclusive tails. This conditional
parametric P value is not an exact permutation probability. Seeds use the first
8 SHA256 hex digits of seed-prefix + event_id; default prefix 20261125.

`count_differential_events.tsv` retains all events and eligibility reasons,
delta_B_fraction, p_value, BH_q, prior/rho, seed and the explicit estimand.
`sample_usage.tsv` records sample-level counts and observability. `summary.json`
records parameters, input hashes and scope. BH is applied to all tested events
within IR/nonIR. Calls require q<=.05 and |observed change|>=.1 by default.
A ranking restricted to a benchmark's common event family uses its own explicit
BH family, and need not equal the native full-family call set.

Validation scope: prior-viewed GSE172421 Sequin libraries at full depth, reduced
replication and 25% depth. Low counts of truly unchanged benchmark events do not
establish general FDR control. Do not reinterpret this as capture-corrected
molecular significance or superiority across independent datasets.

## Optional coverage rescue

Install the optional dependency from the source directory with `python -m pip install '.[rescue]'`.
Pass the event-psi output for the same samples, event IDs and A/B branch definitions.

```bash
spliceweave diff-splicing-counts --samples samples.tsv --counts short_counts.tsv \
  --reference Mix_A --comparison Mix_B --coverage-rescue event_usage.tsv \
  --out-dir count_with_rescue
```

Omitting the option selects the standard count analysis. With rescue enabled the
default per-sample minimum is one informative fragment for computing the count
test and its priors. Set `--min-informative` explicitly to override this value.
Count evidence takes precedence if a count score exists and at least half the
replicates in each group have five or more informative fragments. Eligible
events with insufficient count support use the molecular score from other genes
at similar abundance. The contrast is comparison minus reference in both modes.

The additional file `coverage_rescue.tsv` identifies the evidence source,
effect, score and exploratory candidate flag for each event. Candidates meet a
BH-transformed ranking score cutoff of 0.05 and the requested minimum absolute
effect. The ranking needs independent calibration before use for FDR claims.
Use `count_differential_events.tsv` for observed-count p and q values.
