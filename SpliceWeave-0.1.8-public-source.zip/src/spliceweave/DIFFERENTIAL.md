# SpliceWeave differential splicing

比较两个条件中同一剪接事件的分支使用比例。每行样本对应一份生物学样本。同一样本的技术重复应先合并。可提供两个以上条件，然后用名称选择本次比较的两组。按独立组分析时每组至少两个生物学重复，组大小可以不同。配对分析至少需要两对完整样本。

## 安装与试运行

在 SpliceWeave 源码根目录执行 `python -m pip install .`。有配套 wheel 时也可使用 `python -m pip install 路径/文件名.whl`。以下合成输入演示了不同样本名、两组不等量和一个低覆盖事件。文件位于源码的 `examples/differential/`，在审稿包中位于 `example/differential/`。在示例目录执行

~~~bash
spliceweave diff-splicing --samples samples.tsv --counts counts.tsv \
  --reference vehicle --comparison treated --out-dir result
~~~

期待 3 个事件中 2 个可检验，shift 的处理组减对照组效应为 +0.80，stable 为 0，low_depth 保留覆盖不足状态。这些人为构造的计数仅供核对运行。

### Minimal input (English)

`samples.tsv` has one row per biological replicate with columns `sample_id` and `condition`. Choose the two group names with `--reference` and `--comparison`. Groups can differ in size. To compare matched samples, add a subject identifier and specify its header with `--pair-column`. Each subject contributes one sample per condition.

`counts.tsv` has columns `event_id`, `sample_id`, `Unit`, `A_only_fragments` and `B_only_fragments`. Counts are mutually exclusive short-read fragments for the two fixed event paths. Alternatively use `--events events.gtf.gz --gtf models.gtf.gz` with indexed, paired-end short-read BAMs listed under `sr_bam` and their `sr_strandedness` in the design. The same reference build and chromosome names must be used throughout. The BAM path can be relative to the design file.

`differential_events.tsv` reports the comparison-minus-reference difference in mean observed B/(A+B), its two-sided permutation P value and BH q value. It also reports events with insufficient data. `sample_usage.tsv` provides the counts behind each sample fraction. These observed fractions can depend on fragment opportunity and branch length.

## 使用自己的数据

- **有分支计数**。样本 TSV 需要 `sample_id`、`condition`。计数 TSV 每个事件、样本一行，列为 `event_id`、`sample_id`、`Unit`、`A_only_fragments`、`B_only_fragments`。A、B 是在同一固定目录上只支持相应分支的整数片段计数；模糊片段及同时支持两分支的片段单列。TPM、PSI、累加连接读数或两个平台的计数之和均不满足该输入定义。表可用 gzip 压缩。可额外提供 `--catalog events.tsv`，按事件 ID 匹配 `Unit`、`gene_names`、`AS_code`、坐标等；冲突会报告错误。目录中缺样本的事件仍列入结果。
- **有 BAM 及转录本模型**。安装 `python -m pip install '.[bam]'`，或为已安装的 wheel 安装 `pysam>=0.22`。设计表再加 `sr_bam`、`sr_strandedness`。BAM 可用绝对路径或相对于设计表的路径。每个样本一份已建立索引的双端、坐标排序 RNA-seq BAM。链特异性可填 `unstranded`、`forward_stranded`（read 1 对应转录链）或 `reverse_stranded`（read 2 对应转录链）。长读可提供固定转录本 GTF；如使用原生 AStalavista GTF，请同时提供生成该目录的转录本 GTF，染色体命名和参考版本须对应。

~~~bash
spliceweave diff-splicing --samples samples.tsv --events AS_events.gtf.gz \
  --gtf transcript_models.gtf.gz --reference control --comparison treatment --out-dir result
~~~

原生 AStalavista GTF 取 `as_event` 行。A、B 对应原事件的第一、第二分支；优先沿用 `event_id`，缺省时从坐标和结构生成稳定的 SW 标识。也可用两分支 TSV。必需列为 `event_id chrom strand start end`，另加 `AS_code splice_chain flanks`，或 `Unit branch_A_introns_1based branch_B_introns_1based`。列以制表符分隔。内含子按基因组顺序填写 1-based 闭区间，例如 `101-180;241-330`，完全保留的分支为空字符串。程序核对两条局部路径都出现在覆盖事件窗口的 GTF 模型内，其他竞争路径也参与片段归属。GTF 的多个分支和可变转录端不在此二分支检验范围，列于 `excluded_events.tsv`。直接提交分支计数时，用户负责保持每个事件 A、B 的结构与方向一致。

双端片段按同一文库的读组及读名合并。使用正确配对、主比对、MAPQ ≥20，过滤重复及质控失败读段；剪接连接两侧锚定均至少 8 nt。IR 保留分支需实际测到跨整段内含子且两侧各有 8 nt 的连续比对。未测序的双端间隔不作为保留证据。覆盖不足的长内含子会影响 IR 可检验数量。

## 设计、统计量与输出

IR 计数要求单个连续比对块覆盖保留内含子及两侧各 8 nt。每个样本的可观测性单独核对，刚好达到所需长度也算可观测。BAM 模式默认从整个输入 BAM 读取最长主比对读段，也可在样本表提供经整库质控核实的 `max_mate_length`。使用区域切片时应优先填写其来源文库的整库值。计数模式若使用相同规则，在样本表或计数表填 `ir_count_rule=single_mate_full_span` 和最长单端读长，并提供两条分支内含子路径。超过读长的事件保留原始计数，受影响样本的比例及组间检验记为 NA。缺少适用的规则、路径或读长，且只有单侧阳性时，在达到计数阈值后记为 `unknown_IR_observability`。两侧均有实测计数及低深度样本分别标记。逐样本表保留 A、B 两条分支所需的跨度及可观测性。

- 匹配设计在样本表添加同一个体或生物学配对的 ID 列，两组各一个样本，命令添加 `--pair-column subject_id`。默认置换独立样本的组标签，配对模式仅在每对内交换。批次、连续变量及多因素交互需要其他适当的统计模型。
- 单样本比例为 B/(A+B)。比较以生物学样本等权计算两组均值之差，方向固定为 `comparison − reference`。0.1 表示 B 分支增加 10 个百分点。该量是观测片段占比，尚未作分支有效长度或捕获效率校正。
- 默认每个选中样本均须有 20 个可判定片段，可通过 `--min-informative` 指定。未观测或低覆盖保留状态和 NA，每样本实际零个片段记录为零覆盖。缺失样本不能当成零计数；每组应含可交换的生物学重复。
- 两侧置换检验以均值差绝对值衡量。可行分组数 ≤10,000 时全枚举；超过该值默认有放回抽取 10,000 个随机标签分配并计算 (极端次数+1)/(抽取次数+1)。`--exact-limit`、`--permutations` 和 `--seed` 可调整。仅在达到覆盖要求的事件上分别对 IR 及非 IR 做 Benjamini–Hochberg 校正。Complex 表示固定的两条局部路径，该类检验属探索性。小样本精确检验的 P 值分辨率有限。
- `differential_events.tsv` 给出各事件、样本覆盖数、两组均值、`delta_B_fraction`、双侧 `p_value`、`BH_q`、`significant` 和可检验状态。`sample_usage.tsv` 提供每个样本的分子、分母及观测比例。`summary.json` 记录组别、置换模式、阈值、输入校验及实际检验数。BAM 模式提供 `branch_counts.tsv` 复查被排除的片段类别。每次使用新的输出目录。
