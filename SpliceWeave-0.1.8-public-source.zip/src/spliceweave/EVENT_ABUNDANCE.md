# Molecular event usage: selected joint estimator

`event-psi` is an optional adapter from transcript molecular abundance to a fixed, GTF-validated event catalogue. It does not replace the released count-based difference tests.

```
spliceweave event-psi --events events.tsv --gtf models.gtf --abundance abundance.tsv --value-column TPM --out-dir event_usage
```

The TSV requires sample, transcript_id, and a finite nonnegative abundance column. Concatenate SW quantify abundance.tsv files with one header. SR_TPM selects the SR-only estimate; TPM selects the joint estimate. Raw fragment counts are not molecular abundance.

The formula is sum(B abundance)/sum(A+B abundance). This is established methodology, including SUPPA/SUPPA2, not a new formula. The independently written adapter does not invoke external tools. External TPM must be attributed to its upstream quantifier. See https://github.com/comprna/SUPPA/blob/master/psiCalculator.py .

Both local paths must exist in the GTF; their transcript sets are disjoint. Other spanning paths are reported separately, with AB_fraction_of_local_abundance showing the conditional denominator's coverage. Missing transcripts produce missing_denominator, never implicit zero. Zero total abundance produces zero_denominator. Estimated does not imply independent identifiability, calibration, or correctness.

No significance test is produced. Do not feed TPM into a molecule-count test. Native SW geometry models do not yet provide validated LR truncation/capture correction. Keep observed fragment fractions alongside molecular estimates during development. The current Sequin data have already been inspected; reanalysis is not independent validation.

## Current project selection (2026-11-24)

By user decision, continue with the previous **SW native joint abundance**
estimator: `quantify` → joint `TPM` → `event-psi`. For group change, take the
comparison-group mean sample PSI minus the reference-group mean sample PSI,
weighting biological replicates equally. Do not use the experimental
`replicate_pooling` refinement for the current analysis.

The selection applies to molecular PSI/ΔPSI estimation, not a replacement of
count-based significance tests. The event adapter remains experimental with
respect to external validation; selection is not evidence of superiority over
SUPPA2. On the previously inspected Sequin subsets, ΔPSI MAE was 0.954365 pp
(15 events) and 5.072586 pp (40 events).

The source and evidence hashes are recorded in
`configs/event_estimation_selection_20261124.json` as an audit manifest, not a
runtime configuration consumed by the CLI. CLI `event-psi` already defaults
to `TPM`; no inference code change was necessary. The unused replicate-sharing
prototype and its negative results remain available for research audit.

## Experimental replicate refinement (2026-11-24)

`quantification.replicate_pooling` adds a research-only estimator; it is not
wired into the released `quantify` or differential-test default. It consumes
native observation probabilities, conditions on gene and read-length pattern,
and estimates a separate within-gene molecular composition for every sample.
The prototype assumes no cross-gene ambiguous observations in the evaluation;
`gene_blocks` audits any exclusions. Whole-transcriptome application requires
proper opportunity denominators for cross-gene ambiguity before deployment.

For log-compositions `z_s`, the objective is the native conditional negative
log-likelihood plus a weak centered log prior (variance 25), optionally adding
`sum_s ||center(z_s) - mean_condition(center(z))||^2 / (2*tau^2)`.
The within-condition penalty borrows information without making every
replicate identical. `tau` is estimated from other genes' baseline replicate
variation, excluding the target gene from that dispersion summary. Those
baseline abundances share upstream fitted parameters; this is not a fully
cross-fitted abundance pipeline or independent validation. The penalty is
standard partial pooling, not a claim of a new statistical family.

Outputs are **within-gene relative abundances, not transcriptome TPM**.
They may be projected onto same-gene event partitions using `project`.
Group delta is the difference of equally weighted sample PSI means. No p-value,
FDR guarantee, biological-variance calibration, or independent verification is
provided by this estimator. It cannot replace differential significance tests.

The frozen development protocol, fitting script, full comparisons and figures
are in `Output/SpliceWeave_SUPPA2_refinement_20261124` at the project root.
