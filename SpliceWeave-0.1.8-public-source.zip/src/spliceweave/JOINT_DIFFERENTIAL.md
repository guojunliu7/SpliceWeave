# Joint differential splice-branch usage (0.1.6)

`diff-splicing-joint` accepts user-defined conditions and any species with a common
reference and a fixed, two-branch splice-event catalog. It measures condition
changes and tests platform interaction. Its first benchmark is **synthetic
statistical validation**, not a demonstration of superiority to rMATS/MAJIQ or
independent biological accuracy.

## Inputs and execution

Count-table mode:

```sh
spliceweave diff-splicing-joint --samples samples.tsv \
  --short-counts short.tsv --long-counts long.tsv --catalog events.tsv \
  --reference control --comparison treated --out-dir results/joint
```

Each biological sample appears once in `samples.tsv` with `sample_id, condition`.
Both platforms correspond to that **same biological sample**, never two pooled
condition-level libraries. At least two samples per condition are required;
small designs can have insufficient permutation resolution for multiplicity
correction. Optional `--pair-column subject_id` is for matched subjects across
conditions, not for matching short and long libraries within a sample.

The catalog columns are `event_id, Unit, chrom, strand, start, end,
branch_A_introns_1based, branch_B_introns_1based`. Coordinates are 1-based closed;
branch introns are ordered `start-end;start-end`. Empty branches represent
retention. Both intron paths must lie strictly inside the local window and the
same A/B definition must apply in every sample and platform.

Each platform table contains `event_id, sample_id, Unit, A_only_fragments,
B_only_fragments`; missing data must be explicit `NA,NA`, not zero. Catalog
annotations supplied in counts are checked for agreement. Only uniquely
classified A/B molecules enter the fraction; other/ambiguous paths are retained
in BAM-mode audit counts. Count-table providers are responsible for consistent
branch assignment and independent molecules. All catalog events remain in the
output, including untestable events.

BAM mode (`pip install '.[bam]'`):

```sh
spliceweave diff-splicing-joint --samples bam_samples.tsv \
  --events events.tsv --gtf inference_models.gtf \
  --reference control --comparison treated --out-dir results/joint_bam
```

`bam_samples.tsv` additionally contains `sr_bam, sr_strandedness, lr_bam,
lr_strand_rule`. BAMs require coordinate sorting and indexes. Relative paths are
resolved from the sample table. SR strandedness is `forward_stranded`,
`reverse_stranded`, or `unstranded`. LR strand rule is explicitly `forward`
(oriented cDNA follows genomic alignment), `reverse`, or `tag` (genomic XS, or
minimap2 ts interpreted relative to read orientation). Missing strand tags in
tag mode are skipped and counted; no silent unstranded fallback. Use the rule
matching the actual library/alignment protocol. Each long read must represent
one FLNC/consensus molecule, not repeated subreads from a ZMW. The counter merges
identical primary records with the same query name and read group and rejects
distinct primary alignments for that identity. It does not infer UMI deduplication.

Supported input is a two-branch event TSV or AStalavista `as_event` GTF. Local
paths are verified against inference-model GTF. Multi-branch events and
alternative transcript ends are excluded explicitly. This is local event
recognition/counting on an existing catalog, **not a de novo genome-wide event
catalog discovery algorithm**. The inference GTF must not be a withheld truth
catalog in a discovery benchmark.

MAPQ >=20, splice anchors >=8 nt; SR evidence uses proper pairs and LR evidence
uses single aligned molecules. Secondary/supplementary/duplicate/QC-failed
records are excluded. IR retention requires the entire intron plus 8-nt flanks
sequenced in one mate/read. Library maximum observed lengths constrain physical
observability; they do not establish uniform capture efficiency. Count-table
IR metadata use `max_mate_length, ir_count_rule=single_mate_full_span` separately
in each platform table; optional design `max_long_read_length, lr_ir_count_rule`
are LR-specific. SR length metadata are never reused for LR.

## Estimands and tests

For sample i, platform p and event e:

    psi[i,p,e] = B[i,p,e] / (A[i,p,e] + B[i,p,e])
    Delta[p,e] = mean_treated(psi[p,e]) - mean_control(psi[p,e])
    Delta[joint,e] = (Delta[short,e] + Delta[long,e]) / 2
    Delta[interaction,e] = Delta[long,e] - Delta[short,e]

Weights are fixed at 1/2 and biological samples are equally weighted. The
estimand is an **observed branch fraction**; it is not a capture-corrected
molecular PSI. Joint averaging can worsen accuracy when one platform is much
noisier. The CLI deliberately does not tune weights using differential truth.

One synchronized label allocation is applied to both platforms and every event.
Independent-group tests permute biological-sample labels; paired tests swap both
platforms together within each subject. Two-sided absolute mean contrasts test
SR, LR, their average, and the per-sample LR-minus-SR difference. Exact tests
include all allocations when there are <=10,000; otherwise 10,000 random draws
with `(extreme+1)/(draws+1)` are used (seed 1). Ties count as extreme.

Separate **directional conjunction** evidence asks whether both platforms
support change in the same direction:

    p_concordance = min(1, 2 * min(max(p_SR_up, p_LR_up),
                                  max(p_SR_down, p_LR_down)))

This is an intersection-union test in each direction, followed by a two-direction
Bonferroni correction. It does not assume independent technologies. It is more
conservative than testing their average; a significant average alone does not
establish replication in both platforms.

Default multiple-testing adjustment is BY (`--adjustment BY`) over all tested
IR and nonIR events, **separately for each endpoint** (SR, LR, joint, interaction,
concordance). BY accommodates arbitrary dependence between event tests when
individual p-values are valid. BH is an explicit sensitivity option with its
usual dependence assumptions. There is no guarantee for a pooled union of
claims selected across endpoints. `joint association` is the primary endpoint;
concordance and interaction remain separately reported analyses. No outcome-
dependent filtering or post-hoc choice of an endpoint is used.

Permutation validity requires exchangeability of observed sample-level
measurements (within matched pairs in paired mode), not merely identical mean
PSI. Batch, depth-dependent heteroskedasticity, and condition-confounded capture
can violate it. Covariate-adjusted regression is not implemented. An interaction
indicates differing observed platform effects, not necessarily which platform
is wrong or whether the cause is technical. A nonsignificant interaction does
not prove platform equivalence. No computational test can separate biological
change from a bias perfectly confounded with condition in both technologies.

Default coverage thresholds are SR >=20 and LR >=5 informative molecules in
**every** selected sample. Joint/conjunction/interaction tests require both
platforms eligible. A usable single platform is still tested separately. Missing
or unobservable evidence is never interpreted as no change. Users must choose
thresholds before viewing effects; do not relax them solely to obtain hits.

## Outputs

- `joint_differential_events.tsv`: per-platform and joint effects, p and adjusted
  q values, directional conjunction, interaction, opposite-direction flag, and
  audit status. `platform_conflict` requires opposite point estimates **and**
  significant interaction. Same-direction significant interaction is
  `platform_effect_heterogeneity`.
- `short/`, `long/`: per-sample branch counts/fractions/observability and separate
  statistical results. `adjusted_q` uses the selected correction across event
  types; `legacy_BH_q_within_event_type` is retained only for traceability.
- BAM mode additionally saves both count tables, event catalog, exclusions, and
  source BAM path/size/mtime manifest. Input and generated count/catalog SHA256
  values, parameters, finite permutation resolution, and limitations are recorded
  in `summary.json`. The BAM manifest is metadata, not a cryptographic BAM hash.
- Existing result directories are not overwritten. Failed runs leave no partial
  final result directory.

## Formal benchmark and current scope

Project output `Output/SpliceWeave_joint_differential_20261124` contains a frozen
simulation protocol, seeds, executable benchmark, tables, figures and NT/PF BAM
recount. Four scenarios cross 3/4/6/8 replicates per group and SR/LR depth pairs
30/5, 100/20, 400/80. Each of 48 cells has 30 independent datasets of 240 events
(1,440 datasets total). Shared changes, complete nulls, opposite platform effects,
and LR-only capture shifts are distinguished. Recall includes all true changed
events, including coverage failures. Report mean FDP as empirical FDR, null FPR,
coverage, observed Delta-PSI error, and interaction sensitivity. LR-only capture
shifts have no biological change but a genuine observed platform effect: a joint
association in that stress test is not evidence of biological change.

The first real-data audit comprises the six preselected NT/PF gel loci. It is
retrospective and lacks independent quantitative differential truth; it is an
input/coverage audit, not a six-locus accuracy validation. It must not be pooled
with synthetic truth or represented as prospective RT-PCR confirmation.

## Statistical references

- Phipson & Smyth, permutation p-values should never be zero:
  https://pubmed.ncbi.nlm.nih.gov/21044043/
- Winkler et al., permutation inference and exchangeability:
  https://pmc.ncbi.nlm.nih.gov/articles/PMC4010955/
- Benjamini & Yekutieli, dependence-aware FDR control (2001):
  https://doi.org/10.1214/aos/1013699998

These are established statistical methods, not claimed as novel SpliceWeave
inventions. The implementation integrates them with shared event definitions,
platform-specific observability, molecule-level counting and conflict reporting.
