# Native joint quantification

Version 0.1.5 promotes the frozen `geometry_MAP_joint` model from the 2026-11-24 six-library comparison. `correct` and `assemble-chains` retain their existing policies. The packaged quantifier does not run an assembler or competitor internally.

## Inputs and outputs

Install with `python -m pip install '.[quantification]'`. Run:

```bash
spliceweave quantify --gtf transcripts.gtf --short-bam short.bam --long-bam long.bam --sample sample1 --out-dir results/quant
spliceweave quantify --geometry results/quant/geometry.json.gz --sample sample1 --out-dir results/replay
```

The catalogue is fixed for inference; it must not contain withheld ground truth except in an explicitly labelled complete-catalogue benchmark. GTF exons require gene_id and transcript_id. BAMs must be coordinate sorted and share identical reference names, lengths and order. Primary unique mappings at MAPQ >=20 and junction anchors >=8 nt are used. Transcript strand follows XS or ts when available; unknown strand is not inferred from unstranded paired alignment orientation. Read-group and read-name identify fragments. Supplementary, secondary, QC-failed and duplicate-marked alignments are excluded. Long-read terminal compatibility slack is 50 nt; short-read slack is zero. Filtered single mates are treated as single observations. This module estimates abundance from the supplied geometry, not sequence-level correction.

`abundance.tsv` contains joint TPM, SR_TPM (matched short-read control) and has_input_support. Input support means at least one compatible observation, not unique identifiability. Zero-support models have zero TPM. `summary.json` records all three fit convergence results, calibration statistics, settings, version and input SHA256. Failure to converge does not publish a completed output directory. `geometry.json.gz` is a transparent JSON replay input; no user-supplied pickle is loaded.

## Frozen likelihood

Let z_t be a transcript's log abundance and b_t = exp(z_t). For short-read observation class i, A_it is its compatibility-weighted transcript-space fragment probability; paired observations use the calibrated insert distribution, single reads use compatibility. E_kt is the number of valid fragment starts integrated over the insert distribution for read-length pattern k. n_i is the fragment count; N_k = sum_{i:k(i)=k} n_i. L_jt is long-read compatibility and m_j its class count.

The minimized negative log posterior is

```
J(z) = sum_k N_k log(sum_t E_kt exp(z_t))
     - sum_i n_i log(sum_t A_it exp(z_t))
     + (sum_j m_j) log(sum_t exp(z_t))
     - sum_j m_j log(sum_t L_jt exp(z_t))
     + sum_t (z_t - mean(z))^2 / (2 v).
TPM_t = 10^6 exp(z_t) / sum_u exp(z_u).
```

The SR-only maximum-likelihood fit initializes SR MAP; v is the squared robust MAD of the initial log abundances, clipped to [1,25]. The joint fit starts from SR MAP and retains its v. L-BFGS-B uses bounds [-25,25], maxiter=4000, ftol=1e-14, gtol=1e-5 and maxls=40, matching the comparison. The prior is a regularizer, not an independently calibrated molecular-source probability.

Calibration uses fragments with a uniquely determined insert length and a single inference gene. Each gene's own histogram is excluded from its background; SIRV loci are excluded as blocks. The frozen calibration support is 1–3000 nt. A uniform fallback is recorded when the remaining histogram is empty. Valid starts enforce an 8-nt junction anchor; exposure uses 256-point quadrature. Nonpositive exposure for an observed member is clamped and audited. No direction gate or split reliability filter is part of the released fit.

## Interpretation and scope

This version models SR insert geometry. LR likelihood uses compatible sets; a calibrated model of long-read truncation and capture bias has not been established. It is not a deep-learning model and must not be described as one. Whole-transcriptome runtime and scale have not been validated by the targeted catalogue benchmarks.

In the six Sequin libraries, the uniform input-supported full-denominator metric gives mean within-gene TV errors of 12.50 and 10.91 percentage points (A and B). MPAQT differences have confidence intervals crossing zero. The matched SR-only versus joint mean improvement is below 0.01 percentage points. These are previously inspected libraries and shared constructs, not new independent-gene validation. Numerical floor predictions in unsupported genes can change the ranking under other scoring conventions; retain the documented scoring sensitivity.

## Release verification

All 117 tests passed. All six frozen geometry inputs reproduce the archived probability matrices exactly and all fits converge. The six likelihood/geometry functions are AST-identical to the frozen comparison source. Replayed TPMs are not bitwise identical to archived fits: the largest observed per-transcript difference was 0.378081 TPM. This numerical replay does not replace the archived benchmark or establish a new performance gain.
