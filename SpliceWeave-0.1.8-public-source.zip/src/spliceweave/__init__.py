"""SpliceWeave correction and cohort-analysis commands."""

__version__ = "0.1.8"
