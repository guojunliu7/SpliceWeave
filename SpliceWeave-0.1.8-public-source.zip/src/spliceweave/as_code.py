"""Structural rules from classify_flnc_astalavista_unit for two internal splice paths."""

from __future__ import annotations

import re
from dataclasses import dataclass

TOKEN = re.compile(r"(\d+)([\^-])")


class CoordinateCollision(ValueError):
    """Two AS code ranks share a genomic coordinate; inspect the models."""


@dataclass(frozen=True)
class Classification:
    unit: str
    detail: str
    rule: str
    validation: str


def tokens(value: str, *, allow_zero: bool = False) -> list[tuple[int, str]]:
    if value == "0" and allow_zero:
        return []
    found = [(int(number), symbol) for number, symbol in TOKEN.findall(value)]
    if not found or "".join(f"{number}{symbol}" for number, symbol in found) != value:
        raise ValueError("malformed AS code or splice chain")
    numbers = [number for number, _ in found]
    if numbers != sorted(set(numbers)):
        raise ValueError("site numbers are not unique and increasing")
    return found


def chain_tokens(value: str) -> list[tuple[int, str]]:
    if value == "":
        return []
    found = [(int(number), symbol) for number, symbol in TOKEN.findall(value)]
    if not found or "".join(f"{number}{symbol}" for number, symbol in found) != value:
        raise ValueError("malformed coordinate splice chain")
    return found


def validate(code: str, chain: str, strand: str) -> list[list[tuple[int, str]]]:
    if strand not in {"+", "-"}:
        raise ValueError("unknown strand")
    code_sides, chain_sides = code.split(","), chain.split(",")
    if len(code_sides) != 2 or len(chain_sides) != 2:
        raise ValueError("expected exactly two AS variants")
    rank_sites: dict[int, tuple[int, str]] = {}
    variants = []
    for code_side, chain_side in zip(code_sides, chain_sides):
        sites = tokens(code_side, allow_zero=True)
        coords = chain_tokens(chain_side)
        if len(sites) != len(coords):
            raise ValueError("code and chain have different site counts")
        if [symbol for _, symbol in sites] != [symbol for _, symbol in coords]:
            raise ValueError("code and chain have different splice-site symbols")
        if code_side == "0" and chain_side != "":
            raise ValueError("zero variant has a nonempty splice chain")
        for (rank, symbol), (coord, _) in zip(sites, coords):
            site = (coord, symbol)
            if rank in rank_sites and rank_sites[rank] != site:
                raise ValueError("a ranked site maps to conflicting coordinates")
            rank_sites[rank] = site
        variants.append(sites)
    ordered = [rank_sites[rank][0] for rank in sorted(rank_sites)]
    if len(set(ordered)) != len(ordered):
        raise CoordinateCollision("distinct ranked sites share a coordinate")
    if ordered != sorted(ordered, reverse=strand == "-"):
        raise ValueError("site ranks disagree with strand direction")
    return variants


def alternating(sites: list[tuple[int, str]], pair: tuple[str, str]) -> bool:
    return (
        bool(sites)
        and len(sites) % 2 == 0
        and [symbol for _, symbol in sites] == list(pair) * (len(sites) // 2)
    )


def exons(sites: list[tuple[int, str]]) -> list[tuple[int, int]]:
    return [(sites[i][0], sites[i + 1][0]) for i in range(0, len(sites), 2)]


def disjoint(first: list[tuple[int, int]], second: list[tuple[int, int]]) -> bool:
    return all(
        a_end < b_start or b_end < a_start for a_start, a_end in first for b_start, b_end in second
    )


def classify(code: str, chain: str, strand: str) -> Classification:
    try:
        first, second = validate(code, chain, strand)
    except CoordinateCollision as exc:
        return Classification("Unresolved", str(exc), "U1_coordinate_collision", "needs_review")
    except ValueError as exc:
        return Classification("Unresolved", str(exc), "U0_invalid_code", "failed")

    if len(first) == len(second) == 1:
        if first[0][1] == second[0][1] == "^":
            return Classification("A5SS", "alternative_donor", "S1_donor", "passed")
        if first[0][1] == second[0][1] == "-":
            return Classification("A3SS", "alternative_acceptor", "S2_acceptor", "passed")

    if not first or not second:
        other = second if not first else first
        if alternating(other, ("-", "^")):
            count = len(other) // 2
            return Classification(
                "ES",
                f"{count}_skipped_exon" + ("s" if count != 1 else ""),
                "S3_zero_vs_exons",
                "passed",
            )
        if alternating(other, ("^", "-")):
            count = len(other) // 2
            return Classification(
                "IR",
                f"{count}_retained_intron" + ("s" if count != 1 else ""),
                "S4_zero_vs_introns",
                "passed",
            )
        return Classification("Complex", "zero_vs_mixed_structure", "C1_zero_mixed", "passed")

    if alternating(first, ("-", "^")) and alternating(second, ("-", "^")):
        if disjoint(exons(first), exons(second)):
            return Classification(
                "MXE",
                f"{len(first)//2}_vs_{len(second)//2}_exons",
                "S5_disjoint_alternative_exons",
                "passed",
            )
        return Classification(
            "Complex", "overlapping_alternative_exons", "C2_exon_overlap", "passed"
        )

    if len(first) == len(second) == 2 and all(
        [symbol for _, symbol in side] == ["^", "-"] for side in (first, second)
    ):
        return Classification(
            "Complex", "alternative_donor_and_acceptor", "C3_both_intron_ends", "passed"
        )
    return Classification(
        "Complex", "compound_or_noncanonical_splicing", "C4_other_valid_code", "passed"
    )


def asta_paths(code, chain, flanks, strand):
    label = classify(code, chain, strand)
    if label.validation != "passed":
        raise ValueError(label.detail)
    left, right = flanks.split(",")

    def flank(value):
        match = re.fullmatch(r"(\d+)([\^\-\[\]])", value)
        if not match:
            raise ValueError(f"invalid flanking site {value!r}")
        return int(match[1]), match[2]

    paths = []
    for variant in chain.split(","):
        sites = [flank(left), *chain_tokens(variant), flank(right)]
        coords = [x for x, _ in sites]
        if coords != sorted(set(coords), reverse=strand == "-"):
            raise ValueError("splice sites and flanks are out of order on the transcript strand")
        introns = sorted(
            (min(a, b) + 1, max(a, b) - 1)
            for (a, s), (b, t) in zip(sites, sites[1:])
            if (s, t) == ("^", "-")
        )
        paths.append(";".join(f"{a}-{b}" for a, b in introns))
    return label.unit, *paths
