"""Whole-chain reconstruction with original/corrected evidence arbitration."""
