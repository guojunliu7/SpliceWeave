"""Strand-specific branching paths, fragment phasing and independent end support."""

import csv
from bisect import bisect_left
from collections import Counter, defaultdict
from dataclasses import dataclass
from math import log1p
from statistics import median_low

from .mixed_assembly import Candidate, PathSpan, compatible, seed_paths


@dataclass
class Decision:
    model: Candidate
    score: float = 0.0
    lr_links: int = 0
    pair_links: int = 0
    phase_floor: int | None = None
    lr_observed_edges: int = 0
    missing_edge_evidence: tuple = ()
    missing_fork_lr: tuple = ()
    status: str = "accepted"
    parents: tuple = ()
    required: tuple = ()
    evidence: tuple = ()
    mate_context: tuple = ()


def load_ends(path):
    """Independent assays use stranded, 1-based nucleotide positions."""
    ends = defaultdict(list)
    if path:
        with open(path, newline="") as f:
            reader = csv.DictReader(f, delimiter="\t")
            fields = {"contig", "strand", "end_type", "position_1based", "source"}
            if not fields.issubset(reader.fieldnames or ()):
                raise ValueError(f"End evidence needs columns {sorted(fields)}")
            for r in reader:
                pos = int(r["position_1based"])
                if (
                    pos < 1
                    or not r["source"].strip()
                    or not r["contig"]
                    or r["strand"] not in ("+", "-")
                    or r["end_type"] not in ("5p", "3p")
                ):
                    raise ValueError(f"Invalid end evidence at line {reader.line_num}")
                ends[r["contig"], r["strand"], r["end_type"]].append((pos, r["source"]))
    return {key: sorted(set(values)) for key, values in ends.items()}


class PathGraph:
    def __init__(self, strand, long_reads, pairs):
        self.strand = strand
        self.depth = Counter()
        self.sr_depth = Counter()
        lr_edges, sr_edges = Counter(), Counter()
        starts, ends = defaultdict(list), defaultdict(list)
        long_counts, pair_counts = Counter(), Counter()
        for read in long_reads:
            self.depth.update(read.chain)
            lr_edges.update(zip(read.chain, read.chain[1:]))
            starts[read.chain[0]].append(read.start)
            ends[read.chain[-1]].append(read.end)
            if len(read.chain) > 1:
                long_counts[(read,)] += 1
        sr_start, sr_end = {}, {}
        for mates in pairs:
            spliced = [r for r in mates if r.strand == strand and r.chain]
            nodes = {j for r in spliced for j in r.chain}
            self.sr_depth.update(nodes)
            sr_edges.update(
                {edge for r in spliced for edge in zip(r.chain, r.chain[1:])}
            )
            for r in spliced:
                a, b = r.chain[0], r.chain[-1]
                sr_start[a] = min(sr_start.get(a, r.start), r.start)
                sr_end[b] = max(sr_end.get(b, r.end), r.end)
            if (
                len(mates) == 2
                and nodes
                and all(r.strand in (strand, ".") for r in mates)
            ):
                pair_counts[
                    tuple(
                        sorted(mates, key=lambda r: (r.start, r.end, r.chain, r.strand))
                    )
                ] += 1

        self.depth.update(self.sr_depth)
        self.left = {**sr_start, **{j: median_low(v) for j, v in starts.items()}}
        self.right = {**sr_end, **{j: median_low(v) for j, v in ends.items()}}
        self.pred, self.succ = defaultdict(set), defaultdict(set)
        for (a, b), votes in (lr_edges + sr_edges).items():
            if votes >= 2 and a[1] < b[0]:
                self.pred[b].add(a)
                self.succ[a].add(b)

        # A weak upstream/downstream edge can disappear even when an internal
        # junction remains. The adjacent exon bounds the provisional endpoint.
        adjacent_left, adjacent_right = {}, {}
        for a, b in lr_edges.keys() | sr_edges.keys():
            adjacent_left[b] = max(adjacent_left.get(b, a[1]), a[1])
            adjacent_right[a] = min(adjacent_right.get(a, b[0]), b[0])
        self.left = {**adjacent_left, **self.left}
        self.right = {**adjacent_right, **self.right}

        # A geometry specifies positive and negative introns. Unsequenced
        # space between mates imposes no negative constraint.
        self.patterns = defaultdict(Counter)
        ordered = sorted(self.depth)
        for assay, counts in (("lr", long_counts), ("pair", pair_counts)):
            for reads, n in counts.items():
                required = frozenset(j for r in reads for j in r.chain)
                forbidden = set()
                for r in reads:
                    observed = set(r.chain)
                    for j in ordered[: bisect_left(ordered, (r.end,))]:
                        if j[1] > r.start and j not in observed:
                            forbidden.add(j)
                start = min(r.start for r in reads)
                end = max(r.end for r in reads)
                if (
                    len(required) == 1
                    and sum(start <= a and b <= end for a, b in ordered) < 2
                ):
                    continue
                lo = start
                hi = end
                if not required & forbidden:
                    self.patterns[min(required)][
                        assay, required, frozenset(forbidden), lo, hi
                    ] += n

    def evaluate(self, chain, span=None):
        nodes = set(chain)
        start = span.start if span else self.left.get(chain[0], chain[0][0] - 1)
        end = span.end if span else self.right.get(chain[-1], chain[-1][1] + 1)
        marks = set()
        fork_edges = set()
        for i, (a, b) in enumerate(zip(chain, chain[1:])):
            if len(self.succ[a]) > 1:
                marks.add(i + 1)
                fork_edges.add(i)
            if len(self.pred[b]) > 1:
                marks.add(i)
                fork_edges.add(i)
        marks = sorted(marks)
        phase = [0] * max(0, len(marks) - 1)
        links = {"lr": [0] * (len(chain) - 1), "pair": [0] * (len(chain) - 1)}
        # A mate envelope votes for ordering, but a junction pair is directly
        # supported only when the same molecule actually observes both junctions.
        direct = {assay: [0] * (len(chain) - 1) for assay in links}
        totals = Counter()
        for j in chain:
            for (assay, req, forbidden, lo, hi), n in self.patterns.get(j, {}).items():
                if not req <= nodes or nodes & forbidden:
                    continue
                slack = 50 if assay == "lr" else 0
                if lo < start - slack or hi > end + slack:
                    continue
                indices = [i for i, (a, b) in enumerate(chain) if lo <= a and b <= hi]
                if len(indices) < 2:
                    continue
                totals[assay] += n
                for i in range(indices[0], indices[-1]):
                    links[assay][i] += n
                    if chain[i] in req and chain[i + 1] in req:
                        direct[assay][i] += n
                for k, (a, b) in enumerate(zip(marks, marks[1:])):
                    if chain[a] in req and chain[b] in req:
                        phase[k] += n
        # Means prevent long paths accumulating score solely through length.
        coverage = sum(log1p(self.depth[j]) for j in chain) / len(chain)
        score = coverage + sum(
            sum(map(log1p, values)) / max(1, len(values)) for values in links.values()
        )
        missing_edges = tuple(
            i
            for i, (lr, pairs) in enumerate(zip(direct["lr"], direct["pair"]))
            if lr == 0 and pairs < 2
        )
        missing_forks = tuple(i for i in sorted(fork_edges) if direct["lr"][i] == 0)
        return (
            score,
            totals["lr"],
            totals["pair"],
            min(phase, default=None),
            sum(n > 0 for n in direct["lr"]),
            missing_edges,
            missing_forks,
        )

    def extensions(self, width):
        """Bound alternatives separately at each convergence in genomic order."""
        partial = {}
        for j in sorted(self.succ.keys() | self.pred.keys()):
            paths = [p + (j,) for a in self.pred[j] for p in partial[a]] or [(j,)]
            if len(paths) > width:
                paths.sort(key=lambda p: (-self.evaluate(p)[0], p))
                paths = paths[:width]
            partial[j] = paths
            if not self.succ[j]:
                for p in paths:
                    if len(p) >= 2:
                        yield p


def mate_extensions(graph, spans, long_reads, short_reads, width):
    """Keep ordered mate anchors separate from sequenced adjacency evidence."""
    paths = set(spans)
    strand = graph.strand
    pairs = defaultdict(Counter)
    for mates in short_reads.values():
        if len(mates) != 2 or any(r.strand != strand or not r.chain for r in mates):
            continue
        left, right = sorted(mates, key=lambda r: r.start)
        a, b = left.chain[-1], right.chain[0]
        if a[1] < b[0] and left.end <= b[0] and right.start >= a[1]:
            if b not in graph.succ[a]:
                pairs[a, b][left, right] += 1
    pairs = {k: v for k, v in pairs.items() if sum(v.values()) >= 2}
    if not pairs:
        return [], {}

    # Capture route evidence before inserting the hypothetical skip edges.
    used = set(pairs)
    sequenced = defaultdict(set)
    for read in long_reads:
        for edge in zip(read.chain, read.chain[1:]):
            if edge in used:
                sequenced[edge].add((read, 50))
    for mates in short_reads.values():
        for read in mates:
            if read.strand != strand:
                continue
            for edge in zip(read.chain, read.chain[1:]):
                if edge in used:
                    sequenced[edge].add((read, 0))
    prefixes, suffixes = defaultdict(set), defaultdict(set)
    routes = defaultdict(set)
    lefts = {a for a, b in pairs}
    rights = {b for a, b in pairs}
    for path in paths:
        for i, j in enumerate(path):
            if j in lefts:
                prefixes[j].add(path[: i + 1])
                for k in range(i + 2, len(path)):
                    if (j, path[k]) in pairs:
                        routes[j, path[k]].add(path[i : k + 1])
            if j in rights:
                suffixes[j].add(path[i:])
    for a, b in pairs:
        graph.succ[a].add(b)
        graph.pred[b].add(a)

    def top(options):
        return (
            sorted(options, key=lambda p: (-graph.evaluate(p)[0], p))[:width]
            if len(options) > width
            else options
        )

    added = {
        p for p in graph.extensions(width) if any(e in pairs for e in zip(p, p[1:]))
    }
    for a, b in pairs:
        prefixes[a].add((a,))
        suffixes[b].add((b,))
        starts, ends = top(prefixes[a]), top(suffixes[b])
        for mid in top(routes[a, b] | {(a, b)}):
            added.update(top({l + mid[1:-1] + r for l in starts for r in ends}))
    decisions = []
    contexts = {}
    for path in sorted(added | paths):
        # Report the intervening route, including indirect alternatives already present.
        if not any(j in lefts for j in path):
            continue
        span = spans.get(path) or PathSpan(
            graph.left[path[0]], graph.right[path[-1]], strand, path
        )
        context = []
        for i, a in enumerate(path):
            if a not in lefts:
                continue
            for k in range(i + 1, len(path)):
                edge = (a, path[k])
                if edge not in pairs:
                    continue
                count = sum(
                    n
                    for mates, n in pairs[edge].items()
                    if all(compatible(r, span, 0) for r in mates)
                )
                witnesses = any(
                    compatible(r, span, slack) for r, slack in sequenced[edge]
                )
                context.append((i, k, count, witnesses))
        if not context:
            continue
        contexts[path] = tuple(context)
        if path in paths:
            continue
        # At least one anchor constraint must apply to this entire candidate.
        if not any(n >= 2 for _, _, n, _ in context):
            continue
        model = Candidate(
            span, "paired_local_route", 0, min(graph.sr_depth[j] for j in path), 0
        )
        d = Decision(model, *graph.evaluate(path, span))
        d.mate_context = tuple(context)
        if any(
            k == i + 1 and (n < 2 or not witnessed) for i, k, n, witnessed in context
        ):
            d.status = "mate_gap_adjacency_unresolved"
        else:
            apply_structure_gate(d)
        decisions.append(d)
    return decisions, contexts


def apply_structure_gate(d):
    if d.phase_floor == 0 and not d.model.exact:
        d.status = "unphased_branches"
    elif d.model.origin in ("graph_extension", "paired_local_route") and (
        not d.lr_observed_edges or d.missing_edge_evidence or d.missing_fork_lr
    ):
        d.status = "extension_needs_molecular_support"


def classify_nested(decisions, chrom, ends, tolerance):
    parents_by_node = defaultdict(list)
    for d in sorted(decisions, key=lambda d: -len(d.model.span.chain)):
        x = d.model.span
        if not x.chain or x.strand == "." or d.status != "accepted":
            continue
        parents, sides = [], set()
        for parent in parents_by_node[x.strand, x.chain[0]]:
            p = parent.chain
            i = p.index(x.chain[0])
            if len(p) == len(x.chain) or p[i : i + len(x.chain)] != x.chain:
                continue
            parents.append(parent)
            if i:
                sides.add("left")
            if i + len(x.chain) < len(p):
                sides.add("right")
        if parents:
            hits, required = set(), set()
            for side in sorted(sides):
                left = side == "left"
                kind = "5p" if left == (x.strand == "+") else "3p"
                required.add(kind)
                pos = x.start + 1 if left else x.end
                entries = ends.get((chrom, x.strand, kind), ())
                lo = bisect_left(entries, (pos - tolerance,))
                hi = bisect_left(entries, (pos + tolerance + 1,))
                for peak, source in entries[lo:hi]:
                    if (
                        left
                        and peak > x.chain[0][0]
                        or not left
                        and peak <= x.chain[-1][1]
                    ):
                        continue
                    # A peak shared with an extending parent does not distinguish this end.
                    extending = [
                        p
                        for p in parents
                        if (
                            p.chain[0] != x.chain[0]
                            if left
                            else p.chain[-1] != x.chain[-1]
                        )
                    ]
                    if all(
                        abs(peak - (p.start + 1 if left else p.end)) > tolerance
                        for p in extending
                    ):
                        hits.add((kind, peak, source))
            d.parents = tuple(sorted(p.chain for p in parents))
            d.evidence, d.required = tuple(sorted(hits)), tuple(sorted(required))
            d.status = (
                "end_supported_short_isoform"
                if required <= {h[0] for h in hits}
                else "fragment_or_short_isoform"
            )
        if d.status != "fragment_or_short_isoform":
            for j in x.chain:
                parents_by_node[x.strand, j].append(x)


def decide_paths(
    long_reads,
    short_reads,
    chrom="",
    ends=None,
    tolerance=20,
    width=16,
    paired_extension=False,
    paired_review=False,
):
    if width < 2 or tolerance < 0:
        raise ValueError("beam width must be >=2 and end tolerance >=0")
    seeds = seed_paths(long_reads, short_reads)
    models = {(m.span.strand, m.span.chain): m for m in seeds if m.span.chain}
    decisions = [Decision(m) for m in seeds if not m.span.chain or m.span.strand == "."]
    for strand in ("+", "-"):
        lr = [r for r in long_reads.values() if r.chain and r.strand == strand]
        sr = (
            mates
            for mates in short_reads.values()
            if any(r.strand == strand and r.chain for r in mates)
        )
        graph = PathGraph(strand, lr, sr)
        paths = {chain for s, chain in models if s == strand}
        paths.update(graph.extensions(width))
        for chain in sorted(paths):
            m = models.get((strand, chain))
            if m is None:
                span = PathSpan(
                    graph.left[chain[0]], graph.right[chain[-1]], strand, chain
                )
                m = Candidate(
                    span, "graph_extension", 0, min(graph.sr_depth[j] for j in chain), 0
                )
            d = Decision(m, *graph.evaluate(chain, m.span))
            apply_structure_gate(d)
            decisions.append(d)
        if paired_extension or paired_review:
            spans = {
                d.model.span.chain: d.model.span
                for d in decisions
                if d.model.span.strand == strand and d.model.span.chain
            }
            extra, contexts = mate_extensions(graph, spans, lr, short_reads, width)
            for d in decisions:
                if d.model.span.strand == strand:
                    d.mate_context = contexts.get(d.model.span.chain, ())
            if paired_review:
                for d in extra:
                    if d.status == "accepted":
                        d.status = "paired_route_for_review"
            decisions.extend(extra)
    classify_nested(decisions, chrom, ends or {}, tolerance)
    return sorted(
        decisions,
        key=lambda d: (
            d.model.span.start,
            d.model.span.end,
            d.model.span.strand,
            d.model.span.chain,
        ),
    )
