"""Truth-blind arbitration of original and corrected whole-read chains.

Read identifiers are never duplicated. Each eligible read chooses one geometry;
candidate decisions are rebuilt afterwards. No posterior probability is implied.
"""
from collections import defaultdict,Counter
from . import structure_evidence as core

def choose(raw,corrected,short,chrom,annotation,witnesses,mode):
    baseline=core.select(corrected,short,chrom,annotation,witnesses)
    if mode=='corrected_only':return baseline,corrected,[]
    original=core.select(raw,short,chrom,annotation,witnesses)
    allowed={(d.model.span.strand,d.model.span.chain) for d in original if d.status=='accepted'}
    if mode=='naive_union':
        union={(d.model.span.strand,d.model.span.chain):d for d in baseline if d.status=='accepted'}
        for d in original:
            if d.status=='accepted':union.setdefault((d.model.span.strand,d.model.span.chain),d)
        # Candidate-union control only. No duplicated read table or abundance fit.
        return list(union.values()),corrected,[]
    assert mode in ['evidence_replay','replay_no_SR']
    groups=defaultdict(list);sr=Counter()
    for name,r in raw.items():groups[r.strand,r.chain].append(name)
    for mates in short.values():sr.update({(r.strand,j) for r in mates for j in r.chain if r.strand in ('+','-')})
    counts={k:{j:sum(j in witnesses.get((chrom,name[1]),set()) for name in names) for j in k[1]} for k,names in groups.items()}
    resolved=dict(corrected);audit=[]
    for name,r in raw.items():
        c=corrected[name]
        if r.chain==c.chain:continue
        key=r.strand,r.chain;changed=set(r.chain)-set(c.chain)
        own=witnesses.get((chrom,name[1]),set())
        reason='retained_corrected'
        if r.strand not in ('+','-') or r.strand!=c.strand or len(r.chain)!=len(c.chain) or not changed:
            reason='unresolved_geometry'
        elif key not in allowed:reason='raw_chain_not_accepted'
        elif len(groups[key])<2:reason='insufficient_same_chain_reads'
        elif not changed<=own:reason='moved_site_lacks_own_exact_flank'
        elif any(counts[key][j]<2 for j in changed):reason='insufficient_same_chain_perfect_witnesses'
        elif mode!='replay_no_SR' and any(sr[r.strand,j]<3 for j in changed):reason='insufficient_short_fragment_support'
        else:resolved[name]=r;reason='restored_original_geometry'
        audit.append(dict(contig=chrom,read_group=name[0],read_id=name[1],strand=r.strand,
                          raw_chain=r.chain,corrected_chain=c.chain,changed_raw_junctions=tuple(sorted(changed)),
                          same_chain_reads=len(groups[key]),own_exact_moved_sites=len(changed&own),
                          min_same_chain_perfect=min((counts[key][j] for j in changed),default=0),
                          min_short_fragments=min((sr[r.strand,j] for j in changed),default=0),decision=reason))
    assert set(resolved)==set(raw)==set(corrected)
    return core.select(resolved,short,chrom,annotation,witnesses),resolved,audit
