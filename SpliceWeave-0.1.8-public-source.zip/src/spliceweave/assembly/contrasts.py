import pysam
from .mixed_assembly import alignment_span
from .sequence_arbitration import compare_window

def extract(s,overlay,witnesses):
 out={};stats=dict(eligible=0,changed=0,scorable_junctions=0,raw_better=0,tied=0,corrected_better=0)
 with pysam.AlignmentFile(s['long_bam'],'rb') as bam,pysam.FastaFile(s['reference']) as ref:
  for r in bam:
   if r.flag&3844 or r.mapping_quality<20 or (r.has_tag('NH') and r.get_tag('NH')!=1) or not r.query_sequence:continue
   raw=alignment_span(r,1)
   if raw is None:continue
   c=overlay.get((r.reference_name,r.query_name));stats['eligible']+=1
   if c is None or raw.chain==c.chain or len(raw.chain)!=len(c.chain):continue
   stats['changed']+=1;own=witnesses.get((r.reference_name,r.query_name),set());p=r.reference_start;q=0;idx=0;seq=r.query_sequence.upper();scores={};ops=r.cigartuples or []
   for i,(op,n) in enumerate(ops):
    if op==3:
     old=(p,p+n);new=c.chain[idx];idx+=1
     if old!=new and old in own and i>0 and i+1<len(ops) and ops[i-1][0] in (0,7,8) and ops[i+1][0] in (0,7,8):
      L=min(20,ops[i-1][1]);R=min(20,ops[i+1][1]);lo=p-L;hi=p+n+R
      if L>=10 and R>=10 and lo<new[0]<new[1]<hi and q>=L and q+R<=len(seq):
       costs=compare_window(seq[q-L:q+R],ref.fetch(r.reference_name,lo,p).upper(),ref.fetch(r.reference_name,p+n,hi).upper(),ref.fetch(r.reference_name,lo,new[0]).upper(),ref.fetch(r.reference_name,new[1],hi).upper())
       if costs is not None:
        scores[old]=costs;stats['scorable_junctions']+=1;stats[['raw_better','tied','corrected_better'][0 if costs[0]<costs[1] else 1 if costs[0]==costs[1] else 2]]+=1
    if op in (0,1,4,7,8):q+=n
    if op in (0,2,3,7,8):p+=n
   if scores:out[r.reference_name,r.get_tag('RG') if r.has_tag('RG') else '',r.query_name]=scores
 return out,stats
