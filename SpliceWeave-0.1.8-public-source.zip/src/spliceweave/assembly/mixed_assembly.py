"""Molecule-supported splice-chain assembly, without reference transcript annotation.

Coordinates are half-open internally. Candidates carry independent observations of
whole chains or a uniquely resolved overlap between two observed chain segments.
"""

from collections import Counter, defaultdict
from dataclasses import dataclass
from heapq import merge
from statistics import median_low

import pysam


@dataclass(frozen=True, slots=True)
class PathSpan:
    start: int
    end: int
    strand: str
    chain: tuple


@dataclass
class Candidate:
    span: PathSpan
    origin: str
    exact: int
    min_sr: int
    witnesses: int


def alignment_span(read, anchor):
    pos = read.reference_start
    introns = []
    ops = read.cigartuples or ()
    for i, (op, length) in enumerate(ops):
        if op == 3:
            if i == 0 or i + 1 == len(ops):
                return None
            for adjacent, size in (ops[i - 1], ops[i + 1]):
                if adjacent not in (0, 7, 8) or size < anchor:
                    return None
            introns.append((pos, pos + length))
        if op in (0, 2, 3, 7, 8):
            pos += length
    if pos <= read.reference_start:
        return None
    strand = "."
    if read.has_tag("XS") and read.get_tag("XS") in ("+", "-"):
        strand = read.get_tag("XS")
    elif read.has_tag("ts") and read.get_tag("ts") in ("+", "-"):
        strand = read.get_tag("ts")
        if read.is_reverse:
            strand = "-" if strand == "+" else "+"
    return PathSpan(read.reference_start, pos, strand, tuple(introns))


def alignments(handle, assay, anchor, mapq):
    last = (-1, -1)
    for read in handle:
        if read.flag & 3844 or read.mapping_quality < mapq:
            continue
        if read.has_tag("NH") and read.get_tag("NH") != 1:
            continue
        coord = read.reference_id, read.reference_start
        if coord < last:
            raise ValueError(f"{assay} BAM is not coordinate sorted")
        last = coord
        span = alignment_span(read, anchor)
        if span is None:
            continue
        group = read.get_tag("RG") if read.has_tag("RG") else ""
        extent = span.end
        if assay == "short" and read.is_paired and not read.mate_is_unmapped:
            if read.next_reference_id != read.reference_id or not read.is_proper_pair:
                continue
            extent = max(extent, read.next_reference_start + 1)
        yield coord, assay, (group, read.query_name), span, extent


def loci(long_handle, short_handle, anchor, mapq, long_anchor=None):
    if (
        long_handle.references != short_handle.references
        or long_handle.lengths != short_handle.lengths
    ):
        raise ValueError(
            "BAM reference dictionaries must match in name, length and order"
        )
    current = None
    end = -1
    long_reads, short_reads = {}, defaultdict(list)
    streams = [
        alignments(long_handle, "long", anchor if long_anchor is None else long_anchor, mapq),
        alignments(short_handle, "short", anchor, mapq),
    ]
    for (tid, start), assay, name, span, extent in merge(*streams, key=lambda x: x[0]):
        if current != tid or start >= end:
            if long_reads or short_reads:
                yield long_handle.references[current], long_reads, short_reads
            current = tid
            end = -1
            long_reads = {}
            short_reads = defaultdict(list)
        end = max(end, extent)
        if assay == "long":
            if name in long_reads:
                raise ValueError(f"Duplicate primary long-read name in locus: {name}")
            long_reads[name] = span
        else:
            short_reads[name].append(span)
    if long_reads or short_reads:
        yield long_handle.references[current], long_reads, short_reads


def supported_paths(long_reads, short_reads):
    from .branch_paths import decide_paths

    return [
        d.model
        for d in decide_paths(long_reads, short_reads)
        if d.status in ("accepted", "end_supported_short_isoform")
    ]


def seed_paths(long_reads, short_reads):
    """Short fragments vote once per junction; retain complete long-read linkage."""
    short_support = Counter()
    for mates in short_reads.values():
        short_support.update(
            {(m.strand, j) for m in mates for j in m.chain if m.strand != "."}
        )
    obs = defaultdict(list)
    for span in long_reads.values():
        obs[span.strand, span.chain].append(span)
    candidates = []
    for (strand, chain), reads in sorted(obs.items()):
        if not chain:
            # Single-exon models require two intersecting long-read intervals.
            cluster = []
            common_end = -1
            for r in sorted(reads, key=lambda r: (r.start, r.end)):
                if r.start >= common_end:
                    if len(cluster) >= 2:
                        candidates.append(mono_model(cluster))
                    cluster = []
                    common_end = r.end
                common_end = min(common_end, r.end)
                cluster.append(r)
            if len(cluster) >= 2:
                candidates.append(mono_model(cluster))
            continue
        sr = min(short_support[strand, j] for j in chain)
        if len(reads) < 2 and sr < 2:
            continue
        # Robust representative of aligned boundaries; these are provisional ends.
        span = PathSpan(
            median_low([r.start for r in reads]),
            median_low([r.end for r in reads]),
            strand,
            chain,
        )
        candidates.append(Candidate(span, "observed_chain", len(reads), sr, 0))

    # Exact terminal overlap: require reciprocal unique partners. Enumerating
    # proper prefixes/suffixes avoids forming every path through a splice graph.
    observed = {(m.span.strand, m.span.chain): m for m in candidates if m.span.chain}
    prefixes = defaultdict(set)
    for key, m in observed.items():
        if m.exact < 2 or m.min_sr < 2 or key[0] == ".":
            continue
        for i in range(1, len(key[1])):
            prefixes[key[0], key[1][:i]].add(key)
    outgoing, incoming = defaultdict(set), defaultdict(set)
    for left, lm in observed.items():
        if lm.exact < 2 or lm.min_sr < 2 or left[0] == ".":
            continue
        for i in range(1, len(left[1])):
            suffix = left[1][i:]
            for right in prefixes.get((left[0], suffix), ()):
                outgoing[left].add((right, len(suffix)))
                incoming[right].add(left)
    inferred = {}
    for left, partners in outgoing.items():
        if len(partners) != 1:
            continue
        right, n = next(iter(partners))
        if len(incoming[right]) != 1:
            continue
        lm, rm = observed[left], observed[right]
        # The partial reads must end/start within the actual shared exon span.
        if lm.span.end > right[1][n][0] or rm.span.start < left[1][-n - 1][1]:
            continue
        chain = left[1] + right[1][n:]
        key = left[0], chain
        if key in obs:
            continue
        span = PathSpan(lm.span.start, rm.span.end, left[0], chain)
        witness = min(lm.exact, rm.exact)
        proposal = Candidate(
            span, "unique_overlap", 0, min(lm.min_sr, rm.min_sr), witness
        )
        if key not in inferred or inferred[key].witnesses < witness:
            inferred[key] = proposal
    supported = candidates + list(inferred.values())
    seed_keys = {(m.span.strand, m.span.chain) for m in supported}
    supported.extend(
        m
        for m in short_paths(short_reads, short_support)
        if (m.span.strand, m.span.chain) not in seed_keys
    )
    return sorted(
        supported, key=lambda m: (m.span.start, m.span.end, m.span.strand, m.span.chain)
    )


def short_paths(short_reads, support):
    """Compact paths of well-supported introns using only sequenced adjacencies.

    An edge needs two distinct fragments witnessing the same pair of consecutive
    junctions on a single alignment. Stop at all branches; never cross a mate gap.
    Nested paths are retained for subsequent end-evidence adjudication.
    """
    edges = Counter()
    starts = defaultdict(Counter)
    ends = defaultdict(Counter)
    for mates in short_reads.values():
        votes = set()
        for read in mates:
            if not read.chain or read.strand == ".":
                continue
            first = (read.strand, read.chain[0])
            last = (read.strand, read.chain[-1])
            starts[first][read.start] += 1
            ends[last][read.end] += 1
            votes.update(
                ((read.strand, a), (read.strand, b))
                for a, b in zip(read.chain, read.chain[1:])
            )
        edges.update(votes)
    nodes = {key for key, n in support.items() if n >= 3}
    successors = defaultdict(set)
    predecessors = defaultdict(set)
    for (a, b), n in edges.items():
        if n >= 2 and a in nodes and b in nodes:
            successors[a].add(b)
            predecessors[b].add(a)
    links = {}
    for a, targets in successors.items():
        if len(targets) == 1:
            b = next(iter(targets))
            if len(predecessors[b]) == 1:
                links[a] = b
    result = []
    for start in sorted(nodes - set(links.values())):
        path = [start]
        while path[-1] in links:
            path.append(links[path[-1]])
        strand = start[0]
        chain = tuple(j for s, j in path)
        left, right = starts[start], ends[path[-1]]
        if not left or not right:
            continue
        # Furthest boundaries actually reached by short reads; provisional ends.
        span = PathSpan(min(left), max(right), strand, chain)
        result.append(
            Candidate(span, "short_read_path", 0, min(support[k] for k in path), 0)
        )
    return result


def mono_model(reads):
    return Candidate(
        PathSpan(
            median_low([r.start for r in reads]),
            median_low([r.end for r in reads]),
            reads[0].strand,
            (),
        ),
        "single_exon",
        len(reads),
        0,
        0,
    )


def compatible(read, model, slack):
    """Every skipped AND retained intron inside the aligned span must agree."""
    if read.strand != "." and model.strand != "." and read.strand != model.strand:
        return False
    if read.start < model.start - slack or read.end > model.end + slack:
        return False
    if model.start >= read.end or model.end <= read.start:
        return False
    crossed = tuple(j for j in model.chain if j[0] < read.end and j[1] > read.start)
    return crossed == read.chain


def equivalence_classes(candidates, long_reads, short_reads):
    idx = defaultdict(set)
    for i, m in enumerate(candidates):
        for j in m.span.chain:
            idx[j].add(i)
    universe = set(range(len(candidates)))

    # Duplicate fragment geometries are frequent in short-read data.
    def collect(geometries, slack):
        classes = Counter()
        for reads, n in geometries.items():
            junctions = {j for r in reads for j in r.chain}
            possible = (
                set.intersection(*(idx[j] for j in junctions))
                if junctions
                else universe
            )
            matches = tuple(
                i
                for i in sorted(possible)
                if all(compatible(r, candidates[i].span, slack) for r in reads)
            )
            if matches:
                classes[matches] += n
        return classes

    lr = Counter((r,) for r in long_reads.values())
    sr = Counter(
        tuple(sorted(mates, key=lambda r: (r.start, r.end, r.chain, r.strand)))
        for mates in short_reads.values()
    )
    return collect(lr, 50), collect(sr, 0)


def fit_abundance(lengths, long_classes, short_classes, fragment_length, diagnostics=None):
    """Poisson EM, sampling exposure 1 for LR, effective length for SR.

    Conditional on its sequenced geometry, a compatible fragment contributes a
    likelihood proportional to molecule abundance. Library scales are estimated
    jointly. Counts assigned by each E step conserve that library's mapped mass.
    """
    import numpy as np
    from scipy.sparse import csr_matrix

    size = len(lengths)
    if not size:
        return [], [], []

    def matrix(classes):
        row = []
        col = []
        counts = []
        for members, n in classes.items():
            row.extend([len(counts)] * len(members))
            col.extend(members)
            counts.append(n)
        return csr_matrix(
            (np.ones(len(row)), (row, col)), shape=(len(counts), size)
        ), np.array(counts)

    lr, nl = matrix(long_classes)
    sr, ns = matrix(short_classes)
    effective = np.maximum(1, np.asarray(lengths) - fragment_length + 1)
    theta = np.ones(size) / size

    def distribute(mat, counts):
        denom = mat @ theta
        return theta * (
            mat.T @ np.divide(counts, denom, out=np.zeros_like(denom), where=denom > 0)
        )

    for iteration in range(1, 501):
        a, b = distribute(lr, nl), distribute(sr, ns)
        exposure = nl.sum() + ns.sum() * effective / np.dot(theta, effective)
        update = (a + b) / np.maximum(exposure, 1e-300)
        if not update.sum():
            if diagnostics is not None:
                diagnostics.update(iterations=iteration, converged=False, status="no_mass")
            return np.zeros(size), a, b
        update /= update.sum()
        delta = np.abs(update - theta).sum()
        theta = update
        if delta < 1e-8:
            break
    if diagnostics is not None:
        diagnostics.update(iterations=iteration, converged=bool(delta < 1e-8), final_l1=float(delta))
    return 1e6 * theta, distribute(lr, nl), distribute(sr, ns)
