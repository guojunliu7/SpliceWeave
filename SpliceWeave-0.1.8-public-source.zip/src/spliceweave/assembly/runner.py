"""Portable released entry point; frozen decisions with explicit input provenance."""
import csv
import gzip
import hashlib
import json
import tempfile
from collections import Counter
from functools import lru_cache
from pathlib import Path

import pysam
from .. import __version__
from ..correct import Read
from . import mixed_assembly as mx
from .chain_conflict import choose
from .structure_evidence import annotation, select
from .sequence_arbitration import arbitrate, SIGNALS
from .contrasts import extract
from .witnesses import build

ALGORITHM_ID = 'sw-chain-family-arbitration-v2'

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''):
            h.update(b)
    return h.hexdigest()

def read_bed(path):
    overlay = {}
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt') as f:
        for line in f:
            if not line.strip() or line.startswith('#'):
                continue
            r = Read.parse(line)
            key = (r.fields[0], r.fields[3])
            if key in overlay:
                raise ValueError(f'Duplicate corrected BED ID: {key}')
            overlay[key] = mx.PathSpan(r.start, r.end, r.fields[5], tuple(r.junctions))
    return overlay

def tsv(path, fields):
    f = gzip.open(path, 'wt', newline='') if str(path).endswith('.gz') else path.open('w', newline='')
    w = csv.DictWriter(f, fieldnames=fields, delimiter='\t', extrasaction='ignore')
    w.writeheader()
    return f, w

def run_assembly(args):
    out = args.out_dir
    if out.exists() or out.is_symlink():
        raise FileExistsError(f'Choose a new output directory: {out}')
    inputs = {k: Path(getattr(args, k)) for k in ['long_bam', 'short_bam', 'reference', 'gtf', 'corrected_bed']}
    for path in inputs.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    ann = annotation(inputs['gtf'])
    overlay = read_bed(inputs['corrected_bed'])
    # The BED and exact-flank interfaces key reads by (contig, name). Reject
    # collisions across RGs rather than silently assign another molecule's evidence.
    seen = set()
    with pysam.AlignmentFile(inputs['long_bam'], 'rb') as bam:
        for read in bam:
            if read.flag & 3844 or read.mapping_quality < 20 or (read.has_tag('NH') and read.get_tag('NH') != 1):
                continue
            key = read.reference_name, read.query_name
            if key in seen:
                raise ValueError(f'Long-read IDs must be unique per contig, including across read groups: {key}')
            seen.add(key)
    witness_data = build(str(inputs['long_bam']), str(inputs['reference']))
    witnesses = {tuple(k.split('\t')): set(map(tuple, v)) for k, v in witness_data['witnesses'].items()}
    features, feature_counts = extract({k: str(v) for k, v in inputs.items()}, overlay, witnesses)
    counts = Counter()
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.sw-chain-', dir=out.parent) as tmp:
        dest = Path(tmp) / 'result'
        dest.mkdir()
        (dest / 'witnesses.json').write_text(json.dumps(witness_data, separators=(',', ':')) + '\n')
        fields = {
            'chain_decisions.tsv': ['contig', 'strand', 'chain', 'status', 'support', 'origin'],
            'geometry_decisions.tsv.gz': ['contig', 'read_group', 'read_id', 'chain', 'decision', 'chain_reads', 'family_raw_count', 'family_runner_count', 'family_dominance', 'min_strict_support', 'raw_vs_corrected_costs'],
            'direction_decisions.tsv.gz': ['contig', 'read_group', 'read_id', 'chain', 'old_strand', 'new_strand', 'decision', 'reason'],
            'baseline_decisions.tsv.gz': ['contig', 'read_group', 'read_id', 'strand', 'raw_chain', 'corrected_chain', 'changed_raw_junctions', 'same_chain_reads', 'own_exact_moved_sites', 'min_same_chain_perfect', 'min_short_fragments', 'decision'],
            'read_evidence.tsv.gz': ['contig', 'read_group', 'read_id', 'raw_chain', 'corrected_chain', 'final_chain', 'raw_strand', 'corrected_strand', 'final_strand'],
        }
        streams = {n: tsv(dest / n, fs) for n, fs in fields.items()}
        try:
            with pysam.AlignmentFile(inputs['long_bam'], 'rb', threads=2) as lr, pysam.AlignmentFile(inputs['short_bam'], 'rb', threads=2) as sr, pysam.FastaFile(inputs['reference']) as ref, (dest / 'models.gtf').open('w') as gtf:
                @lru_cache(maxsize=50000)
                def motif(ch, a, b):
                    return SIGNALS.get((ref.fetch(ch, a, a+2) + ref.fetch(ch, b-2, b)).upper())
                for ch, raw, short in mx.loci(lr, sr, 8, 20, long_anchor=1):
                    cor = {k: overlay.get((ch, k[1]), v) for k, v in raw.items()}
                    for key, r in raw.items():
                        c = cor[key]
                        if (r.start, r.end, r.strand, len(r.chain)) != (c.start, c.end, c.strand, len(c.chain)):
                            raise ValueError(f'Corrected BED must preserve read ends, strand and intron count: {(ch, key)}')
                        counts['overlay_matched' if (ch, key[1]) in overlay else 'retained_without_overlay'] += 1
                    base, resolved, ba = choose(raw, cor, short, ch, ann, witnesses, 'evidence_replay')
                    final, ga, sa = arbitrate(raw, cor, resolved, short, ch, ann, witnesses, features, lambda j: motif(ch, *j), args.mode)
                    decisions = base if args.mode == 'baseline' else select(final, short, ch, ann, witnesses)
                    counts['loci'] += 1
                    counts['input_molecules'] += len(raw)
                    counts['output_molecules'] += len(final)
                    for name, rows in [('baseline_decisions.tsv.gz', ba), ('geometry_decisions.tsv.gz', ga), ('direction_decisions.tsv.gz', sa)]:
                        streams[name][1].writerows(rows)
                    for key, r in raw.items():
                        c, f = cor[key], final[key]
                        streams['read_evidence.tsv.gz'][1].writerow(dict(contig=ch, read_group=key[0], read_id=key[1], raw_chain=r.chain, corrected_chain=c.chain, final_chain=f.chain, raw_strand=r.strand, corrected_strand=c.strand, final_strand=f.strand))
                    for d in decisions:
                        x = d.model.span
                        streams['chain_decisions.tsv'][1].writerow(dict(contig=ch, strand=x.strand, chain=x.chain, status=d.status, support=d.lr_links, origin=d.model.origin))
                        counts['status:' + d.status] += 1
                        if d.status != 'accepted':
                            continue
                        tid = 'SW.' + hashlib.sha256(repr((ch, x)).encode()).hexdigest()[:20]
                        at = f'gene_id "SW.{ch}.{x.start}.{x.strand}"; transcript_id "{tid}"; assembly_origin "{d.model.origin}";'
                        for start, end in zip([x.start]+[j[1] for j in x.chain], [j[0] for j in x.chain]+[x.end]):
                            if start >= end:
                                raise ValueError('Nonpositive exon in reconstructed model')
                            print(ch, 'SpliceWeave', 'exon', start+1, end, '.', x.strand, '.', at, sep='\t', file=gtf)
        finally:
            for stream, _ in streams.values():
                stream.close()
        if counts['input_molecules'] != counts['output_molecules']:
            raise ValueError('Read accounting failed')
        info = dict(version=__version__, algorithm=ALGORITHM_ID, mode=args.mode, baseline='evidence_replay', counts=dict(counts), contrast_features=feature_counts, inputs={k: str(p.resolve()) for k,p in inputs.items()}, input_sha256={k: digest(p) for k,p in inputs.items()}, parameters=dict(mapq=20, long_anchor=1, short_anchor=8, exact_flank=10, sequence_window_max=20, family_threshold='ln(100)', min_original_chain_reads=2, min_exact_witnesses=2, baseline_min_short_fragments=3), calibrated_probability=False, endpoint_validation=False, bam_modified=False)
        (dest / 'summary.json').write_text(json.dumps(info, indent=2) + '\n')
        if out.exists():
            raise FileExistsError(out)
        dest.rename(out)
    return info
