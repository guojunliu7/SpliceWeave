"""Independent whole-molecule arbitration, not a calibrated probability model.
Compare original and proposed junctions using the SAME observed query window and
fixed outer genomic anchors. Direction is constrained by splice motifs and known
junctions; contradictory sites never become majority votes. No truth/tool output.
"""
from collections import Counter,defaultdict
from math import log
from functools import lru_cache
from .mixed_assembly import PathSpan
from .structure_evidence import select,ends_fit_full
MODES=['baseline','sequence_only','direction_only','joint','no_sequence_gate','no_family_gate']
SIGNALS={'GTAG':'+','GCAG':'+','ATAC':'+','CTAC':'-','CTGC':'-','GTAT':'-'}
@lru_cache(maxsize=16384)
def distance(a,b):
 if a==b:return 0
 row=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  nxt=[i]
  for j,y in enumerate(b,1):nxt.append(min(row[j]+1,nxt[-1]+1,row[j-1]+(x!=y)))
  row=nxt
 return row[-1]
def compare_window(query,raw_left,raw_right,alt_left,alt_right):
 """All strings are anchored to the same original exon-window boundaries."""
 if not query or set(query+raw_left+raw_right+alt_left+alt_right)-set('ACGT'):return None
 return distance(query,raw_left+raw_right),distance(query,alt_left+alt_right)
def direction(span,chrom,annot,sj_annot,motif,annotation_only=False):
 whole={st for (ch,st,c),models in annot.items() if ch==chrom and c==span.chain and any(ends_fit_full(span,p) for p,t in models)}
 if annotation_only:return (next(iter(whole)) if len(whole)==1 else None),'annotation_only'
 votes=[];ambiguous=0
 for j in span.chain:
  signs=set(sj_annot.get(j,set()));ms=motif(j)
  if ms:signs.add(ms)
  if len(signs)==1:votes.append(next(iter(signs)))
  elif len(signs)>1:ambiguous+=1
 if len(set(votes))!=1:return None,'conflicting_or_absent_site_direction'
 target=votes[0]
 if len(votes)>=2 or (whole=={target} and len(votes)>=1):return target,'coherent_site_constraints'
 return None,'insufficient_informative_sites'
def arbitrate(raw,corrected,baseline_resolved,short,chrom,annot,witnesses,features,motif,mode):
 assert mode in MODES
 if mode=='baseline':return baseline_resolved,[],[]
 res=dict(baseline_resolved);ga=[];sa=[]
 if mode in ['sequence_only','joint','no_sequence_gate','no_family_gate']:
  ds=select(raw,short,chrom,annot,witnesses);allowed={(d.model.span.strand,d.model.span.chain) for d in ds if d.status=='accepted'}
  groups=defaultdict(list);families=defaultdict(Counter)
  for name,r in raw.items():families[corrected[name].chain][r.chain]+=1
  for name,r in raw.items():groups[r.strand,r.chain].append(name)
  strict=Counter();perfect=Counter()
  for k,names in groups.items():
   for name in names:
    own=witnesses.get((chrom,name[1]),set());perfect.update((k,j) for j in k[1] if j in own)
    f=features.get((chrom,name[0],name[1]),{})
    strict.update((k,j) for j,(a,b) in f.items() if a<b and j in own)
  for name,r in raw.items():
   current=res[name];c=corrected[name]
   if r.chain==current.chain:continue
   key=r.strand,r.chain;family=families[c.chain];own_count=family[r.chain];runner=max((n for chain,n in family.items() if chain!=r.chain),default=0);dominance=(own_count-runner)**2/(2*(own_count+runner)) if own_count>runner else 0;changed=set(r.chain)-set(c.chain);own=witnesses.get((chrom,name[1]),set());f=features.get((chrom,name[0],name[1]),{});reason='retained_baseline'
   if r.strand!=current.strand or len(r.chain)!=len(c.chain) or len(r.chain)<2 or not changed:reason='unsupported_geometry'
   elif key not in allowed:reason='original_chain_not_accepted'
   elif len(groups[key])<2 or not changed<=own or any(perfect[key,j]<2 for j in changed):reason='insufficient_original_exact_witnesses'
   elif mode!='no_family_gate' and dominance<log(100):reason='insufficient_correction_family_dominance'
   elif mode!='no_sequence_gate' and any(j not in f or f[j][0]>=f[j][1] or strict[key,j]<2 for j in changed):reason='no_replicated_sequence_advantage'
   else:res[name]=r;reason='preserved_original_chain'
   ga.append(dict(contig=chrom,read_group=name[0],read_id=name[1],chain=r.chain,decision=reason,chain_reads=len(groups[key]),family_raw_count=own_count,family_runner_count=runner,family_dominance=dominance,min_strict_support=min((strict[key,j] for j in changed),default=0),raw_vs_corrected_costs=[(j,f.get(j)) for j in sorted(changed)]))
 if mode in ['direction_only','joint','no_sequence_gate','no_family_gate','direction_annotation_only']:
  sja=defaultdict(set);by_chain=defaultdict(dict)
  for (ch,st,c) in annot:
   if ch==chrom:
    by_chain[c][ch,st,c]=annot[ch,st,c]
    for j in c:sja[j].add(st)
  cached={}
  for name,r in list(res.items()):
   if len(r.chain)<2:continue
   key=(r.start,r.end,r.chain)
   if key not in cached:cached[key]=direction(r,chrom,by_chain[r.chain],sja,motif,mode=='direction_annotation_only')
   target,why=cached[key]
   if target in ['+','-'] and target!=r.strand:
    res[name]=PathSpan(r.start,r.end,target,r.chain);decision='changed_strand'
   else:decision='unchanged'
   sa.append(dict(contig=chrom,read_group=name[0],read_id=name[1],chain=r.chain,old_strand=r.strand,new_strand=res[name].strand,decision=decision,reason=why))
 assert set(res)==set(raw)==set(corrected)==set(baseline_resolved)
 return res,ga,sa
