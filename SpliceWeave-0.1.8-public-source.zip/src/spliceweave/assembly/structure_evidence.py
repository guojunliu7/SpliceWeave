"""Experimental molecule-anchored chain selection, independently implemented in Python.

Known chains and novel chains have distinct evidence contracts. Annotation is a
prior, never evidence of expression. Novel junction witnesses must belong to
reads observing that same entire chain; pooled junction depth cannot create it.
Scores and status labels are not calibrated probabilities or molecular truth.
"""
from collections import Counter,defaultdict
from statistics import median_low
import re,gzip
from .mixed_assembly import PathSpan,Candidate
from .branch_paths import Decision

def annotation(path):
 tx={};op=gzip.open if str(path).endswith('.gz') else open
 with op(path,'rt') as f:
  for line in f:
   if line.startswith('#'):continue
   v=line.rstrip().split('\t')
   if len(v)!=9 or v[2]!='exon':continue
   a=dict(re.findall(r'(\w+) "([^\"]*)"',v[8]));tid=a.get('transcript_id')
   if tid:tx.setdefault((v[0],v[6],tid),[]).append((int(v[3])-1,int(v[4])))
 out=defaultdict(list)
 for (ch,st,tid),es in tx.items():
  es=sorted(set(es));chain=tuple((x[1],y[0]) for x,y in zip(es,es[1:]))
  if chain:out[ch,st,chain].append((PathSpan(es[0][0],es[-1][1],st,chain),tid))
 return out

def ends_fit_full(read,model,slack=35):
 return read.start>=model.start-slack and read.end<=model.end+slack

def fragment_fit(short,parent,internal_slack=6,terminal_slack=35):
 """Does some embedding explain this observed short-chain span as a fragment?"""
 a,b=short.chain,parent.chain
 if len(a)>=len(b) or short.strand!=parent.strand:return False
 for i in range(len(b)-len(a)+1):
  if b[i:i+len(a)]!=a:continue
  left=parent.start if i==0 else b[i-1][1]
  right=parent.end if i+len(a)==len(b) else b[i+len(a)][0]
  lslack=terminal_slack if i==0 else internal_slack
  rslack=terminal_slack if i+len(a)==len(b) else internal_slack
  if short.start>=left-lslack and short.end<=right+rslack:return True
 return False

def select(long_reads,short_reads,chrom,annot,witnesses,flank_gate=True):
 """Return all decisions, including rejected/pending records, for audit."""
 observed=defaultdict(list);sr=Counter()
 for name,r in long_reads.items():
  if r.chain and r.strand in ('+','-'):observed[r.strand,r.chain].append((name,r))
 for mates in short_reads.values():sr.update({(r.strand,j) for r in mates for j in r.chain if r.strand in ('+','-')})
 decisions=[];source_reads={}
 for (strand,chain),reads in sorted(observed.items()):
  known=annot.get((chrom,strand,chain),[])
  compatible=[]
  for model,tid in known:
   supporters=[(name,r) for name,r in reads if ends_fit_full(r,model)]
   if supporters:compatible.append((len(supporters),tid,model,supporters))
  if compatible:
   # One supported representative per chain. No reference-only transcript emitted.
   compatible.sort(key=lambda z:(-z[0],z[1]));n,tid,span,supporters=compatible[0]
   m=Candidate(span,'annotation_chain_with_molecule',n,min(sr[strand,j] for j in chain),n)
   d=Decision(m,score=float(n),lr_links=n,status='accepted')
   d.evidence=(('annotation_chain',span.start+1,tid),)
   decisions.append(d);source_reads[id(d)]=supporters;continue
  span=PathSpan(median_low([r.start for _,r in reads]),median_low([r.end for _,r in reads]),strand,chain)
  perfect=[sum(j in witnesses.get((chrom,name[1]),set()) for name,r in reads) for j in chain]
  support=min(sr[strand,j] for j in chain);n=len(reads)
  d=Decision(Candidate(span,'observed_molecule_chain',n,support,min(perfect)),score=float(min(perfect)),lr_links=n)
  if n<2:d.status='insufficient_complete_molecules'
  elif flank_gate and any(not (p>=2 or (p>=1 and sr[strand,j]>=3)) for j,p in zip(chain,perfect)):
   d.status='chain_conditioned_junction_support_missing'
  decisions.append(d);source_reads[id(d)]=reads
 # A parent must itself have passed evidence acceptance. Geometric containment
 # alone does not prove fragment origin, and no posterior probability is claimed.
 parents=[]
 for d in sorted(decisions,key=lambda x:(-len(x.model.span.chain),x.model.span.chain)):
  if d.status!='accepted':continue
  x=d.model.span
  if d.model.origin=='annotation_chain_with_molecule':parents.append(x);continue
  explain=[p for p in parents if fragment_fit(x,p)]
  if explain:
   d.status='fragment_or_short_isoform';d.parents=tuple(p.chain for p in explain)
  else:parents.append(x)
 return sorted(decisions,key=lambda d:(d.model.span.start,d.model.span.end,d.model.span.strand,d.model.span.chain))

def augment_annotation(decisions,long_reads,short_reads,chrom,annot):
 """Ablation: add known-chain support while retaining the old graph decisions."""
 additions=select(long_reads,short_reads,chrom,annot,{},flank_gate=False)
 known={ (d.model.span.strand,d.model.span.chain):d for d in additions if d.model.origin=='annotation_chain_with_molecule'}
 out=[d for d in decisions if (d.model.span.strand,d.model.span.chain) not in known]
 return out+list(known.values())
