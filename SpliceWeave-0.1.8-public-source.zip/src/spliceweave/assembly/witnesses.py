"""Original-alignment exact flanks, not reference support inferred from corrected sites."""
from pathlib import Path
import json,pysam,argparse
def build(bam,fasta):
 out={};counts=dict(reads=0,junctions=0,exact_flanks=0)
 with pysam.AlignmentFile(bam,'rb') as f,pysam.FastaFile(fasta) as ref:
  for r in f:
   if r.flag&3844 or r.mapping_quality<20 or (r.has_tag('NH') and r.get_tag('NH')!=1):continue
   if not r.query_sequence:continue
   counts['reads']+=1;seq=r.query_sequence.upper();q=0;p=r.reference_start;ops=r.cigartuples or [];good=[]
   for i,(op,n) in enumerate(ops):
    if op==3:
     counts['junctions']+=1
     if i>0 and i+1<len(ops) and ops[i-1][0] in (0,7,8) and ops[i+1][0] in (0,7,8) and min(ops[i-1][1],ops[i+1][1])>=10:
      left=ref.fetch(r.reference_name,p-10,p).upper();right=ref.fetch(r.reference_name,p+n,p+n+10).upper()
      if seq[q-10:q]==left and seq[q:q+10]==right and set(left+right)<=set('ACGT'):
       good.append([p,p+n]);counts['exact_flanks']+=1
    if op in (0,1,4,7,8):q+=n
    if op in (0,2,3,7,8):p+=n
   if good:out[r.reference_name+'\t'+r.query_name]=good
 return dict(counts=counts,flank_bp=10,witnesses=out)
