"""SpliceWeave junction correction and cohort splice-branch analysis."""

import argparse
import csv
import hashlib
import json
import tempfile
from pathlib import Path

from .event_bam import generate_counts
from .tables import read_counts, read_design


def file_digest(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def differential(args):
    try:
        import numpy as np
        from .differential import write_result
    except ImportError as exc:
        raise ValueError("Install the SpliceWeave package with its NumPy dependency") from exc
    if min(args.min_informative, args.exact_limit, args.permutations) < 1 or args.seed < 0:
        raise ValueError("Depth and permutation limits must be positive, seed must be non-negative")
    if not 0 < args.fdr <= 1:
        raise ValueError("--fdr must be in (0, 1]")
    if bool(args.events) != bool(args.gtf):
        raise ValueError("BAM mode needs both --events and --gtf; use --catalog only with --counts")
    if args.catalog and not args.counts:
        raise ValueError("--catalog is optional annotation for --counts")
    if args.out_dir.exists() or args.out_dir.is_symlink():
        raise FileExistsError(f"Choose a new output directory: {args.out_dir}")
    design, selected, n_ref = read_design(
        args.samples, args.reference, args.comparison, bool(args.events), args.pair_column
    )
    args.out_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.out_dir.parent, prefix=".spliceweave-") as scratch:
        out = Path(scratch) / "result"
        out.mkdir()
        counts = args.counts
        excluded = {}
        if args.events:
            counts = out / "branch_counts.tsv"
            excluded = generate_counts(counts, args, design, selected)
        events = read_counts(counts, design, selected, args.catalog, allow_empty=bool(excluded))
        info = write_result(out, events, selected, n_ref, design, args)
        inputs = {
            k: getattr(args, k)
            for k in ("samples", "counts", "catalog", "events", "gtf")
            if getattr(args, k) is not None
        }
        info.update(
            reference=args.reference,
            comparison=args.comparison,
            reference_samples=selected[:n_ref],
            comparison_samples=selected[n_ref:],
            study_design="matched pairs" if args.pair_column else "two independent groups",
            pair_column=args.pair_column,
            excluded_catalog_events=excluded,
            effect="comparison mean observed B/(A+B) minus reference mean",
            adjustment="Benjamini-Hochberg within IR and nonIR, tested events only",
            min_informative_per_sample=args.min_informative,
            fdr=args.fdr,
            exact_limit=args.exact_limit,
            numpy_version=np.__version__,
            input_sha256={k: file_digest(p) for k, p in inputs.items()},
        )
        (out / "summary.json").write_text(
            json.dumps(info, indent=2, ensure_ascii=False) + "\n", encoding="utf8"
        )
        if args.out_dir.exists():
            raise FileExistsError(f"Output appeared during the run: {args.out_dir}")
        out.rename(args.out_dir)
    print(
        f"{info['tested']}/{info['events']} events tested, {info['significant']} at q <= {args.fdr:g}. "
        f"Results: {args.out_dir}"
    )


def main(argv=None):
    parser = argparse.ArgumentParser(prog="spliceweave", description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    usage = commands.add_parser('event-psi', help='experimental molecular event usage from transcript abundance (no significance test)')
    for name in ('events', 'gtf', 'abundance', 'out-dir'):
        usage.add_argument('--'+name, type=Path, required=True)
    usage.add_argument('--value-column', default='TPM', help='molecular abundance column; TPM or SR_TPM for SW quantify')
    quant = commands.add_parser('quantify', help='native geometric likelihood RNA-seq + Iso-Seq quantification')
    quant.add_argument('--gtf', type=Path, help='fixed inference transcript catalogue GTF[.gz]')
    quant.add_argument('--short-bam', type=Path, help='coordinate-sorted short-read BAM')
    quant.add_argument('--long-bam', type=Path, help='coordinate-sorted long-read BAM')
    quant.add_argument('--geometry', type=Path, help='replay geometry.json[.gz] without BAM extraction')
    quant.add_argument('--sample', default='sample', help='sample identifier')
    quant.add_argument('--out-dir', type=Path, required=True)
    assembly = commands.add_parser('assemble-chains', help='reconstruct chains with original/corrected evidence arbitration')
    assembly.add_argument('--long-bam', type=Path, required=True)
    assembly.add_argument('--short-bam', type=Path, required=True)
    assembly.add_argument('--reference', type=Path, required=True, help='indexed reference FASTA')
    assembly.add_argument('--gtf', type=Path, required=True, help='inference annotation, never a withheld truth catalogue')
    assembly.add_argument('--corrected-bed', type=Path, required=True, help='all-read corrected.bed from correct, not confident.bed')
    assembly.add_argument('--mode', choices=['joint', 'baseline', 'sequence_only', 'direction_only', 'no_sequence_gate', 'no_family_gate'], default='joint', help='joint is the released policy; other modes are matched controls')
    assembly.add_argument('--out-dir', type=Path, required=True)
    correct_parser = commands.add_parser('correct', help='trusted-pair local correction of BED12 reads (SW unguarded)')
    correct_parser.add_argument('--query', '-q', type=Path, required=True, help='BED12[.gz], one primary alignment per read; transcript strand')
    correct_parser.add_argument('--gtf', type=Path, help='trusted transcript annotation GTF[.gz]')
    guidance = correct_parser.add_mutually_exclusive_group()
    guidance.add_argument('--junction-bed', type=Path, help='trusted BED6 introns, score = supporting fragments')
    guidance.add_argument('--junction-tab', type=Path, help='STAR SJ.out.tab; threshold uses unique-read support')
    correct_parser.add_argument('--window', '-w', type=int, default=10, help='maximum displacement per boundary, default 10 nt')
    correct_parser.add_argument('--min-support', type=int, default=1, help='minimum junction evidence support, default 1')
    correct_parser.add_argument('--end-anchor', type=int, default=8, help='minimum terminal span for a proposed move, default 8 nt')
    correct_parser.add_argument('--out-dir', type=Path, required=True, help='new output directory; existing results are never overwritten')
    review_parser = commands.add_parser('review-junctions', help='experimental event-preserving junction review (no BAM/GTF edits)')
    review_parser.add_argument('--input', type=Path, required=True, help='shared-window evidence JSONL[.gz]')
    review_parser.add_argument('--out-dir', type=Path, required=True, help='new output directory')
    review_parser.add_argument('--config', type=Path, help='JSON ReviewConfig overrides; record the frozen settings')
    p = commands.add_parser(
        "diff-splicing",
        help="test differential usage of two fixed splice branches",
        description="Two-sided permutation tests for two independent groups or matched biological pairs.",
    )
    p.add_argument("--samples", type=Path, required=True, help="TSV with sample_id and condition")
    p.add_argument(
        "--reference", required=True, help="baseline condition, exact label from the design"
    )
    p.add_argument(
        "--comparison",
        required=True,
        help="comparison condition; effects are comparison minus reference",
    )
    p.add_argument(
        "--pair-column",
        help="optional matched-subject ID in --samples; swap labels within each pair",
    )
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "--counts", type=Path, help="event/sample A_only_fragments and B_only_fragments TSV[.gz]"
    )
    source.add_argument(
        "--events", type=Path, help="fixed local two-branch event TSV or AStalavista .gtf[.gz]"
    )
    p.add_argument(
        "--gtf", type=Path, help="exon models corresponding to --events; uses BAMs in --samples"
    )
    p.add_argument(
        "--catalog", type=Path, help="optional event_id, Unit and event annotation TSV for --counts"
    )
    p.add_argument("--out-dir", type=Path, required=True, help="new output directory")
    p.add_argument(
        "--min-informative", type=int, default=20, help="required A+B in every sample (default 20)"
    )
    p.add_argument(
        "--exact-limit", type=int, default=10000, help="enumerate all allocations up to this many"
    )
    p.add_argument(
        "--permutations", type=int, default=10000, help="random draws above the exact limit"
    )
    p.add_argument("--seed", type=int, default=1, help="Monte Carlo random seed (default 1)")
    p.add_argument("--fdr", type=float, default=0.05, help="BH q-value threshold (default 0.05)")
    count = commands.add_parser('diff-splicing-counts', help='replicate-aware bootstrap test of observed fragment fractions (not molecular PSI)')
    for name in ('samples', 'counts', 'out-dir'):
        count.add_argument('--'+name, type=Path, required=True)
    count.add_argument('--catalog', type=Path)
    for name in ('reference', 'comparison'):
        count.add_argument('--'+name, required=True)
    count.add_argument('--coverage-rescue', type=Path, metavar='EVENT_USAGE.tsv',
                       help='enable experimental abundance rescue using event-psi output')
    count.add_argument('--min-informative', type=int,
                       help='minimum count depth per sample (default 20, or 1 with --coverage-rescue)')
    count.add_argument('--bootstrap-draws', type=int, default=9999)
    count.add_argument('--seed-prefix', default='20261125', help='frozen hash prefix; event ID supplies a stable per-event seed')
    count.add_argument('--fdr', type=float, default=.05)
    count.add_argument('--min-effect', type=float, default=.1, help='minimum absolute observed fraction change; not molecular DeltaPSI')
    joint = commands.add_parser('diff-splicing-joint', help='joint RNA-seq/Iso-Seq differential usage and platform conflict')
    for name in ('samples','out-dir'):
        joint.add_argument('--'+name, type=Path, required=True)
    for name in ('short-counts','long-counts','catalog','events','gtf'):
        joint.add_argument('--'+name, type=Path)
    for name in ('reference','comparison'):
        joint.add_argument('--'+name, required=True)
    joint.add_argument('--pair-column')
    joint.add_argument('--min-short', type=int, default=20)
    joint.add_argument('--min-long', type=int, default=5)
    joint.add_argument('--exact-limit', type=int, default=10000)
    joint.add_argument('--permutations', type=int, default=10000)
    joint.add_argument('--seed', type=int, default=1)
    joint.add_argument('--fdr', type=float, default=0.05)
    joint.add_argument('--adjustment', choices=('BH','BY'), default='BY', help='BY controls arbitrary event dependence; BH requires dependence assumptions')
    args = parser.parse_args(argv)
    try:
        if args.command == 'diff-splicing-counts':
            from .count_differential import run_count_test
            if args.min_informative is None:
                args.min_informative = 1 if args.coverage_rescue else 20
            print(json.dumps(run_count_test(args), ensure_ascii=False))
        elif args.command == 'event-psi':
            from .event_abundance import run_event_psi
            print(json.dumps(run_event_psi(args), ensure_ascii=False))
        elif args.command == 'diff-splicing-joint':
            from .joint_differential import run_joint
            print(json.dumps(run_joint(args), ensure_ascii=False))
        elif args.command == 'quantify':
            try:
                from .quantification.runner import run_quantify
            except ImportError as exc:
                raise ValueError("Install SpliceWeave with 'pip install .[quantification]'") from exc
            result = run_quantify(args)
            print(json.dumps(dict(model=result['model'], models=result['models'], out_dir=str(args.out_dir))))
        elif args.command == 'assemble-chains':
            from .assembly.runner import run_assembly
            print(json.dumps(run_assembly(args), ensure_ascii=False))
        elif args.command == 'correct':
            from .correct import CorrectConfig, run_correct
            result = run_correct(args.query, args.out_dir, gtf=args.gtf,
                                 junction_bed=args.junction_bed, junction_tab=args.junction_tab,
                                 config=CorrectConfig(args.window, args.min_support, args.end_anchor))
            print(json.dumps(result, ensure_ascii=False))
        elif args.command == 'review-junctions':
            from .correction import ReviewConfig, run_review
            config = ReviewConfig(**json.loads(args.config.read_text())) if args.config else ReviewConfig()
            print(json.dumps(run_review(args.input, args.out_dir, config), ensure_ascii=False))
        else:
            differential(args)
    except (ValueError, OSError, csv.Error) as exc:
        parser.exit(2, f"{parser.prog}: {exc}\n")
