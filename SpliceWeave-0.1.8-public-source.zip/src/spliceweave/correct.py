"""Released trusted-pair local correction of BED12 read alignments (SW unguarded).

This is an independent implementation. FLAIR inspired the trusted-site workflow;
no FLAIR code or external executable is used here. Coordinates are 0-based,
half-open and strand is transcript strand. Scores are not probabilities.
"""

from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from contextlib import ExitStack
from dataclasses import asdict, dataclass
import csv
import gzip
import hashlib
import json
from pathlib import Path
import re
import tempfile


@dataclass(frozen=True)
class CorrectConfig:
    window: int = 10
    min_support: int = 1
    end_anchor: int = 8

    def validate(self):
        if self.window < 0 or self.min_support < 1 or self.end_anchor < 1:
            raise ValueError("window must be >=0; min_support and end_anchor must be >=1")


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for b in iter(lambda: handle.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def open_text(path):
    return gzip.open(path, 'rt') if str(path).endswith('.gz') else Path(path).open()


class Catalog:
    def __init__(self):
        self.edges = defaultdict(set)
        self.support = {}
        self.sources = defaultdict(set)
        self.left = defaultdict(set)
        self.right = defaultdict(set)
        self.index = {}

    def add(self, chrom, strand, left, right, source, support=0):
        if strand not in ('+', '-') or left < 0 or right <= left:
            raise ValueError(f"Invalid trusted junction: {chrom}:{left}-{right}:{strand}")
        key = (chrom, strand)
        edge = (left, right)
        self.edges[key].add(edge)
        self.left[key].add(left)
        self.right[key].add(right)
        self.sources[key + edge].add(source)
        # Repeated rows are not independent fragments: do not sum them.
        self.support[key + edge] = max(support, self.support.get(key + edge, 0))

    def finish(self):
        for key, edges in self.edges.items():
            self.index[key] = sorted(edges)
        if not self.index:
            raise ValueError("No trusted junctions survived input filtering")

    def near(self, key, edge, window):
        values = self.index.get(key, [])
        lo = bisect_left(values, (edge[0] - window, -1))
        hi = bisect_right(values, (edge[0] + window, float('inf')))
        return [j for j in values[lo:hi] if abs(j[1] - edge[1]) <= window]


def load_catalog(gtf=None, junction_bed=None, junction_tab=None, min_support=1):
    c = Catalog()
    if gtf:
        tx = defaultdict(set)
        with open_text(gtf) as f:
            for line_no, ln in enumerate(f, 1):
                if not ln.strip() or ln.startswith('#'):
                    continue
                row = ln.rstrip('\n').split('\t')
                if len(row) != 9:
                    raise ValueError(f"GTF line {line_no}: expected 9 tab-separated columns")
                if row[2] != 'exon':
                    continue
                attr = dict(re.findall(r'(\w+)\s+"([^"]*)"', row[8]))
                if not attr.get('transcript_id'):
                    raise ValueError(f"GTF line {line_no}: missing transcript_id")
                start, end = int(row[3]) - 1, int(row[4])
                if start < 0 or end <= start or row[6] not in ('+', '-'):
                    raise ValueError(f"GTF line {line_no}: invalid exon coordinates or strand")
                tx[(row[0], row[6], attr['transcript_id'])].add((start, end))
        for (chrom, strand, name), exons in tx.items():
            exons = sorted(exons)
            for a, b in zip(exons, exons[1:]):
                if a[1] >= b[0]:
                    raise ValueError(f"Overlapping/touching exons in transcript {name}")
                c.add(chrom, strand, a[1], b[0], 'annotation')
    for path, kind in ((junction_bed, 'bed'), (junction_tab, 'star')):
        if not path:
            continue
        with open_text(path) as f:
            for line_no, ln in enumerate(f, 1):
                if not ln.strip() or ln.startswith(('#', 'track ', 'browser ')):
                    continue
                row = ln.rstrip('\n').split('\t')
                if kind == 'bed':
                    if len(row) != 6:
                        raise ValueError(f"Junction BED line {line_no}: use BED6 intron intervals, not BED12")
                    chrom, left, right, _, support, strand = row
                    left, right, support = int(left), int(right), float(support)
                else:
                    if len(row) != 9:
                        raise ValueError(f"STAR line {line_no}: expected 9 SJ.out.tab columns")
                    chrom, left, right = row[0], int(row[1]) - 1, int(row[2])
                    if row[3] == '0':
                        continue
                    if row[3] not in ('1', '2'):
                        raise ValueError(f"STAR line {line_no}: invalid strand code")
                    strand = '+' if row[3] == '1' else '-'
                    support = int(row[6])
                if not (support >= 0 and support < float('inf')):
                    raise ValueError(f"Junction line {line_no}: invalid support")
                if support >= min_support:
                    c.add(chrom, strand, left, right, 'junction_' + kind, support)
    c.finish()
    return c


@dataclass
class Read:
    fields: list
    start: int
    end: int
    junctions: list

    @classmethod
    def parse(cls, line):
        f = line.rstrip('\r\n').split('\t')
        if len(f) < 12 or f[5] not in ('+', '-', '.') or not f[3]:
            raise ValueError("Expected BED12 with a read ID and transcript strand (+, -, or .)")
        start, end, count = int(f[1]), int(f[2]), int(f[9])
        sizes = [int(x) for x in f[10].rstrip(',').split(',')]
        offsets = [int(x) for x in f[11].rstrip(',').split(',')]
        if start < 0 or end <= start or count < 1 or len(sizes) != count or len(offsets) != count:
            raise ValueError(f"Invalid BED12 span/block count: {f[3]}")
        blocks = [(start + x, start + x + n) for x, n in zip(offsets, sizes)]
        if blocks[0][0] != start or blocks[-1][1] != end or any(a >= b for a, b in blocks):
            raise ValueError(f"Invalid BED12 blocks: {f[3]}")
        if any(a[1] >= b[0] for a, b in zip(blocks, blocks[1:])):
            raise ValueError(f"BED12 blocks must be ordered, separated, and nonoverlapping: {f[3]}")
        return cls(f, start, end, [(a[1], b[0]) for a, b in zip(blocks, blocks[1:])])

    def render(self, junctions):
        f = self.fields.copy()
        starts = [self.start] + [j[1] for j in junctions]
        ends = [j[0] for j in junctions] + [self.end]
        if any(b <= a for a, b in zip(starts, ends)) or any(a >= b for a, b in junctions):
            raise ValueError(f"Internal error: invalid corrected geometry for {f[3]}")
        f[10] = ','.join(str(b-a) for a, b in zip(starts, ends)) + ','
        f[11] = ','.join(str(a-self.start) for a in starts) + ','
        return '\t'.join(f) + '\n'


def correct_read(read, catalog, config):
    key = (read.fields[0], read.fields[5])
    decisions = []
    final = list(read.junctions)
    for i, orig in enumerate(read.junctions):
        d = dict(index=i, original=orig, final=orig, action='REVIEW', reason='', candidates=[])
        decisions.append(d)
        if key[1] == '.':
            d['reason'] = 'unknown_transcript_strand'
            continue
        if orig in catalog.edges.get(key, set()):
            d.update(action='KEEP', reason='exact_trusted_pair')
            continue
        left_known = orig[0] in catalog.left.get(key, set())
        right_known = orig[1] in catalog.right.get(key, set())
        if left_known and right_known:
            d['reason'] = 'trusted_boundaries_unpaired'
            continue
        candidates = catalog.near(key, orig, config.window)
        # A trusted original boundary is immutable, even if the other is uncertain.
        candidates = [j for j in candidates if (not left_known or j[0] == orig[0])
                      and (not right_known or j[1] == orig[1])]
        d['candidates'] = candidates
        if not candidates:
            d['reason'] = 'no_compatible_trusted_pair'
            continue
        distances = {j: abs(j[0]-orig[0]) + abs(j[1]-orig[1]) for j in candidates}
        best = min(distances.values())
        winners = [j for j in candidates if distances[j] == best]
        if len(winners) != 1:
            d['reason'] = 'equal_distance_ambiguity'
            continue
        proposed = winners[0]
        if proposed[0] - read.start < config.end_anchor or read.end - proposed[1] < config.end_anchor:
            d['reason'] = 'insufficient_terminal_anchor'
            continue
        final[i] = proposed
        d.update(action='APPLY', reason='unique_nearest_trusted_pair', final=proposed)
    # Conflicting simultaneous proposals are both reverted, never chosen by order.
    while True:
        bad = set()
        for i, (a, b) in enumerate(zip(final, final[1:])):
            if a[1] >= b[0]:
                bad.update((i, i+1))
        changed = [i for i in bad if final[i] != read.junctions[i]]
        if not changed:
            break
        for i in changed:
            final[i] = read.junctions[i]
            decisions[i].update(action='REVIEW', reason='chain_geometry_conflict', final=final[i])
    return final, decisions


def run_correct(query, out_dir, *, gtf=None, junction_bed=None, junction_tab=None, config=None):
    config = config or CorrectConfig()
    config.validate()
    query, out_dir = Path(query), Path(out_dir)
    if not any((gtf, junction_bed, junction_tab)):
        raise ValueError("Provide --gtf and/or --junction-bed or --junction-tab")
    if junction_bed and junction_tab:
        raise ValueError("Use one junction evidence format per run")
    if out_dir.exists() or out_dir.is_symlink():
        raise FileExistsError(f"Choose a new output directory: {out_dir}")
    inputs = {k: Path(v) for k, v in dict(query=query, gtf=gtf, junction_bed=junction_bed,
                                       junction_tab=junction_tab).items() if v}
    before = {k: digest(v) for k, v in inputs.items()}
    catalog = load_catalog(gtf, junction_bed, junction_tab, config.min_support)
    out_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=out_dir.parent, prefix='.correct-') as tmp:
        out = Path(tmp) / 'result'
        out.mkdir()
        counts, reasons = Counter(), Counter()
        seen = set()
        with ExitStack() as stack:
            outputs = {n: stack.enter_context((out / n).open('w')) for n in
                       ('corrected.bed', 'confident.bed', 'unresolved.bed')}
            audit = stack.enter_context(gzip.open(out / 'junction_decisions.tsv.gz', 'wt'))
            w = csv.writer(audit, delimiter='\t')
            w.writerow(['read_id', 'chrom', 'strand', 'junction_index', 'original_left', 'original_right',
                        'final_left', 'final_right', 'action', 'reason', 'candidate_pairs_json'])
            reads = stack.enter_context((out / 'read_status.tsv').open('w'))
            rw = csv.writer(reads, delimiter='\t')
            rw.writerow(['read_id', 'junctions', 'applied', 'review', 'status'])
            f = stack.enter_context(open_text(query))
            for line_no, ln in enumerate(f, 1):
                if not ln.strip() or ln.startswith(('#', 'track ', 'browser ')):
                    continue
                try:
                    read = Read.parse(ln)
                except ValueError as e:
                    raise ValueError(f"Query line {line_no}: {e}") from e
                rid = read.fields[3]
                if rid in seen:
                    raise ValueError(f"Duplicate read ID {rid}; supply one primary alignment per read")
                seen.add(rid)
                final, decisions = correct_read(read, catalog, config)
                applied = sum(d['action'] == 'APPLY' for d in decisions)
                review = sum(d['action'] == 'REVIEW' for d in decisions)
                status = 'unspliced' if not decisions else 'unresolved' if review else 'confident'
                bed = read.render(final)
                outputs['corrected.bed'].write(bed)
                # Unspliced reads have no verified junctions; never call them confident.
                outputs['confident.bed' if status == 'confident' else 'unresolved.bed'].write(bed)
                rw.writerow([rid, len(decisions), applied, review, status])
                counts.update(reads=1, junctions=len(decisions), applied=applied, review=review,
                              changed_reads=int(applied > 0), **{status+'_reads': 1})
                for d in decisions:
                    reasons[d['reason']] += 1
                    w.writerow([rid, *read.fields[0:1], read.fields[5], d['index'], *d['original'],
                                *d['final'], d['action'], d['reason'], json.dumps(d['candidates'])])
        if before != {k: digest(v) for k, v in inputs.items()}:
            raise ValueError("An input changed during correction; output was not published")
        summary = dict(module='spliceweave.correct', schema_version=3, release_version='0.1.3',
                       algorithm_id='sw-correct-trusted-pair-local-v1', original_branch_guard=False,
                       config=asdict(config),
                       counts=dict(counts), reasons=dict(reasons),
                       trusted_pairs=sum(map(len, catalog.edges.values())), input_sha256=before,
                       source_sha256=digest(__file__),
                       output_sha256={p.name: digest(p) for p in sorted(out.iterdir())},
                       coordinates='0-based half-open introns; transcript strand; endpoints unchanged',
                       interpretation='Catalog-guided coordinate correction, not source truth, '
                       'transcript discovery, calibrated probability, or a corrected BAM. '
                       'corrected.bed retains unresolved coordinates; inspect read_status and audit.')
        (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
        if out_dir.exists() or out_dir.is_symlink():
            raise FileExistsError(f"Output appeared during run: {out_dir}")
        out.rename(out_dir)
    return summary
