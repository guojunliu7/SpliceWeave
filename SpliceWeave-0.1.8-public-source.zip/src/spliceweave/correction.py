"""Experimental event-preserving junction review. Scores are NOT probabilities.

No annotation or BAM is edited. Input must describe a shared read window and
uncorrected, independently indexed evidence. Library/molecule IDs, rather than
alignment IDs, define independence. The original competes on equal terms.
"""
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path
import csv
import gzip
import hashlib
import json
import math
import tempfile

# Seven sequence-only coefficients from the archived 20261120 model.
# The original-position coefficient (-6.18) and abundance terms are removed.
SEQUENCE_WEIGHTS = (0.011653532564388515, 1.3328143610763905,
                    -1.6722338940393555, -1.1172121072108312,
                    -2.3479244191983026, 0.3992043756180478,
                    0.8789144124386931)


@dataclass(frozen=True)
class ReviewConfig:
    min_margin: float = 3.5
    phase_bonus: float = 8.0
    short_bonus: float = 2.0
    replicated_molecules: int = 2
    rescue_max_sequence_loss: float = 6.0
    allow_phase_rescue: bool = True
    min_anchor: int = 8
    min_query_coverage: float = 0.75
    min_match_fraction: float = 0.65
    evidence_admission: bool = True
    unsupported_sequence_gain: float = 5.0
    cross_platform_bonus: float = 0.0

    def __post_init__(self):
        if not isinstance(self.allow_phase_rescue, bool) or not isinstance(self.evidence_admission, bool):
            raise ValueError('allow_phase_rescue and evidence_admission must be boolean')
        for key in ('min_margin', 'phase_bonus', 'short_bonus', 'rescue_max_sequence_loss', 'unsupported_sequence_gain', 'cross_platform_bonus'):
            value = getattr(self, key)
            if not math.isfinite(value) or value < 0:
                raise ValueError(f'{key} must be finite and non-negative')
        for key in ('replicated_molecules', 'min_anchor'):
            value = getattr(self, key)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f'{key} must be a positive integer')
        for key in ('min_query_coverage', 'min_match_fraction'):
            if not 0 < getattr(self, key) <= 1:
                raise ValueError(f'{key} must be in (0, 1]')


@lru_cache(maxsize=100000)
def alignment_features(path, query, boundary):
    """Same local alignment geometry as the archived seven-feature scorer."""
    from Bio.Align import PairwiseAligner
    if not path or not query:
        return (0.0,) * 7
    aligner = PairwiseAligner(mode='local', match_score=2, mismatch_score=-3,
                             open_gap_score=-5, extend_gap_score=-1)
    hit = next(iter(aligner.align(path, query)), None)
    if hit is None:
        return (0.0,) * 7
    r, q = hit.indices
    paired = (r >= 0) & (q >= 0)
    matches = sum(path[i] == query[j] for i, j in zip(r[paired], q[paired]))
    return tuple(float(v) for v in (hit.score, matches, paired.sum()-matches,
                 (r < 0).sum(), (q < 0).sum(),
                 (paired & (r < boundary)).sum(), (paired & (r >= boundary)).sum()))


def independent_count(ids, own_id):
    if not isinstance(ids, list) or any(not isinstance(x, str) or not x for x in ids):
        raise ValueError('Evidence must be a list of non-empty library/molecule IDs')
    return len(set(ids) - {own_id})


def review(record, config=ReviewConfig()):
    """Variable-cardinality KEEP/APPLY/REVIEW with an explicit unknown flag.

    `phase_molecules` requires at least one shared flanking junction outside the
    disputed site plus exact independent anchors on both sides of that site.
    The extractor, not this scorer, must enforce this biological contract.
    """
    for field in ('gene', 'rid', 'molecule_id', 'original'):
        if not isinstance(record.get(field), str) or not record[field]:
            raise ValueError(f'Missing {field}')
    query = record.get('query', '').upper()
    if set(query) - set('ACGTN'):
        raise ValueError('Query must use A/C/G/T/N')
    candidates = record.get('candidates')
    if not isinstance(candidates, list) or not candidates:
        raise ValueError('At least the original candidate is required')
    ids = [c.get('id') for c in candidates]
    if any(not isinstance(i, str) or not i for i in ids) or len(ids) != len(set(ids)):
        raise ValueError('Candidate IDs must be unique non-empty strings')
    if record['original'] not in ids:
        raise ValueError('The original must be retained in the candidate set')
    evaluations = []
    for c in candidates:
        path = c.get('path', '').upper()
        boundary = c.get('boundary')
        if (set(path) - set('ACGTN') or isinstance(boundary, bool)
                or not isinstance(boundary, int) or not 0 <= boundary <= len(path)):
            raise ValueError('Invalid candidate path or boundary')
        h = independent_count(c.get('phase_molecules', []), record['molecule_id'])
        sr = c.get('short_support')
        if sr is not None and (isinstance(sr, bool) or not isinstance(sr, int) or sr < 0):
            raise ValueError('short_support must be a non-negative integer or null')
        f = alignment_features(path, query, boundary)
        sequence_score = sum(w*x for w, x in zip(SEQUENCE_WEIGHTS, f))
        supported_phase = min(h / config.replicated_molecules, 1.0)
        supported_short = min((sr or 0) / config.replicated_molecules, 1.0)
        motif=c.get('splice_motif')
        if motif is not None and (not isinstance(motif,str) or len(motif)!=4 or set(motif)-set('ACGTN')):
            raise ValueError('splice_motif must be four A/C/G/T/N bases or null')
        canonical = None if motif is None or 'N' in motif else motif in ('GTAG','GCAG','ATAC')
        quorum = h >= config.replicated_molecules and (sr or 0) >= 4 and canonical is True
        score = sequence_score + config.phase_bonus*supported_phase + config.short_bonus*supported_short + config.cross_platform_bonus*quorum
        n = max(1, len(query))
        usable = (bool(query) and min(f[5:7]) >= config.min_anchor
                  and (f[1]+f[2]+f[3])/n >= config.min_query_coverage
                  and f[1]/n >= config.min_match_fraction)
        evaluations.append(dict(id=c['id'], alignment_score=f[0], sequence_score=sequence_score,
                                score=score, phase_molecules=h, short_support=sr,
                                sequence_usable=usable, exact_window_match=bool(query) and path == query,
                                canonical=canonical, cross_platform_quorum=quorum))
    current = next(e for e in evaluations if e['id'] == record['original'])
    for e in evaluations:
        e['admitted'] = (e['id']==record['original'] or not config.evidence_admission
                        or e['phase_molecules']>=config.replicated_molecules
                        or (e['short_support'] or 0)>=config.replicated_molecules
                        or e['alignment_score']-current['alignment_score']>=config.unsupported_sequence_gain)
    evaluations.sort(key=lambda e: (-e['score'], e['id']))
    active=[e for e in evaluations if e['admitted']]
    best = active[0]
    margin = best['score'] - active[1]['score'] if len(active) > 1 else 0.0
    unknown = not any(e['sequence_usable'] for e in evaluations)
    action, reason, final = 'REVIEW', 'insufficient_score_separation', record['original']
    if unknown:
        reason = 'insufficient_sequence_or_unrepresented_state'
    elif len(active) == 1:
        reason = 'no_alternative_evaluated' if len(evaluations)==1 else 'no_supported_alternative'
    elif margin > 1e-9 and margin >= config.min_margin and best['sequence_usable']:
        if best['id'] == record['original']:
            action, reason = 'KEEP', 'original_wins_fair_competition'
        else:
            delta = best['alignment_score'] - current['alignment_score']
            rescue = (config.allow_phase_rescue and config.phase_bonus > 0
                      and best['phase_molecules'] >= config.replicated_molecules
                      and current['phase_molecules'] == 0
                      and (current['short_support'] or 0) == 0
                      and delta >= -config.rescue_max_sequence_loss)
            quorum_rescue = (config.allow_phase_rescue and config.cross_platform_bonus>0
                             and best['cross_platform_quorum'] and current['canonical'] is False
                             and (current['short_support'] or 0)==0
                             and delta>=-config.rescue_max_sequence_loss)
            if current['exact_window_match']:
                reason = 'exact_original_sequence_protection'
            elif delta > 0 or rescue or quorum_rescue:
                action, reason, final = 'APPLY', ('sequence_gain' if delta > 0 else 'replicated_phase_rescue' if rescue else 'cross_platform_rescue'), best['id']
            else:
                reason = 'original_sequence_protection'
    plausible = sorted({record['original']} | {e['id'] for e in evaluations
                         if best['score']-e['score'] <= config.min_margin})
    return dict(gene=record['gene'], rid=record['rid'], original=record['original'], final=final,
                action=action, reason=reason, best=best['id'], margin=margin,
                unknown_possible=unknown, candidate_catalog_exhaustive=False,
                plausible_candidates=plausible, candidates=evaluations,
                score_semantics='uncalibrated ranking score; not a probability or quantification likelihood')


def run_review(input_path, output_dir, config=ReviewConfig()):
    input_path, output_dir = Path(input_path), Path(output_dir)
    if output_dir.exists() or output_dir.is_symlink():
        raise FileExistsError(f'Choose a new output directory: {output_dir}')
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if input_path.suffix == '.gz' else open
    seen, counts = set(), {}
    with tempfile.TemporaryDirectory(dir=output_dir.parent, prefix='.junction-review-') as tmp:
        dst = Path(tmp)/'result'
        dst.mkdir()
        with opener(input_path, 'rt', encoding='utf8') as src, gzip.open(dst/'decisions.jsonl.gz', 'wt', encoding='utf8') as detail, gzip.open(dst/'decisions.tsv.gz', 'wt', encoding='utf8') as table:
            fields = ['gene','rid','original','final','action','reason','best','margin','unknown_possible']
            writer = csv.DictWriter(table, fields, delimiter='\t', lineterminator='\n', extrasaction='ignore')
            writer.writeheader()
            for line in src:
                record = json.loads(line)
                key = (record['gene'], record['rid'])
                if key in seen:
                    raise ValueError(f'Duplicate read window: {key}')
                seen.add(key)
                result = review(record, config)
                writer.writerow(result)
                detail.write(json.dumps(result, ensure_ascii=False)+'\n')
                counts[result['action']] = counts.get(result['action'], 0)+1
        def digest(path):
            h = hashlib.sha256()
            with open(path, 'rb') as stream:
                for block in iter(lambda: stream.read(1048576), b''): h.update(block)
            return h.hexdigest()
        summary = dict(status='experimental', n=len(seen), actions=counts, config=asdict(config),
                       input_sha256=digest(input_path), code_sha256=digest(__file__),
                       calibration='none; scores must not be used as probabilities or Q entries',
                       sequence_weights=list(SEQUENCE_WEIGHTS),
                       scope='junction review tables only; no BAM/GTF or quantification changes')
        (dst/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf8')
        if output_dir.exists(): raise FileExistsError(output_dir)
        dst.rename(output_dir)
    return summary
