"""Released wrapper for the frozen observed-count bootstrap model.

This interface does not supply a P value for capture-corrected molecular PSI.
The empirical scope remains the previously viewed Sequin benchmark.
"""
import hashlib
import json
import re
import tempfile
from collections import defaultdict
from pathlib import Path

import numpy as np

from .differential import prepare_result, adjust_bh
from .experimental_count_test import bootstrap_test, excess_dispersion
from .joint_differential import write_tsv
from .tables import read_counts, read_design, MISSING


def event_gene(event):
    """Require one explicit gene; never learn a prior from the tested gene."""
    for key in ('ensembl_gene_ids', 'gene_names'):
        value = event.annotations.get(key, '').strip()
        if value.lower() in MISSING:
            continue
        genes = set(re.split(r'[,;|\s]+', value))
        return next(iter(genes)) if len(genes) == 1 else None
    return None


def run_count_test(args):
    from .cli import file_digest
    if args.min_informative < 1 or args.bootstrap_draws < 99:
        raise ValueError('Positive depth and at least 99 bootstrap draws required')
    if not 0 < args.fdr <= 1 or not 0 <= args.min_effect <= 1:
        raise ValueError('Require 0 < FDR <= 1 and 0 <= minimum effect <= 1')
    if args.out_dir.exists() or args.out_dir.is_symlink():
        raise FileExistsError(f'Choose a new output directory: {args.out_dir}')
    design, selected, n_ref = read_design(args.samples, args.reference, args.comparison, False)
    events = read_counts(args.counts, design, selected, args.catalog)
    args.out_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.out_dir.parent, prefix='.sw-count-') as tmp:
        out = Path(tmp)/'result'; out.mkdir()
        rows, eligible, _ = prepare_result(out, events, selected, n_ref, design, args)
        gene_rho = defaultdict(lambda: defaultdict(list)); arrays = {}
        for row in eligible:
            eid = row['event_id']; gene = event_gene(events[eid]); row['gene_id'] = gene
            if gene is None:
                row['status'] = 'missing_or_ambiguous_gene'; continue
            pairs = np.array([events[eid].counts[s] for s in selected])
            y, n = pairs[:, 1], pairs.sum(axis=1)
            arrays[eid] = (y, n)
            gene_rho[row['test_family']][gene].append(float(excess_dispersion(y, n, n_ref)))
        prior_by_gene = {family: {gene: float(np.mean(v)) for gene, v in g.items()}
                         for family, g in gene_rho.items()}
        for row in eligible:
            if row['status'] != 'tested': continue
            eid = row['event_id']; gene = row['gene_id']; family = row['test_family']
            others = [v for g, v in prior_by_gene[family].items() if g != gene]
            row['prior_genes'] = len(others)
            if not others:
                row['status'] = 'insufficient_other_genes'; continue
            prior = float(np.mean(others))
            seed = int(hashlib.sha256((args.seed_prefix+eid).encode()).hexdigest()[:8], 16)
            r = bootstrap_test(*arrays[eid], n_ref, prior, prior_df=4,
                               draws=args.bootstrap_draws, seed=seed, null_rho_floor=prior)
            row.update(r)
        adjust_bh(rows)
        fields = list(rows[0]) + [k for row in rows for k in row if k not in rows[0]]
        fields = list(dict.fromkeys(fields))
        for row in rows:
            if row['BH_q'] is not None:
                row['significant'] = bool(row['BH_q'] <= args.fdr and abs(row['delta_B_fraction']) >= args.min_effect)
            else:
                row['significant'] = None
        # q and effect are both observed-count quantities. No molecular estimate is joined.
        write_tsv(out/'count_differential_events.tsv', rows, fields)
        summary = dict(version='sw-count-bootstrap-v1', estimand='observed B/(A+B), comparison minus reference',
                       molecular_PSI_significance=False, independent_groups=True,
                       reference=args.reference, comparison=args.comparison,
                       reference_samples=selected[:n_ref], comparison_samples=selected[n_ref:],
                       events=len(rows), tested=sum(r['p_value'] is not None for r in rows),
                       significant=sum(r['significant'] is True for r in rows),
                       adjustment='BH within IR/nonIR across tested events',
                       fdr=args.fdr, min_effect=args.min_effect, min_informative=args.min_informative,
                       bootstrap_draws=args.bootstrap_draws, seed_prefix=args.seed_prefix, prior_df=4,
                       prior='mean of within-gene mean dispersions in the same test family; tested gene excluded',
                       null_floor='leave-one-gene-out prior',
                       evidence_scope='Previously viewed Sequin libraries; external FDR calibration not established',
                       input_sha256={k:file_digest(getattr(args,k)) for k in ('samples','counts','catalog') if getattr(args,k)})
        if getattr(args, 'coverage_rescue', None):
            try:
                from .experimental_coverage_rescue import write_rescue_results
            except ModuleNotFoundError as exc:
                if exc.name != 'pandas':
                    raise
                raise ValueError("Install the rescue extra with pip install '.[rescue]'") from exc
            summary['coverage_rescue'] = write_rescue_results(
                out, args.coverage_rescue, events, rows, selected, n_ref, args.min_effect)
            summary['input_sha256']['coverage_rescue'] = file_digest(args.coverage_rescue)
        (out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
        if args.out_dir.exists() or args.out_dir.is_symlink():
            raise FileExistsError(f'Output appeared during run: {args.out_dir}')
        out.rename(args.out_dir)
    return summary
