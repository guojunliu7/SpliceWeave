"""Independent-sample tests of the change in the observed B-branch fraction."""

import csv
import itertools
import math
from collections import defaultdict

import numpy as np

from .tables import ANNOTATIONS
from .fragments import RETENTION_RULE, retention_spans


def permutations(values, n_ref, exact_limit, draws, seed, paired=False):
    """Compare absolute mean contrasts; equivalent sample labellings are kept."""
    n, n_events = values.shape
    n_alt = n - n_ref
    total = 2 ** n_ref if paired else math.comb(n, n_alt)
    exact = total <= exact_limit
    trials = total if exact else draws
    observed = np.abs(values[n_ref:].mean(axis=0) - values[:n_ref].mean(axis=0))
    sums = values.sum(axis=0)
    extreme = np.zeros(n_events, dtype=np.int64)
    if n_events:
        rng = np.random.default_rng(seed)
        if paired:
            slots = np.arange(n_ref)
            swaps = (
                itertools.product((0, 1), repeat=n_ref)
                if exact
                else (rng.integers(0, 2, n_ref) for _ in range(trials))
            )
            allocations = (slots + n_ref * np.asarray(swap) for swap in swaps)
        elif exact:
            allocations = itertools.combinations(range(n), n_alt)
        else:
            allocations = (rng.choice(n, n_alt, replace=False) for _ in range(trials))
        # Each row is a named assignment, reused for every event. Chunk both axes.
        batch_size = min(128, max(1, 262144 // n))
        while batch := list(itertools.islice(allocations, batch_size)):
            mask = np.zeros((len(batch), n), dtype=float)
            mask[np.arange(len(batch))[:, None], np.asarray(batch)] = 1
            for start in range(0, n_events, 2048):
                part = slice(start, start + 2048)
                group_sum = mask @ values[:, part]
                differences = group_sum / n_alt - (sums[part] - group_sum) / n_ref
                extreme[part] += (np.abs(differences) >= observed[part] - 1e-12).sum(axis=0)
    p = extreme / trials if exact else (extreme + 1) / (trials + 1)
    return p, {
        "method": "exact" if exact else "monte_carlo",
        "possible_assignments": total,
        "permutations_per_test": trials,
        "seed": None if exact else seed,
    }


def adjust_bh(rows):
    families = defaultdict(list)
    for row in rows:
        if row["p_value"] is not None:
            families[row["test_family"]].append(row)
    for tests in families.values():
        tests.sort(key=lambda r: r["p_value"])
        previous = 1.0
        for rank in range(len(tests), 0, -1):
            row = tests[rank - 1]
            previous = min(previous, row["p_value"] * len(tests) / rank)
            row["BH_q"] = previous


def writer(stream, fields):
    w = csv.DictWriter(stream, fieldnames=fields, delimiter="\t", lineterminator="\n")
    w.writeheader()
    return w


def prepare_result(out, events, selected, n_ref, design, args):
    rows, tested, test_values = [], [], []
    hits = 0
    with (out / "sample_usage.tsv").open("w", encoding="utf8", newline="") as f:
        samples = writer(
            f,
            (
                "event_id",
                "sample_id",
                "condition",
                "Unit",
                "A_only_fragments",
                "B_only_fragments",
                "informative_fragments",
                "observed_B_fraction",
                "status",
                "ir_observability",
                "max_mate_length",
                "required_A_span_nt",
                "required_B_span_nt",
            ),
        )
        for eid, event in sorted(events.items()):
            vals, statuses = [], []
            spans = retention_spans(event.annotations) if event.unit == "IR" else None
            for sid in selected:
                counts = event.counts.get(sid)
                length, rule = event.ir_geometry.get(sid, (None, ""))
                geometry = "not_applicable" if event.unit != "IR" else "unknown"
                fraction = None
                depth = None
                status = "missing_sample"
                if counts is not None:
                    depth = sum(counts)
                    fraction = counts[1] / depth if depth else None
                    status = "usable" if depth >= args.min_informative else "low_coverage"
                    if event.unit == "IR":
                        if rule == RETENTION_RULE and spans and length:
                            impossible = [i for i, span in enumerate(spans) if span > length]
                            if any(counts[i] for i in impossible):
                                raise ValueError(f"{eid}/{sid}: retained count contradicts the declared mate length")
                            geometry = "span_fits_mate"
                            if impossible:
                                geometry = "unobservable_" + "".join("AB"[i] for i in impossible)
                                status = "unobservable_retained_branch"
                                fraction = None
                        elif min(counts) > 0:
                            geometry = "both_branches_observed"
                        elif status == "usable":
                            status = "unknown_IR_observability"
                            fraction = None
                samples.writerow(
                    dict(
                        event_id=eid,
                        sample_id=sid,
                        condition=design[sid]["condition"],
                        Unit=event.unit,
                        A_only_fragments=counts[0] if counts else "NA",
                        B_only_fragments=counts[1] if counts else "NA",
                        informative_fragments=depth if depth is not None else "NA",
                        observed_B_fraction=fraction if fraction is not None else "NA",
                        status=status,
                        ir_observability=geometry,
                        max_mate_length=length or "NA",
                        required_A_span_nt=spans[0] if spans else "NA",
                        required_B_span_nt=spans[1] if spans else "NA",
                    )
                )
                vals.append(fraction)
                statuses.append(status)
            complete = all(s == "usable" for s in statuses)
            status = (
                "tested"
                if complete
                else next(s for s in ("unobservable_retained_branch", "missing_sample",
                                      "unknown_IR_observability", "low_coverage") if s in statuses)
            )
            row = dict(
                event_id=eid,
                Unit=event.unit,
                **event.annotations,
                reference=args.reference,
                comparison=args.comparison,
                n_reference_usable=statuses[:n_ref].count("usable"),
                n_comparison_usable=statuses[n_ref:].count("usable"),
                test_family="IR" if event.unit.upper() == "IR" else "nonIR",
                status=status,
                mean_reference_B_fraction=None,
                mean_comparison_B_fraction=None,
                delta_B_fraction=None,
                p_value=None,
                BH_q=None,
                significant=None,
            )
            if complete:
                ref = sum(vals[:n_ref]) / n_ref
                alt = sum(vals[n_ref:]) / (len(vals) - n_ref)
                row.update(
                    mean_reference_B_fraction=ref,
                    mean_comparison_B_fraction=alt,
                    delta_B_fraction=alt - ref,
                )
                tested.append(row)
                test_values.append(vals)
            rows.append(row)
    return rows, tested, test_values


def write_result(out, events, selected, n_ref, design, args):
    rows, tested, test_values = prepare_result(out, events, selected, n_ref, design, args)
    hits = 0
    values = np.asarray(test_values, dtype=float).reshape(-1, len(selected)).T
    pvals, info = permutations(
        values,
        n_ref,
        args.exact_limit,
        args.permutations,
        args.seed,
        paired=args.pair_column is not None,
    )
    for row, p in zip(tested, pvals):
        row["p_value"] = float(p)
    adjust_bh(rows)
    fields = (
        "event_id",
        "Unit",
        *ANNOTATIONS,
        "reference",
        "comparison",
        "n_reference_usable",
        "n_comparison_usable",
        "test_family",
        "status",
        "mean_reference_B_fraction",
        "mean_comparison_B_fraction",
        "delta_B_fraction",
        "p_value",
        "BH_q",
        "significant",
    )
    with (out / "differential_events.tsv").open("w", encoding="utf8", newline="") as f:
        w = writer(f, fields)
        for row in rows:
            if row["BH_q"] is not None:
                row["significant"] = row["BH_q"] <= args.fdr
                hits += row["significant"]
            w.writerow({k: v if v is not None else "NA" for k, v in row.items()})
    info.update(
        events=len(rows), tested=len(tested), significant=hits, untested=len(rows) - len(tested)
    )
    return info
