"""Experimental molecular event usage with an explicit, fixed denominator.

Abundance summation is established methodology (e.g. SUPPA), not a new
statistical test. This adapter neither changes transcript estimates nor
infers significance from TPM as if TPM were an observed molecule count.
"""
import csv
import json
import math
import tempfile
from pathlib import Path

from .event_bam import prepare_events
from .fragments import model_paths, parse_path


def partitions(events, gtf):
    """Derive disjoint A/B/other transcript sets from local exon geometry."""
    catalogue, excluded = prepare_events(events, gtf)
    _, _, models = model_paths(gtf)
    result = {}
    for eid, (event, _) in catalogue.items():
        start, end = int(event['start']), int(event['end'])
        a, b = (parse_path(event[f'branch_{x}_introns_1based']) for x in ('A', 'B'))
        groups = {'A': [], 'B': [], 'other': []}
        for tid, (chrom, strand, left, right, chain) in models.items():
            if (chrom, strand) != (event['chrom'], event['strand']) or left > start or right < end:
                continue
            local = tuple(j for j in chain if j[0] > start and j[1] < end)
            groups['A' if local == a else 'B' if local == b else 'other'].append(tid)
        if not groups['A'] or not groups['B']:
            raise ValueError(f'{eid}: both annotated branch denominators are required')
        result[eid] = dict(event=event, **{k: sorted(v) for k, v in groups.items()})
    return result, excluded


def read_abundance(path, column='TPM'):
    by_sample = {}
    with Path(path).open() as f:
        reader = csv.DictReader(f, delimiter='\t')
        if not {'sample', 'transcript_id', column} <= set(reader.fieldnames or []):
            raise ValueError('Abundance table needs sample, transcript_id and '+column)
        for row in reader:
            sample, tid = row['sample'], row['transcript_id']
            if not sample or not tid:
                raise ValueError('Empty sample or transcript identifier')
            value = float(row[column])
            if not math.isfinite(value) or value < 0:
                raise ValueError('Abundances must be finite and nonnegative')
            table = by_sample.setdefault(sample, {})
            if tid in table:
                raise ValueError(f'Duplicate abundance for {sample}/{tid}')
            table[tid] = value
    if not by_sample:
        raise ValueError('Empty abundance table')
    return by_sample


def project(groups, abundance):
    """Missing transcript != zero; additional local paths remain auditable."""
    rows = []
    for sid, table in sorted(abundance.items()):
        for eid, group in sorted(groups.items()):
            required = set(group['A']) | set(group['B'])
            missing = sorted(required - table.keys())
            a = math.fsum(table[t] for t in group['A']) if not missing else None
            b = math.fsum(table[t] for t in group['B']) if not missing else None
            total = a+b if not missing else None
            status = 'missing_denominator' if missing else 'zero_denominator' if total == 0 else 'estimated'
            other_complete = set(group['other']) <= table.keys()
            other = math.fsum(table[t] for t in group['other']) if other_complete else None
            full = total+other if total is not None and other is not None else None
            rows.append(dict(sample=sid, event_id=eid, Unit=group['event']['Unit'],
                             branch_A_transcripts=','.join(group['A']),
                             branch_B_transcripts=','.join(group['B']),
                             other_transcripts=','.join(group['other']),
                             A_abundance=a, B_abundance=b, AB_abundance=total,
                             molecular_B_fraction=b/total if status == 'estimated' else None,
                             AB_fraction_of_local_abundance=total/full if full else None,
                             missing_transcripts=','.join(missing), status=status,
                             estimand='molecular_fraction_conditional_on_A_or_B'))
    return rows


def run_event_psi(args):
    from .cli import file_digest
    out = args.out_dir
    if out.exists() or out.is_symlink():
        raise FileExistsError('Choose a new output directory: '+str(out))
    groups, excluded = partitions(args.events, args.gtf)
    abundance = read_abundance(args.abundance, args.value_column)
    rows = project(groups, abundance)
    if not rows:
        raise ValueError('No eligible events')
    info = dict(status='experimental', events=len(groups), samples=len(abundance),
                source_column=args.value_column, excluded=excluded,
                input_sha256={k:file_digest(getattr(args,k)) for k in ('events','gtf','abundance')},
                formula='sum(B abundance) / sum(A or B abundance)',
                limitations=['Not a significance test; do not treat TPM as counts.',
                             'Accuracy depends on the upstream abundance model and catalog.',
                             'Estimated does not imply independently identifiable or validated.',
                             'Other local paths are outside the conditional A/B denominator.'])
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=out.parent, prefix='.sw-event-psi-') as tmp:
        stage = Path(tmp)/'result'; stage.mkdir()
        with (stage/'event_usage.tsv').open('w') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader()
            for row in rows:w.writerow({k:'NA' if v is None else v for k,v in row.items()})
        (stage/'summary.json').write_text(json.dumps(info,indent=2)+'\n')
        if out.exists():raise FileExistsError(str(out))
        stage.rename(out)
    return info
