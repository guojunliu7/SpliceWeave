"""Translate a fixed two-branch catalogue into per-library fragment counts."""

import csv
import hashlib
import re
from collections import Counter
from pathlib import Path

from .as_code import asta_paths
from .fragments import RETENTION_RULE, event_paths, model_paths, read_length_limit, recount
from .tables import ANNOTATIONS, canonical_unit, open_text, table_rows


def gtf_events(path):
    with open_text(path) as stream:
        for line_no, line in enumerate(stream, 1):
            if line.startswith("#") or not line.strip():
                continue
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) != 9:
                raise ValueError(f"{path}:{line_no}: expected nine GTF columns")
            chrom, _, feature, start, end, _, strand, _, attributes = parts
            if feature != "as_event":
                continue
            attrs = dict(re.findall(r'(\w+)\s+"([^"]*)"', attributes))
            if not {"structure", "splice_chain", "flanks"} <= attrs.keys():
                raise ValueError(f"{path}:{line_no}: missing AStalavista structural attributes")
            code, chain, flanks = (attrs[k] for k in ("structure", "splice_chain", "flanks"))
            identity = "\x1f".join((chrom, strand, start, end, code, chain, flanks))
            eid = (
                attrs.get("event_id") or "SW_" + hashlib.sha256(identity.encode()).hexdigest()[:20]
            )
            yield dict(
                event_id=eid,
                chrom=chrom,
                strand=strand,
                start=start,
                end=end,
                AS_code=code,
                splice_chain=chain,
                flanks=flanks,
                gene_names=attrs.get("gene_name", ""),
                transcript_groups=attrs.get("transcript_id", ""),
            )


def prepare_events(path, gtf):
    models, starts, transcripts = model_paths(gtf)
    if not transcripts:
        raise ValueError(f"{gtf}: no transcript exon models")
    is_gtf = str(path).lower().removesuffix(".gz").endswith(".gtf")
    rows = (
        gtf_events(path)
        if is_gtf
        else table_rows(path, ("event_id", "chrom", "strand", "start", "end"))
    )
    events, excluded, seen = {}, [], set()
    for row in rows:
        eid = row["event_id"]
        try:
            if eid in seen:
                raise ValueError("duplicate event_id")
            seen.add(eid)
            code = row.get("AS_code", "")
            if code and (len(code.split(",")) != 2 or "[" in code or "]" in code):
                reason = (
                    "not_two_branches"
                    if len(code.split(",")) != 2
                    else "alternative_transcript_end"
                )
                excluded.append((eid, code, reason))
                continue
            if row.get("Unit"):
                row["Unit"] = canonical_unit(row["Unit"])
            key = (row["chrom"], row["strand"])
            start, end = int(row["start"]), int(row["end"])
            if key not in models or key[1] not in ("+", "-") or not 1 <= start < end:
                raise ValueError("invalid coordinates, strand or mismatch with the model GTF")
            branches = ("branch_A_introns_1based", "branch_B_introns_1based")
            if row.get("AS_code") and "splice_chain" in row and row.get("flanks"):
                unit, a, b = asta_paths(row["AS_code"], row["splice_chain"], row["flanks"], key[1])
                for name, value in zip(("Unit", *branches), (unit, a, b)):
                    if row.setdefault(name, value) != value:
                        raise ValueError(f"{name} disagrees with the AStalavista paths")
            if not row.get("Unit") or not all(k in row for k in branches):
                raise ValueError(
                    "supply Unit and both intron paths, or AS_code, splice_chain and flanks"
                )
            a, b, candidates = event_paths(row, models, starts)
            if row["Unit"].upper() == "IR":
                row["Unit"] = "IR"
            for branch in (a, b):
                if any(not start < x <= y < end for x, y in branch):
                    raise ValueError(
                        "branch introns must be inside the event window (1-based inclusive)"
                    )
            names = row.get("transcript_groups") or row.get("source_transcript_attribute")
            if names:
                groups = names.split(",")
                if len(groups) != 2:
                    raise ValueError("expected two named transcript groups")
                for branch, group in zip((a, b), groups):
                    for tid in group.split("/"):
                        if tid not in transcripts:
                            raise ValueError(f"missing named transcript {tid!r}")
                        chrom, strand, left, right, introns = transcripts[tid]
                        local = tuple(j for j in introns if j[0] > start and j[1] < end)
                        if (chrom, strand) != key or left > start or right < end or local != branch:
                            raise ValueError(f"branch and named transcript {tid!r} disagree")
            events[eid] = row, (a, b, candidates)
        except (ValueError, KeyError) as exc:
            raise ValueError(f"{path}: event {eid}: {exc}") from exc
    if not seen:
        raise ValueError(f"{path}: no event records")
    return events, excluded


CATEGORIES = {
    "A": "A_only_fragments",
    "B": "B_only_fragments",
    "other": "other_path_fragments",
    "ambiguous": "ambiguous_fragments",
    "incompatible": "incompatible_fragments",
    "AB_conflict": "AB_conflict_fragments",
    "IR_insufficient_full_span": "IR_insufficient_full_span_fragments",
}


def generate_counts(out, args, design, selected):
    try:
        import pysam
    except ImportError as exc:
        raise ValueError(
            "BAM input requires pysam; install SpliceWeave with its bam extra"
        ) from exc
    catalogue, excluded = prepare_events(args.events, args.gtf)
    if excluded:
        with (out.parent / "excluded_events.tsv").open("w", encoding="utf8", newline="") as stream:
            w = csv.writer(stream, delimiter="\t", lineterminator="\n")
            w.writerow(("event_id", "AS_code", "reason"))
            w.writerows(excluded)
    max_end = {}
    for row, _ in catalogue.values():
        chrom = row["chrom"]
        max_end[chrom] = max(max_end.get(chrom, 0), int(row["end"]))
    fields = (
        "event_id",
        "sample_id",
        "condition",
        "Unit",
        *ANNOTATIONS,
        *CATEGORIES.values(),
        "max_mate_length",
        "ir_count_rule",
        "informative_AB_fragments",
        "all_observed_fragments",
    )
    seen_bams = set()
    with out.open("w", encoding="utf8", newline="") as stream:
        w = csv.DictWriter(stream, fieldnames=fields, delimiter="\t", lineterminator="\n")
        w.writeheader()
        if not catalogue:
            return dict(Counter(reason for _, _, reason in excluded))
        for sid in selected:
            sample = design[sid]
            path = (args.samples.parent / Path(sample["sr_bam"]).expanduser()).resolve()
            if path in seen_bams:
                raise ValueError(
                    f"{sid}: the same BAM was supplied for multiple biological samples"
                )
            seen_bams.add(path)
            with pysam.AlignmentFile(str(path), "rb", require_index=True) as bam:
                lengths = dict(zip(bam.references, bam.lengths))
                max_mate = read_length_limit(sample.get("max_mate_length"))
                if max_mate is None and any(row["Unit"] == "IR" for row, _ in catalogue.values()):
                    # A local maximum at an individual event would confound low coverage
                    # with a physical library constraint. Measure the entire input BAM.
                    max_mate = max((r.infer_query_length() or 0 for r in bam.fetch(until_eof=True)
                                    if not r.is_unmapped and not r.is_secondary and
                                    not r.is_supplementary), default=0) or None
                for chrom, end in max_end.items():
                    if lengths.get(chrom, 0) < end:
                        raise ValueError(f"{sid}: missing or too-short BAM reference {chrom}")
                for eid, (row, paths) in catalogue.items():
                    counts, total, _ = recount(bam, row, paths, sample["sr_strandedness"])
                    w.writerow(
                        dict(
                            event_id=eid,
                            sample_id=sid,
                            condition=sample["condition"],
                            Unit=row["Unit"],
                            **{k: row.get(k, "") for k in ANNOTATIONS},
                            **{out_key: counts[key] for key, out_key in CATEGORIES.items()},
                            informative_AB_fragments=counts["A"] + counts["B"],
                            all_observed_fragments=total,
                            max_mate_length=max_mate or "",
                            ir_count_rule=RETENTION_RULE if row["Unit"] == "IR" else "",
                        )
                    )
    return dict(Counter(reason for _, _, reason in excluded))
