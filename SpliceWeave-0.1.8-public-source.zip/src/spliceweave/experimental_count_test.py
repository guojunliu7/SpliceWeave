"""Experimental replicate-aware beta-binomial bootstrap score test.

This tests observed unique-branch fragment fractions, NOT molecular TPM PSI.
It is not a default CLI method and has not established external FDR control.
The dispersion prior must be estimated without the tested gene; no truth labels
or selected molecular estimates enter this module. Biology remains sample-level.
"""
import numpy as np


def _inputs(included, total, n_ref):
    y, n = np.asarray(included, float), np.asarray(total, float)
    if (y.ndim != 1 or y.shape != n.shape or not np.isfinite(y).all()
            or not np.isfinite(n).all() or np.any(n <= 0)
            or np.any(y < 0) or np.any(y > n)
            or np.any(y != np.floor(y)) or np.any(n != np.floor(n))):
        raise ValueError('Require finite integer counts with 0 <= included <= total and total > 0')
    if not isinstance(n_ref, (int, np.integer)) or min(n_ref, len(y)-n_ref) < 2:
        raise ValueError('At least two independent biological replicates per group are required')
    return y, n


def excess_dispersion(included, total, n_ref):
    """Within-group method-of-moments ICC; supports bootstrap rows by broadcasting."""
    y, n = np.asarray(included, float), np.asarray(total, float)
    numerator = np.zeros(y.shape[:-1]); denominator = np.zeros(y.shape[:-1])
    for part in (slice(None, n_ref), slice(n_ref, None)):
        a, depth = y[..., part], n[..., part]
        k = a.shape[-1]; fractions = a/depth
        mu = ((a+.5)/(depth+1)).mean(-1)
        ssr = ((fractions-fractions.mean(-1, keepdims=True))**2).sum(-1)
        factor = (1-1/k)*mu*(1-mu)
        numerator += ssr-factor*(1/depth).sum(-1)
        denominator += factor*(1-1/depth).sum(-1)
    return np.clip(numerator/np.maximum(denominator, 1e-12), 0, .95)


def score(included, total, n_ref, prior_rho, prior_df=4):
    """Studentized sample-mean contrast with count noise and replicate dispersion."""
    y, n = np.asarray(included, float), np.asarray(total, float)
    df = y.shape[-1]-2
    rho = np.clip((df*excess_dispersion(y, n, n_ref)+prior_df*prior_rho)/(df+prior_df), 1e-6, .95)
    variance = np.zeros(y.shape[:-1]); means=[]
    for part in (slice(None, n_ref), slice(n_ref, None)):
        a, depth = y[..., part], n[..., part]; k = a.shape[-1]
        mu = ((a+.5)/(depth+1)).mean(-1)
        means.append((a/depth).mean(-1))
        variance += ((mu*(1-mu))[..., None]*(rho[..., None]+(1-rho[..., None])/depth)).sum(-1)/k**2
    delta = means[1]-means[0]
    return delta**2/np.maximum(variance, 1e-15), delta, rho


def bootstrap_test(included, total, n_ref, prior_rho, prior_df=4,
                   draws=9999, seed=20261125, null_rho_floor=None):
    """Parametric null bootstrap; nuisance uncertainty remains a calibration risk.

    Draw independent replicate fractions from Beta(mu*kappa,(1-mu)*kappa),
    then binomial fragment counts. Refit within-group dispersion and recompute
    the statistic for each bootstrap. Use inclusive tails and the +1 rule.
    This Monte Carlo P is conditional on the fitted null and external prior;
    it is not an exact randomization P and is not assumed universally calibrated.
    """
    y, n = _inputs(included, total, n_ref)
    if (not np.isfinite(prior_rho) or not 0 <= prior_rho < 1
            or not np.isfinite(prior_df) or prior_df < 0
            or not isinstance(draws, (int, np.integer)) or draws < 99
            or not isinstance(seed, (int, np.integer)) or seed < 0):
        raise ValueError('Invalid dispersion prior, bootstrap draws or seed')
    statistic, delta, rho = score(y, n, n_ref, prior_rho, prior_df)
    if null_rho_floor is not None and (not np.isfinite(null_rho_floor) or not 0 <= null_rho_floor < 1):
        raise ValueError('Invalid externally specified null dispersion floor')
    null_rho = max(float(rho), float(null_rho_floor or 0))
    mu = float(np.clip((y/n).mean(), 1e-6, 1-1e-6))
    concentration = (1-null_rho)/null_rho
    rng = np.random.default_rng(seed); extreme=0
    for start in range(0, draws, 512):
        size=(min(512, draws-start), len(y))
        latent=rng.beta(mu*concentration, (1-mu)*concentration, size=size)
        simulated=rng.binomial(n.astype(int), latent)
        stats, _, _=score(simulated, n, n_ref, prior_rho, prior_df)
        extreme += int(np.count_nonzero(stats >= float(statistic)-1e-12))
    return dict(delta_observed=float(delta), statistic=float(statistic),
                p_value=(extreme+1)/(draws+1), rho=float(rho),
                raw_rho=float(excess_dispersion(y, n, n_ref)),
                prior_rho=float(prior_rho), prior_df=float(prior_df), draws=int(draws),
                null_rho=null_rho, null_rho_floor=null_rho_floor,
                seed=int(seed), estimand='comparison minus reference observed B/(A+B)',
                method='experimental_beta_binomial_bootstrap_score')
