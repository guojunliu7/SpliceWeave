"""Experimental abundance-backed rescue of undercovered splice events.

This module produces *empirical scores*, not calibrated p-values. It must not
be used as a default significance test or given an FDR interpretation without
independent null calibration. Evidence from an unobservable IR branch is not
promoted to a confirmed event by the hybrid selector.
"""
from itertools import combinations

import numpy as np
import pandas as pd


def abundance_matched_scores(usage, event_genes, *, area=100, min_replicates=2):
    """Compare molecular ΔPSI to within-group changes at similar abundance.

    Parameters
    ----------
    usage : DataFrame
        Columns: event_id, sample, group, molecular_B_fraction, AB_abundance.
        ``sample`` is retained for audit; independent biological samples are
        the rows. The caller must verify sample provenance.
    event_genes : mapping
        Event ID to gene ID. Every target is compared only with *other genes*.
    area : int
        Maximum number of nearest-abundance within-group comparison pairs.
    min_replicates : int
        Minimum observed biological samples in each condition.
    """
    required={'event_id','sample','group','molecular_B_fraction','AB_abundance'}
    if not required.issubset(usage) or area<1 or min_replicates<2:
        raise ValueError('Invalid molecular usage table or score settings')
    x=usage.copy()
    if x.duplicated(['event_id','sample']).any() or x['group'].isna().any():
        raise ValueError('Each event/sample observation must be unique and grouped')
    if (x.AB_abundance.dropna()<0).any() or ((x.molecular_B_fraction.dropna()<0)|(x.molecular_B_fraction.dropna()>1)).any():
        raise ValueError('Abundance and fractions must be nonnegative and fractions within [0,1]')
    x['gene']=x.event_id.map(event_genes)
    if x.gene.isna().any():
        raise ValueError('Every event needs a gene for leave-gene-out background')
    x['log_abundance']=np.log1p(x.AB_abundance)
    background=[]
    for (_,gene,group),g in x.groupby(['event_id','gene','group']):
        g=g.dropna(subset=['molecular_B_fraction'])
        for a,b in combinations(g.molecular_B_fraction.to_numpy(),2):
            background.append((gene,abs(a-b),float(g.log_abundance.mean())))
    background=pd.DataFrame(background,columns=['gene','within_delta','log_abundance'])
    result=[]
    for (eid,gene),g in x.groupby(['event_id','gene']):
        groups=[v.dropna(subset=['molecular_B_fraction']) for _,v in g.groupby('group',sort=True)]
        if len(groups)!=2 or min(map(len,groups))<min_replicates:
            result.append(dict(event_id=eid,score=np.nan,delta=np.nan,reference_pairs=0,status='insufficient_samples'))
            continue
        delta=float(groups[1].molecular_B_fraction.mean()-groups[0].molecular_B_fraction.mean())
        target_ab=float(g.log_abundance.mean())
        ref=background[background.gene!=gene].copy()
        if ref.empty:
            result.append(dict(event_id=eid,score=np.nan,delta=delta,reference_pairs=0,status='no_external_genes'))
            continue
        ref['distance']=(ref.log_abundance-target_ab).abs()
        ref=ref.nsmallest(min(area,len(ref)),'distance')
        score=(1+int((ref.within_delta>=abs(delta)-1e-12).sum()))/(len(ref)+1)
        result.append(dict(event_id=eid,score=score,delta=delta,reference_pairs=len(ref),status='scored'))
    return pd.DataFrame(result)


def choose_evidence(count_score, count_delta, count_accepted,
                    molecular_score, molecular_delta, *, ir_unobservable=False):
    """Select the prespecified evidence source without using a truth label."""
    if count_accepted and np.isfinite(count_score) and np.isfinite(count_delta):
        return dict(source='count',score=float(count_score),delta=float(count_delta))
    if ir_unobservable:
        return dict(source='unresolved_IR',score=np.nan,delta=np.nan)
    if np.isfinite(molecular_score) and np.isfinite(molecular_delta):
        return dict(source='molecular',score=float(molecular_score),delta=float(molecular_delta))
    return dict(source='unresolved',score=np.nan,delta=np.nan)


def write_rescue_results(out, usage_path, events, count_rows, selected, n_ref, min_effect):
    """Write an auditable exploratory ranking from a single, ordered contrast."""
    from .count_differential import event_gene
    from .joint_differential import adjust, write_tsv
    from .tables import canonical_unit

    usage = pd.read_csv(usage_path, sep='\t', dtype=str, keep_default_na=False)
    required = {'event_id', 'sample', 'Unit', 'status', 'molecular_B_fraction', 'AB_abundance'}
    if not required.issubset(usage.columns):
        raise ValueError(f'{usage_path}: expected event-psi output with columns {sorted(required)}')
    missing_samples = set(selected) - set(usage['sample'])
    if missing_samples:
        raise ValueError(f'{usage_path}: missing selected samples {sorted(missing_samples)}')
    usage = usage[usage['sample'].isin(selected) & usage.event_id.isin(events)].copy()
    if usage.empty or usage.duplicated(['event_id', 'sample']).any():
        raise ValueError(f'{usage_path}: no shared events or duplicate event/sample IDs')
    units = {eid: event.unit for eid, event in events.items()}
    if not (usage.Unit.map(canonical_unit) == usage.event_id.map(units)).all():
        raise ValueError('Event types differ between molecular usage and count catalog')
    # Use explicit contrast order, including when the reference sorts last.
    usage['group'] = usage['sample'].map({sid: int(i >= n_ref) for i, sid in enumerate(selected)})
    genes = {eid: event_gene(event) for eid, event in events.items()}
    usable = usage.status.eq('estimated') & usage.event_id.map(genes).notna()
    usage = usage[usable].copy()
    for column in ('AB_abundance', 'molecular_B_fraction'):
        usage[column] = pd.to_numeric(usage[column], errors='raise')
        if not np.isfinite(usage[column]).all():
            raise ValueError(f'Estimated rows need finite {column}')
    if (usage.AB_abundance <= 0).any():
        raise ValueError('Estimated rows require positive AB_abundance')
    scores = {}
    if len(usage):
        scores = abundance_matched_scores(usage, genes).set_index('event_id').to_dict('index')

    output = []
    for row in count_rows:
        eid = row['event_id']
        event = events[eid]
        counts = [sum(event.counts.get(sid) or (0, 0)) for sid in selected]
        group_pass = all(2 * sum(depth >= 5 for depth in group) >= len(group)
                         for group in (counts[:n_ref], counts[n_ref:]))
        molecular = scores.get(eid, {})
        score = molecular.get('score', np.nan)
        delta = molecular.get('delta', np.nan)
        blocked = row['status'] in ('unobservable_retained_branch', 'unknown_IR_observability')
        choice = choose_evidence(row['p_value'], row['delta_B_fraction'],
                                 group_pass and row['p_value'] is not None,
                                 score, delta, ir_unobservable=blocked)
        output.append(dict(event_id=eid, gene=genes[eid], count_status=row['status'],
                           count_group_pass=group_pass, molecular_status=molecular.get('status','unavailable'),
                           reference_pairs=molecular.get('reference_pairs', 0), **choice))

    ranks = adjust([r['score'] for r in output], 'BH')
    for row, rank in zip(output, ranks):
        row['adjusted_rank_score'] = rank
        row['candidate'] = bool(rank <= .05 and abs(row['delta']) >= min_effect)
    write_tsv(out/'coverage_rescue.tsv', output)
    return dict(file='coverage_rescue.tsv', model='experimental-coverage-rescue-v1',
                scored=int(np.isfinite(ranks).sum()), candidates=sum(r['candidate'] for r in output),
                score_cutoff=.05, min_effect=min_effect, abundance_neighbors=100,
                group_min_fragments=5, minimum_fraction_per_group=.5,
                score_interpretation='exploratory ranking; independent FDR calibration pending')
