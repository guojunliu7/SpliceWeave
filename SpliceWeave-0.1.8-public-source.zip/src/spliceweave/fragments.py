"""Portable counting kernel from recount_stage2_sr_fragments_20261030 (1-based closed)."""

from __future__ import annotations

import bisect
import gzip
import re
from collections import defaultdict

RETENTION_ANCHOR = 8
RETENTION_RULE = "single_mate_full_span"


def retention_spans(annotations):
    """Minimum sequenced bases required on one mate, for each retained branch."""
    keys = ("branch_A_introns_1based", "branch_B_introns_1based")
    if not all(k in annotations for k in keys):
        return None
    a, b = (set(parse_path(annotations[k])) for k in keys)
    if a == b:
        return None
    if any(lo < 1 or hi < lo for lo, hi in a | b):
        raise ValueError("invalid retained-intron coordinates")
    return tuple(max((hi - lo + 1 + 2 * RETENTION_ANCHOR for lo, hi in diff), default=0)
                 for diff in (b - a, a - b))


def read_length_limit(value):
    if value is None or str(value).strip().lower() in {"", ".", "na", "unknown"}:
        return None
    size = int(value)
    if size <= 0:
        raise ValueError("max_mate_length must be a positive number of bases")
    return size

def parse_path(value):
    return tuple(tuple(int(z) for z in intron.split("-")) for intron in value.split(";") if intron)


def model_paths(gtf):
    """Sorted transcript intervals; GTF exon coordinates are 1-based inclusive."""
    exons = defaultdict(list)
    loci = {}
    opener = gzip.open if str(gtf).endswith(".gz") else open
    with opener(gtf, "rt") as f:
        for line in f:
            a = line.rstrip("\n").split("\t")
            if len(a) != 9 or a[2] != "exon":
                continue
            match = re.search(r'(?:^|;)\s*transcript_id\s+"([^"]+)"', a[8])
            if not match:
                raise ValueError("Missing transcript_id on GTF exon")
            tid = match[1]
            loc = (a[0], a[6])
            if tid in loci and loci[tid] != loc:
                raise ValueError(f"transcript locus changed: {tid}")
            loci[tid] = loc
            exons[tid].append((int(a[3]), int(a[4])))
    by_locus = defaultdict(list)
    transcripts = {}
    for tid, ee in exons.items():
        ee.sort()
        if any(left < 1 or right < left for left, right in ee):
            raise ValueError(f"invalid exon coordinates: {tid}")
        if any(a[1] + 1 >= b[0] for a, b in zip(ee, ee[1:])):
            raise ValueError(f"overlapping or adjacent exons: {tid}")
        introns = tuple((a[1] + 1, b[0] - 1) for a, b in zip(ee, ee[1:]))
        model = (ee[0][0], ee[-1][1], introns)
        by_locus[loci[tid]].append(model)
        transcripts[tid] = (*loci[tid], *model)
    for models in by_locus.values():
        models.sort(key=lambda x: x[0])
    starts = {key: [m[0] for m in models] for key, models in by_locus.items()}
    return by_locus, starts, transcripts


def event_paths(event, models, starts):
    key = (event["chrom"], event["strand"])
    start, end = int(event["start"]), int(event["end"])
    branch_a = parse_path(event["branch_A_introns_1based"])
    branch_b = parse_path(event["branch_B_introns_1based"])
    if branch_a == branch_b:
        raise ValueError("A and B branches identical")
    candidates = set()
    arr = models.get(key, ())
    upper = bisect.bisect_right(starts.get(key, ()), start)
    for left, right, introns in arr[:upper]:
        if right >= end:
            candidates.add(tuple(x for x in introns if x[0] > start and x[1] < end))
    if not {branch_a, branch_b}.issubset(candidates):
        raise ValueError("model GTF does not contain both local branches")
    return branch_a, branch_b, candidates


def transcript_strand(read, library):
    if library == "unstranded":
        return None
    if not (read.is_read1 or read.is_read2):
        return None
    genomic_plus = not read.is_reverse
    same = (read.is_read1 and library == "forward_stranded") or (
        read.is_read2 and library == "reverse_stranded"
    )
    return "+" if genomic_plus == same else "-"


def mate_evidence(read, min_anchor):
    # Pysam get_blocks reports observed aligned segments. An N CIGAR op is a
    # splice only when the adjacent match operations both meet the anchor rule.
    blocks = tuple((s + 1, e) for s, e in read.get_blocks())
    introns = []
    pos = read.reference_start
    ops = read.cigartuples or ()
    for i, (op, size) in enumerate(ops):
        if op == 3:
            before = ops[i - 1][1] if i and ops[i - 1][0] in (0, 7, 8) else 0
            after = ops[i + 1][1] if i + 1 < len(ops) and ops[i + 1][0] in (0, 7, 8) else 0
            if min(before, after) < min_anchor:
                return None
            introns.append((pos + 1, pos + size))
        if op in (0, 2, 3, 7, 8):
            pos += size
    return blocks, tuple(introns)


def classify_fragment(mates, start, end, branch_a, branch_b, candidates, unit=""):
    """Classify observed bases; IR retention requires a sequenced full span."""
    blocks = [b for blockset, _ in mates for b in blockset]
    observed = {j for _, joints in mates for j in joints if j[0] > start and j[1] < end}
    if observed & (set(branch_a) - set(branch_b)) and observed & (set(branch_b) - set(branch_a)):
        return "AB_conflict"
    if any(
        max(block[0], intron[0]) <= min(block[1], intron[1])
        for intron in observed
        for block in blocks
    ):
        return "AB_conflict"
    compatible = set()
    for path in candidates:
        if not observed.issubset(path):
            continue
        if any(
            max(block[0], intron[0]) <= min(block[1], intron[1])
            for intron in path
            for block in blocks
        ):
            continue
        compatible.add(path)
    if len(compatible) != 1:
        return "ambiguous" if compatible else "incompatible"
    path = next(iter(compatible))
    if unit == "IR" and path in (branch_a, branch_b):
        other = branch_b if path == branch_a else branch_a
        retained = set(other) - set(path)
        if retained and not all(
            any(block[0] <= intron[0] - RETENTION_ANCHOR and
                block[1] >= intron[1] + RETENTION_ANCHOR for block in blocks)
            for intron in retained
        ):
            return "IR_insufficient_full_span"
    return "A" if path == branch_a else "B" if path == branch_b else "other"


def recount(bam, event, paths, library, min_mapq=20, min_anchor=8):
    start, end = int(event["start"]), int(event["end"])
    by_name = defaultdict(dict)
    for read in bam.fetch(event["chrom"], start - 1, end):
        if (
            read.is_unmapped
            or read.is_secondary
            or read.is_supplementary
            or read.is_duplicate
            or read.is_qcfail
            or not read.is_proper_pair
            or read.mapping_quality < min_mapq
        ):
            continue
        strand = transcript_strand(read, library)
        if strand is not None and strand != event["strand"]:
            continue
        ev = mate_evidence(read, min_anchor)
        if ev is None:
            continue
        mate = 1 if read.is_read1 else 2 if read.is_read2 else 0
        if not mate:
            continue
        name = (read.get_tag("RG") if read.has_tag("RG") else None, read.query_name)
        old = by_name[name].get(mate)
        if old is not None and old != ev:
            raise ValueError("multiple distinct primary alignments for a mate")
        by_name[name][mate] = ev
    counts = dict.fromkeys(
        (
            "A",
            "B",
            "other",
            "ambiguous",
            "incompatible",
            "AB_conflict",
            "IR_insufficient_full_span",
        ),
        0,
    )
    both_mates = 0
    for per_name in by_name.values():
        both_mates += len(per_name) == 2
        kind = classify_fragment(list(per_name.values()), start, end, *paths, unit=event["Unit"])
        counts[kind] += 1
    return counts, len(by_name), both_mates
