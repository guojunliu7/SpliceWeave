"""Synchronized biological-sample tests for two-platform splice usage.

Tests concern observed branch fractions, not capture-corrected abundance. A
significant average is distinct from evidence for change in both platforms.
"""
import csv
import itertools
import json
import math
import tempfile
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from .differential import write_result
from .tables import ANNOTATIONS, read_counts, read_design, table_rows


def directional_permutations(values, n_ref, exact_limit=10000, draws=10000,
                             seed=1, paired=False):
    """Shared allocations for all columns; inclusive tails and +1 Monte Carlo."""
    values = np.asarray(values, dtype=float)
    if values.ndim != 2 or not np.isfinite(values).all():
        raise ValueError('Permutation input must be a finite samples-by-events matrix')
    n, m = values.shape
    if not 1 <= n_ref < n or (paired and n != 2*n_ref):
        raise ValueError('Invalid group sizes or matched-pair ordering')
    if min(exact_limit, draws) < 1 or seed < 0:
        raise ValueError('Invalid permutation limits or seed')
    n_alt = n - n_ref
    total = 2**n_ref if paired else math.comb(n, n_alt)
    exact = total <= exact_limit
    trials = total if exact else draws
    rng = np.random.default_rng(seed)
    obs = values[n_ref:].mean(0) - values[:n_ref].mean(0)
    if paired:
        swaps = itertools.product((0, 1), repeat=n_ref) if exact else (
            rng.integers(0, 2, n_ref) for _ in range(trials))
        allocations = (np.arange(n_ref) + n_ref*np.asarray(s) for s in swaps)
    else:
        allocations = itertools.combinations(range(n), n_alt) if exact else (
            rng.choice(n, n_alt, replace=False) for _ in range(trials))
    counts = np.zeros((3, m), dtype=np.int64)
    sums = values.sum(0)
    while batch := list(itertools.islice(allocations, 128)):
        mask = np.zeros((len(batch), n))
        mask[np.arange(len(batch))[:, None], np.asarray(batch)] = 1
        for start in range(0, m, 1024):
            part = slice(start, start+1024)
            alt = mask @ values[:, part]
            dif = alt/n_alt - (sums[part]-alt)/n_ref
            counts[0, part] += (np.abs(dif) >= np.abs(obs[part])-1e-12).sum(0)
            counts[1, part] += (dif >= obs[part]-1e-12).sum(0)
            counts[2, part] += (dif <= obs[part]+1e-12).sum(0)
    p = counts/trials if exact else (counts+1)/(trials+1)
    return obs, p, dict(method='exact' if exact else 'monte_carlo',
                       possible_assignments=total, permutations_per_test=trials,
                       seed=None if exact else seed)


def joint_statistics(short, long, n_ref, **kwargs):
    """Equal-platform contrast, platform interaction, directional conjunction."""
    short, long = np.asarray(short), np.asarray(long)
    if short.shape != long.shape:
        raise ValueError('Platforms must have identical sample/event axes')
    m = short.shape[1]
    obs, p, info = directional_permutations(
        np.concatenate((short, long, (short+long)/2, long-short), axis=1), n_ref, **kwargs)
    # Intersection-union within a prespecified direction; Bonferroni over two
    # directions. Independence of technologies is neither assumed nor required.
    concordant = np.minimum(1, 2*np.minimum(
        np.maximum(p[1, :m], p[1, m:2*m]),
        np.maximum(p[2, :m], p[2, m:2*m])))
    result = {f'{name}_delta': obs[i*m:(i+1)*m] for i, name in
              enumerate(('short', 'long', 'joint', 'interaction'))}
    result.update({f'{name}_p': p[0, i*m:(i+1)*m] for i, name in
                   enumerate(('short', 'long', 'joint', 'interaction'))})
    result['concordance_p'] = concordant
    return result, info


def adjust(p, method='BY'):
    """BH or dependence-robust BY, retaining NaN for untested hypotheses."""
    p = np.asarray(p, dtype=float)
    q = np.full(p.shape, np.nan)
    valid = np.flatnonzero(np.isfinite(p))
    if not len(valid):
        return q
    if method not in ('BH', 'BY') or np.any((p[valid] < 0) | (p[valid] > 1)):
        raise ValueError('Invalid adjustment or p-values')
    order = valid[np.argsort(p[valid], kind='stable')]
    m = len(order)
    factor = sum(1/i for i in range(1, m+1)) if method == 'BY' else 1
    q[order] = np.minimum(1, np.minimum.accumulate(
        (p[order]*m*factor/np.arange(1, m+1))[::-1])[::-1])
    return q


def read_tsv(path):
    with path.open() as f:
        return list(csv.DictReader(f, delimiter='\t'))


def write_tsv(path, rows, fields=None):
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0]), delimiter='\t', lineterminator='\n')
        w.writeheader()
        for row in rows:
            w.writerow({k: ('NA' if v is None or (isinstance(v, (float, np.floating))
                         and not np.isfinite(v)) else v) for k, v in row.items()})


def run_joint(args):
    from .cli import file_digest
    from .event_bam import generate_counts, prepare_events
    from .joint_event_bam import generate_long_counts
    if min(args.min_short, args.min_long, args.exact_limit, args.permutations) < 1 or args.seed < 0:
        raise ValueError('Positive depth/permutation limits and nonnegative seed required')
    if not 0 < args.fdr <= 1:
        raise ValueError('FDR must be in (0,1]')
    bam_mode = args.events is not None
    if bam_mode:
        if not args.gtf or args.short_counts or args.long_counts or args.catalog:
            raise ValueError('Use --events + --gtf, or --short-counts + --long-counts + --catalog')
    elif not (args.short_counts and args.long_counts and args.catalog) or args.gtf:
        raise ValueError('Count mode requires both platform count tables and a common --catalog')
    if args.out_dir.exists():
        raise FileExistsError(f'Choose a new output directory: {args.out_dir}')
    design, selected, n_ref = read_design(args.samples, args.reference, args.comparison,
                                         bam_mode, args.pair_column)
    lr_design = {s: {k: v for k, v in row.items() if k not in ('max_mate_length','ir_count_rule')}
                 for s, row in design.items()}
    for s, row in lr_design.items():
        if row.get('max_long_read_length'):
            row['max_mate_length'] = row['max_long_read_length']
        if row.get('lr_ir_count_rule'):
            row['ir_count_rule'] = row['lr_ir_count_rule']
    args.out_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.out_dir.parent, prefix='.sw-joint-') as temp:
        out = Path(temp)/'result'
        out.mkdir()
        catalog = args.catalog
        short_counts, long_counts = args.short_counts, args.long_counts
        excluded = {}
        if bam_mode:
            events, exc = prepare_events(args.events, args.gtf)
            if not events:
                raise ValueError('No eligible two-branch events')
            catalog = out/'event_catalog.tsv'
            write_tsv(catalog, [dict(event_id=eid, Unit=r['Unit'], **{k:r.get(k,'') for k in ANNOTATIONS})
                                for eid,(r,_) in events.items()])
            short_counts, long_counts = out/'short_counts.tsv', out/'long_counts.tsv'
            excluded = generate_counts(short_counts, args, design, selected)
            generate_long_counts(long_counts, args, lr_design, selected, events)
        for row in table_rows(catalog, ('event_id','Unit','chrom','strand','start','end',
                                        'branch_A_introns_1based','branch_B_introns_1based'),
                              allow_empty=('branch_A_introns_1based','branch_B_introns_1based')):
            from .fragments import parse_path
            start, end = int(row['start']), int(row['end'])
            if row['strand'] not in ('+','-') or not 1 <= start < end:
                raise ValueError(f"{row['event_id']}: invalid catalog coordinates or strand")
            for key in ('branch_A_introns_1based','branch_B_introns_1based'):
                path = parse_path(row[key])
                if any(len(j) != 2 for j in path) or any(not start < lo <= hi < end for lo,hi in path):
                    raise ValueError(f"{row['event_id']}: invalid branch coordinates")
                if any(a[1] >= b[0] for a,b in zip(path,path[1:])):
                    raise ValueError(f"{row['event_id']}: unordered or overlapping branch introns")
            if row['branch_A_introns_1based'] == row['branch_B_introns_1based']:
                raise ValueError(f"{row['event_id']}: identical branch definitions")
        platforms = {}
        for name, counts, sd, depth in (
            ('short',short_counts,design,args.min_short), ('long',long_counts,lr_design,args.min_long)):
            events = read_counts(counts, sd, selected, catalog)
            sub = out/name
            sub.mkdir()
            options = SimpleNamespace(**vars(args), min_informative=depth)
            write_result(sub, events, selected, n_ref, sd, options)
            results = read_tsv(sub/'differential_events.tsv')
            # Recompute per-platform multiplicity over ALL tested event types.
            q = adjust([float(r['p_value']) if r['p_value'] != 'NA' else np.nan for r in results], args.adjustment)
            for r, v in zip(results, q):
                r['legacy_BH_q_within_event_type'] = r.pop('BH_q')
                r['adjustment'] = args.adjustment
                r['adjusted_q'] = v
                r['significant'] = bool(v <= args.fdr)
            write_tsv(sub/'differential_events.tsv', results)
            usage = {(r['event_id'],r['sample_id']):r for r in read_tsv(sub/'sample_usage.tsv')}
            platforms[name] = ({r['event_id']:r for r in results}, usage)
        ids = sorted(platforms['short'][0])
        tested = [e for e in ids if all(platforms[p][0][e]['status']=='tested' for p in platforms)]
        matrices = [np.array([[float(platforms[p][1][(e,s)]['observed_B_fraction'])
                              for e in tested] for s in selected]).reshape(len(selected),len(tested))
                    for p in ('short','long')]
        stats, info = joint_statistics(*matrices, n_ref, exact_limit=args.exact_limit,
            draws=args.permutations, seed=args.seed, paired=bool(args.pair_column))
        for name in ('joint','interaction','concordance'):
            stats[name+'_q'] = adjust(stats[name+'_p'], args.adjustment)
        lookup = {eid:i for i,eid in enumerate(tested)}
        rows = []
        for eid in ids:
            sr,lr = [platforms[p][0][eid] for p in ('short','long')]
            row = dict(event_id=eid, Unit=sr['Unit'], **{k:sr.get(k,'') for k in ANNOTATIONS},
                       short_status=sr['status'], long_status=lr['status'])
            for p,r in (('short',sr),('long',lr)):
                for name, key in (('delta','delta_B_fraction'),('p','p_value'),('q','adjusted_q')):
                    row[p+'_'+name] = float(r[key]) if r[key]!='NA' else np.nan
            for name in ('joint_delta','interaction_delta','joint_p','joint_q',
                         'interaction_p','interaction_q','concordance_p','concordance_q'):
                row[name] = float(stats[name][lookup[eid]]) if eid in lookup else np.nan
            row['opposite_direction'] = bool(row['short_delta']*row['long_delta'] < 0)
            row['joint_associated'] = bool(row['joint_q'] <= args.fdr)
            row['cross_platform_supported'] = bool(row['concordance_q'] <= args.fdr)
            row['platform_interaction'] = bool(row['interaction_q'] <= args.fdr)
            row['platform_conflict'] = row['platform_interaction'] and row['opposite_direction']
            row['status'] = ('platform_conflict' if row['platform_conflict'] else
                             'platform_effect_heterogeneity' if row['platform_interaction'] else
                             'cross_platform_supported' if row['cross_platform_supported'] else
                             'joint_associated_not_replicated' if row['joint_associated'] else
                             'tested_not_significant' if eid in lookup else
                             'single_platform_only' if 'tested' in (sr['status'],lr['status']) else
                             'insufficient_evidence')
            rows.append(row)
        write_tsv(out/'joint_differential_events.tsv', rows)
        inputs = {k:getattr(args,k) for k in ('samples','short_counts','long_counts','catalog','events','gtf')
                  if getattr(args,k) is not None}
        info.update(module='joint-differential-v1', events=len(ids), joint_tested=len(tested),
                    joint_associated=sum(r['joint_associated'] for r in rows),
                    cross_platform_supported=sum(r['cross_platform_supported'] for r in rows),
                    platform_conflicts=sum(r['platform_conflict'] for r in rows),
                    platform_interactions=sum(r['platform_interaction'] for r in rows),
                    samples=selected, n_reference=n_ref, reference=args.reference, comparison=args.comparison,
                    paired=bool(args.pair_column), pair_column=args.pair_column,
                    adjustment=args.adjustment, fdr=args.fdr, min_short=args.min_short, min_long=args.min_long,
                    multiplicity='Each endpoint separately; all tested IR and nonIR together',
                    estimand='comparison minus reference mean observed B/(A+B); joint=(short+long)/2',
                    primary_endpoint='joint association; concordance and interaction are separate claims',
                    minimum_two_sided_p=(min(1,(2 if len(selected)==2*n_ref else 1)/info['possible_assignments']) if info['method']=='exact'
                                        else 1/(args.permutations+1)),
                    caveats=['Label-exchangeability required; paired mode requires exchangeability within pairs.',
                             'No batch/covariate adjustment; condition-confounded platforms cannot establish biology.',
                             'No evidence of interaction is not evidence of equivalence.',
                             'Observed fractions are not capture-bias-corrected biological PSI.',
                             'Fixed two-branch catalog; detection recall is not de novo event-discovery recall.'],
                    excluded_catalog_events=excluded, input_sha256={k:file_digest(p) for k,p in inputs.items()})
        info['count_sha256'] = {'short':file_digest(short_counts), 'long':file_digest(long_counts),
                                'catalog':file_digest(catalog)}
        if bam_mode:
            manifest = []
            for sid in selected:
                for platform, key in (('short','sr_bam'),('long','lr_bam')):
                    path = (args.samples.parent/Path(design[sid][key]).expanduser()).resolve()
                    st = path.stat()
                    manifest.append(dict(sample_id=sid, platform=platform, path=str(path),
                                         bytes=st.st_size, mtime_ns=st.st_mtime_ns))
            write_tsv(out/'bam_manifest.tsv',manifest)
        (out/'summary.json').write_text(json.dumps(info,indent=2)+'\n')
        if args.out_dir.exists():
            raise FileExistsError(f'Output appeared during run: {args.out_dir}')
        out.rename(args.out_dir)
    return info
