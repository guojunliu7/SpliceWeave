"""Long-read observations of the same local branches used by paired short reads."""
from pathlib import Path
from .event_bam import CATEGORIES
from .fragments import mate_evidence, classify_fragment, RETENTION_RULE
from .tables import ANNOTATIONS


def long_strand(read, rule):
    if rule == 'forward':
        return '-' if read.is_reverse else '+'
    if rule == 'reverse':
        return '+' if read.is_reverse else '-'
    if rule == 'tag':
        # XS is transcript strand in genomic coordinates. Minimap2 ts denotes
        # strand relative to the original read, so reverse alignments flip it.
        if read.has_tag('XS') and read.get_tag('XS') in ('+','-'):
            return read.get_tag('XS')
        if read.has_tag('ts') and read.get_tag('ts') in ('+','-'):
            plus = read.get_tag('ts') == '+'
            return '+' if plus != read.is_reverse else '-'
        return None
    raise ValueError('lr_strand_rule must be forward, reverse, or tag')


def generate_long_counts(out, args, design, selected, events):
    import pysam
    from .joint_differential import write_tsv
    rows, seen = [], set()
    for sid in selected:
        sample = design[sid]
        if not sample.get('lr_bam') or not sample.get('lr_strand_rule'):
            raise ValueError(f'{sid}: BAM mode requires lr_bam and lr_strand_rule')
        rule = sample['lr_strand_rule']
        if rule not in ('forward','reverse','tag'):
            raise ValueError(f'{sid}: invalid lr_strand_rule')
        path = (args.samples.parent/Path(sample['lr_bam']).expanduser()).resolve()
        if path in seen:
            raise ValueError('Same long-read BAM used for multiple biological samples')
        sr_paths = {(args.samples.parent/Path(design[s]['sr_bam']).expanduser()).resolve() for s in selected}
        if path in sr_paths:
            raise ValueError('A BAM cannot represent both platforms')
        seen.add(path)
        with pysam.AlignmentFile(str(path),'rb',require_index=True) as bam:
            maxlen = max((r.infer_query_length() or 0 for r in bam.fetch(until_eof=True)
                          if not r.is_unmapped and not r.is_secondary and not r.is_supplementary), default=0)
            for eid,(event,paths) in events.items():
                counts = dict.fromkeys(CATEGORIES,0)
                observations = {}
                skipped = 0
                start,end = int(event['start']),int(event['end'])
                if event['chrom'] not in bam.references or bam.get_reference_length(event['chrom']) < end:
                    raise ValueError(f'{sid}: incompatible reference for {eid}')
                for r in bam.fetch(event['chrom'],start-1,end):
                    if (r.is_unmapped or r.is_secondary or r.is_supplementary or r.is_duplicate
                            or r.is_qcfail or r.mapping_quality < 20):
                        continue
                    strand = long_strand(r,rule)
                    if strand is None:
                        skipped += 1
                        continue
                    if strand != event['strand']:
                        continue
                    evidence = mate_evidence(r,8)
                    if evidence is None:
                        continue
                    key = (r.get_tag('RG') if r.has_tag('RG') else '', r.query_name)
                    if key in observations and observations[key] != evidence:
                        raise ValueError(f'{sid}: distinct primary alignments for one molecule')
                    observations[key] = evidence
                for ev in observations.values():
                    counts[classify_fragment([ev],start,end,*paths,unit=event['Unit'])] += 1
                rows.append(dict(event_id=eid,sample_id=sid,condition=sample['condition'],Unit=event['Unit'],
                    **{k:event.get(k,'') for k in ANNOTATIONS},
                    **{v:counts[k] for k,v in CATEGORIES.items()}, informative_AB_fragments=counts['A']+counts['B'],
                    all_observed_fragments=len(observations),unknown_strand_alignments=skipped,
                    max_mate_length=maxlen or '',ir_count_rule=RETENTION_RULE if event['Unit']=='IR' else ''))
    write_tsv(out,rows)
