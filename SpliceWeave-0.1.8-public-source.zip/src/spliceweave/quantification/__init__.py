"""Fixed-catalogue native observation likelihood quantification."""
