"""Frozen geometry_MAP_joint likelihood, promoted from the 2026-11-24 comparison.
No competitor imports, concentration truth, or direction gate.
"""
import numpy as np
from scipy.sparse import csr_matrix
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import minimize
from collections import defaultdict


def valid_starts(length, junctions, fragment_lengths, reads, anchor=8):
    """Exact integer starts for each fragment length; each observed mate meets anchor."""
    F=np.asarray(fragment_lengths,dtype=int);upper=length-F;total=np.maximum(upper+1,0)
    intervals=[]
    offsets=[np.zeros_like(F)] if len(reads)==1 else [np.zeros_like(F),F-reads[1]]
    for off,r in zip(offsets,reads):
        for j in junctions:
            for lo,hi in [(j-off-anchor+1,j-off-1),(j-off-r+1,j-off-r+anchor-1)]:
                lo=np.maximum(lo,0);hi=np.minimum(hi,upper)
                intervals.append((lo,np.maximum(hi+1,lo)))
    if intervals:
        lo=np.stack([x[0] for x in intervals]);hi=np.stack([x[1] for x in intervals]);order=np.argsort(lo,axis=0)
        lo=np.take_along_axis(lo,order,axis=0);hi=np.take_along_axis(hi,order,axis=0)
        previous=np.vstack([np.zeros_like(F),np.maximum.accumulate(hi,axis=0)[:-1]])
        total=total-np.maximum(hi-np.maximum(lo,previous),0).sum(0)
    return np.where(F>=max(reads),np.maximum(total,0),0)


def block(m):
    return m['contig'] if m['contig'].startswith('SIRV') else m['gene']


def background(data):
    n=3001;global_hist=np.zeros(n);by=defaultdict(lambda:np.zeros(n));gb={m['gene']:block(m) for m in data['models']}
    for gene,h in data['calibration'].items():
        for f,c in h.items():
            if 0<int(f)<n:by[gb[gene]][int(f)]+=c;global_hist[int(f)]+=c
    out={};audit=[];x=np.arange(n)
    for b in {block(m) for m in data['models']}:
        h=global_hist-by[b];N=h.sum();fallback=False
        if N<=0: # uninformative distribution, no same-gene fallback leakage
            h=np.zeros(n);h[1:]=1;N=0;fallback=True
        p=h/h.sum();sd=np.sqrt(np.dot(p,(x-np.dot(p,x))**2));bw=max(5.,1.06*sd*max(N,1)**(-.2))
        q=gaussian_filter1d(p,bw,mode='constant');q[0]=0;q/=q.sum();q[1:]=(1-1e-6)*q[1:]+1e-6/3000
        out[b]=q;audit.append(dict(block=b,calibration_count=float(N),bandwidth=float(bw),uniform_fallback=fallback,mean=float(q@x)))
    return out,audit


def prepare(data,quadrature=256):
    models=data['models'];n=len(models);qs,audit=background(data);patterns=sorted({tuple(x['kind']) for x in data['observations']});pi={p:i for i,p in enumerate(patterns)}
    ns=[];rr=[];cc=[];vv=[];groups=[]
    for i,o in enumerate(data['observations']):
        ns.append(o['count']);groups.append(pi[tuple(o['kind'])])
        for j,F in zip(o['members'],o['fragments']):
            q=qs[block(models[j])];w=(q[F] if 0<F<len(q) else 0.) if o['kind'][0]==2 else 1.
            rr.append(i);cc.append(j);vv.append(w)
    A=csr_matrix((vv,(rr,cc)),shape=(len(ns),n));E=np.zeros((len(patterns),n))
    for j,m in enumerate(models):
        q=qs[block(m)];fs=np.searchsorted(np.cumsum(q),(np.arange(quadrature)+.5)/quadrature);fs,cnt=np.unique(fs,return_counts=True);weights=cnt/quadrature
        js=[];removed=0
        for a,b in m['chain']:js.append(a-m['start']-removed);removed+=b-a
        for k,p in enumerate(patterns):
            E[k,j]=float(valid_starts(m['length'],js,fs,p[1:])@weights) if p[0]==2 else float(valid_starts(m['length'],js,np.array([p[1]]),p[1:])[0])
    # Integration can miss extreme tails; retain positive exposure whenever observed.
    clamps=0
    for i,g in enumerate(groups):
        ids=A.indices[A.indptr[i]:A.indptr[i+1]]
        for j in ids:
            if E[g,j]<=0:E[g,j]=1e-9;clamps+=1
    lr=data['LR'];lrrows=[];lrcols=[];nl=[]
    for i,o in enumerate(lr):lrrows.extend([i]*len(o['members']));lrcols.extend(o['members']);nl.append(o['count'])
    L=csr_matrix((np.ones(len(lrrows)),(lrrows,lrcols)),shape=(len(lr),n))
    return dict(A=A,E=E,ns=np.array(ns,float),groups=np.array(groups),L=L,nl=np.array(nl,float),models=models,calibration=audit,exposure_clamps=clamps)


def objective(z,A,E,counts,groups,L,nl,variance=None):
    b=np.exp(z);N=np.bincount(groups,weights=counts,minlength=len(E));Z=np.maximum(E@b,1e-300);den=np.maximum(A@b,1e-300)
    value=float(N@np.log(Z)-counts@np.log(den));grad=b*(E.T@(N/Z)-A.T@(counts/den))
    if nl.sum()>0:
        den=np.maximum(L@b,1e-300);value+=nl.sum()*np.log(b.sum())-nl@np.log(den);grad+=b*(nl.sum()/b.sum()-L.T@(nl/den))
    if variance is not None:
        cen=z-z.mean();value+=cen@cen/(2*variance);grad+=cen/variance
    return value,grad


def fit(p,counts=None,shrink=True,init=None,variance=None,tolerance=1e-14):
    nl=p['nl'] if counts is None else np.asarray(counts);active=np.asarray(p['A'].sum(0)+p['L'].sum(0)).ravel()>0
    out=np.zeros(len(active));args=[p['A'][:,active],p['E'][:,active],p['ns'],p['groups'],p['L'][:,active],nl]
    if not active.any():return out,dict(success=True,variance=1.,status='empty')
    def solve(z,v,c):
        a=args.copy();a[-1]=c
        return minimize(lambda zz:objective(zz,*a,v),z,jac=True,method='L-BFGS-B',bounds=[(-25,25)]*sum(active),options=dict(maxiter=4000,ftol=tolerance,gtol=1e-5,maxls=40))
    if init is None:
        pre=solve(np.zeros(sum(active)),None,np.zeros_like(nl));z=pre.x
    else:z=np.log(np.maximum(init[active],1e-12));z-=z.mean()
    if variance is None:variance=float(np.clip((1.4826*np.median(np.abs(z-np.median(z))))**2,1,25))
    res=solve(z,variance if shrink else None,nl);b=np.exp(res.x);out[active]=b/b.sum()*1e6
    return out,dict(success=bool(res.success),iterations=int(res.nit),variance=variance,message=str(res.message),gradient_max=float(np.max(np.abs(res.jac))))

