"""Experimental replicate sharing for molecular usage; no differential test.

Conditions label nuisance sharing only. Truth and event labels are never used.
Condition on uniquely assigned gene and read-length pattern, retaining the
native observation probabilities and opportunity denominators. Do not use
this prototype to infer biological significance or transcript-level TPM.
"""
from collections import defaultdict
import numpy as np
from scipy.optimize import minimize


def gene_blocks(prepared):
    models=prepared['models']; by=defaultdict(list)
    for i,m in enumerate(models): by[m['gene']].append(i)
    A=prepared['A']; out={}; cross=0
    owner=np.array([m['gene'] for m in models])
    row_gene=[]
    for i in range(A.shape[0]):
        ids=A.indices[A.indptr[i]:A.indptr[i+1]]
        gs=set(owner[ids]); row_gene.append(next(iter(gs)) if len(gs)==1 else None)
        if len(gs)>1: cross+=float(prepared['ns'][i])
    row_gene=np.array(row_gene,object)
    for gene,ids in by.items():
        mask=row_gene==gene
        if not mask.any(): continue
        a=A[mask][:,ids].toarray(); group=prepared['groups'][mask]; n=prepared['ns'][mask]
        # Row-specific common factors do not depend on composition. Remove
        # them and compress duplicate probability patterns deterministically.
        a=a/a.sum(axis=1,keepdims=True)
        keys=np.column_stack([group,np.round(a,12)])
        uniq,inv=np.unique(keys,axis=0,return_inverse=True)
        out[gene]=dict(A=uniq[:,1:],groups=uniq[:,0].astype(int),n=np.bincount(inv,weights=n),E=prepared['E'][:,ids],transcripts=[models[j]['transcript'] for j in ids])
    return out,dict(cross_gene_fragments_excluded=cross)


def dispersion(gene, abundance, blocks, conditions, min_count=20):
    """Leave-target-gene-out robust replicate spread, never truth-calibrated."""
    values=[]; donors=[]
    genes=set.intersection(*(set(b) for b in blocks))
    for g in sorted(genes-{gene}):
        tids=blocks[0][g]['transcripts']
        if len(tids)<2 or any(b[g]['n'].sum()<min_count for b in blocks): continue
        if any(b[g]['transcripts']!=tids for b in blocks): raise ValueError('Transcript ordering mismatch')
        z=np.array([[np.log(max(v.get(t,0.),1e-6)) for t in tids] for v in abundance]); z-=z.mean(axis=1,keepdims=True)
        for c in sorted(set(conditions)):
            ix=np.flatnonzero(np.array(conditions)==c)
            for i in range(len(ix)):
                for j in range(i): values.extend((z[ix[i]]-z[ix[j]]).tolist())
        donors.append(g)
    if len(values)<20: return 1.,dict(donor_genes=donors,pairwise_entries=len(values),fallback=True)
    x=np.array(values);sd=1.4826*np.median(np.abs(x-np.median(x)))/np.sqrt(2)
    return float(np.clip(sd**2,.04,4.)),dict(donor_genes=donors,pairwise_entries=len(values),fallback=False,unclipped_variance=float(sd**2))


def objective(z, blocks, conditions, variance=None, prior_variance=25.):
    Z=z.reshape(len(blocks),-1); G=np.zeros_like(Z); value=0.
    for i,(zz,b) in enumerate(zip(Z,blocks)):
        beta=np.exp(zz); E=b['E']; A=b['A']; n=b['n']; N=np.bincount(b['groups'],weights=n,minlength=len(E))
        exposure=np.maximum(E@beta,1e-300); likelihood=np.maximum(A@beta,1e-300)
        value+=float(N@np.log(exposure)-n@np.log(likelihood))
        G[i]=beta*(E.T@(N/exposure)-A.T@(n/likelihood))
    centered=Z-Z.mean(axis=1,keepdims=True)
    value+=float((centered**2).sum()/(2*prior_variance));G+=centered/prior_variance
    if variance is not None:
        for c in sorted(set(conditions)):
            ids=np.flatnonzero(np.array(conditions)==c)
            residual=centered[ids]-centered[ids].mean(axis=0,keepdims=True)
            value+=float((residual**2).sum()/(2*variance)); G[ids]+=residual/variance
    return value,G.ravel()


def fit_gene(blocks,conditions,init=None,variance=None):
    if len(blocks)!=len(conditions): raise ValueError('Each sample needs a condition')
    tids=blocks[0]['transcripts']
    if any(b['transcripts']!=tids for b in blocks): raise ValueError('Gene catalog mismatch')
    if any(b['n'].sum()<=0 for b in blocks): raise ValueError('No observed fragments in a sample')
    shape=(len(blocks),len(tids))
    z=np.zeros(shape) if init is None else np.log(np.maximum(np.asarray(init),1e-12));z-=z.mean(axis=1,keepdims=True)
    if z.shape!=shape: raise ValueError('Initializer shape mismatch')
    res=minimize(lambda x:objective(x,blocks,conditions,variance),z.ravel(),jac=True,method='L-BFGS-B',bounds=[(-25,25)]*z.size,options=dict(maxiter=3000,ftol=1e-13,gtol=1e-6,maxls=40))
    logits=res.x.reshape(shape);v=np.exp(logits-logits.max(axis=1,keepdims=True));v/=v.sum(axis=1,keepdims=True)
    return v,dict(success=bool(res.success),iterations=int(res.nit),gradient_max=float(np.max(np.abs(res.jac))),message=str(res.message),variance=variance,objective=float(res.fun))
