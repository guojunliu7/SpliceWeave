"""User-facing fixed-catalogue quantification; frozen 2026-11-24 policy."""
from collections import Counter, defaultdict
from pathlib import Path
import csv
import gzip
import hashlib
import json
import re
import tempfile
import time

import numpy as np
from .native import prepare, fit


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''):
            h.update(b)
    return h.hexdigest()


def read_catalog(path):
    tx = {}
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt') as f:
        for line in f:
            if line.startswith('#'):
                continue
            row = line.rstrip().split('\t')
            if len(row) != 9 or row[2] != 'exon':
                continue
            attrs = dict(re.findall(r'(\w+) "([^"]+)"', row[8]))
            if not all(k in attrs for k in ('transcript_id', 'gene_id')):
                raise ValueError('GTF exons require transcript_id and gene_id')
            key = (attrs['gene_id'], row[0], row[6])
            old, exons = tx.setdefault(attrs['transcript_id'], (key, []))
            if old != key or row[6] not in ('+', '-', '.'):
                raise ValueError('Inconsistent transcript gene, contig or strand')
            exons.append((int(row[3])-1, int(row[4])))
    models = []
    for tid, ((gene, contig, strand), exons) in sorted(tx.items()):
        exons = sorted(set(exons))
        chain = [(a[1], b[0]) for a, b in zip(exons, exons[1:])]
        if any(a < 0 or b <= a for a, b in exons + chain):
            raise ValueError('Overlapping, adjacent, or invalid exons in '+tid)
        models.append(dict(transcript=tid, gene=gene, contig=contig, strand=strand,
                           start=exons[0][0], end=exons[-1][1], chain=chain,
                           length=sum(b-a for a, b in exons)))
    if not models:
        raise ValueError('GTF contains no exon models')
    return models


def extract(gtf, short_bam, long_bam):
    import pysam
    from ..assembly import mixed_assembly as mx
    models = read_catalog(gtf)
    spans = [mx.PathSpan(m['start'], m['end'], m['strand'], tuple(map(tuple,m['chain']))) for m in models]
    bych = defaultdict(list)
    for j,m in enumerate(models):
        bych[m['contig']].append(j)
    obs, lrclasses, audit = Counter(), Counter(), Counter()
    hist = defaultdict(Counter)
    with pysam.AlignmentFile(long_bam, 'rb') as lr, pysam.AlignmentFile(short_bam, 'rb') as sr:
        for ch, long, short in mx.loci(lr, sr, 8, 20):
            if ch not in bych:
                continue
            ids_ch = bych[ch]
            gs = Counter(tuple(sorted(v, key=lambda r:(r.start,r.end,r.chain,r.strand))) for v in short.values())
            for mates, count in gs.items():
                audit['eligible_SR'] += count
                if len(mates) not in (1,2):
                    audit['unexpected_mate_count'] += count
                    continue
                ids, frags = [], []
                for j in ids_ch:
                    m = spans[j]
                    if not all(mx.compatible(r, m, 0) for r in mates):
                        continue
                    ps = [(r.start-m.start-sum(v-u for u,v in m.chain if v<=r.start),
                           r.end-m.start-sum(v-u for u,v in m.chain if v<=r.end)) for r in mates]
                    if any(b<=a for a,b in ps):
                        continue
                    ids.append(j)
                    frags.append(max(b for a,b in ps)-min(a for a,b in ps))
                if not ids:
                    audit['unassigned_SR'] += count
                    continue
                lens = tuple(r.end-r.start-sum(b-a for a,b in r.chain) for r in mates)
                kind = (len(mates), *lens)
                obs[(kind,tuple(ids),tuple(frags))] += count
                audit['assigned_SR'] += count
                genes = {models[j]['gene'] for j in ids}
                if len(mates)==2 and len(set(frags))==1 and max(lens)<=frags[0]<=3000 and len(genes)==1:
                    hist[next(iter(genes))][frags[0]] += count
                    audit['calibration_SR'] += count
            for read, count in Counter(long.values()).items():
                audit['eligible_LR'] += count
                members = tuple(j for j in ids_ch if mx.compatible(read, spans[j], 50))
                if members:
                    lrclasses[members] += count
                    audit['assigned_LR'] += count
                else:
                    audit['unassigned_LR'] += count
    return dict(models=models, observations=[dict(kind=k,members=ids,fragments=fs,count=n) for (k,ids,fs),n in obs.items()],
                calibration={g:dict(h) for g,h in hist.items()}, LR=[dict(members=ids,count=n) for ids,n in lrclasses.items()],audit=dict(audit))


def validate_geometry(data):
    if not data['observations']:
        raise ValueError('Joint quantification requires at least one compatible short-read observation')
    models = data['models']; n = len(models)
    tids = [m['transcript'] for m in models]
    if not n or len(set(tids)) != n:
        raise ValueError('Models must have distinct transcript identifiers')
    genes = {m['gene'] for m in models}
    for m in models:
        if m['length'] <= 0 or m['end'] <= m['start']:
            raise ValueError('Invalid transcript length or span')
    for platform, rows in [('SR',data['observations']),('LR',data['LR'])]:
        for row in rows:
            c = row['count']; ids = row['members']
            if not np.isfinite(c) or c<=0 or not ids or len(set(ids))!=len(ids) or any(not isinstance(i,int) or not 0<=i<n for i in ids):
                raise ValueError('Invalid '+platform+' observation counts or membership')
            if platform=='SR':
                k=row['kind']
                if k[0] not in (1,2) or len(k)!=k[0]+1 or min(k[1:])<=0 or len(row['fragments'])!=len(ids):
                    raise ValueError('Invalid SR fragment geometry')
                if any(not isinstance(f,int) or f<=0 for f in row['fragments']):
                    raise ValueError('SR fragment lengths must be positive integers')
    for gene, hist in data['calibration'].items():
        if gene not in genes or any(not np.isfinite(v) or v<0 for v in hist.values()):
            raise ValueError('Invalid calibration gene or count')


def quantify_prepared(p):
    """Exactly the fit sequence used in the latest six-library comparison."""
    mle, dm = fit(p, counts=np.zeros_like(p['nl']), shrink=False)
    sr, ds = fit(p, counts=np.zeros_like(p['nl']), init=mle)
    joint, dj = fit(p, init=sr, variance=ds['variance'])
    fits = dict(MLE=dm, SR=ds, joint=dj)
    if not all(d['success'] for d in fits.values()):
        raise ValueError('Quantification did not converge: '+json.dumps(fits))
    return joint, sr, fits


def run_quantify(args):
    from .. import __version__
    started = time.time()
    out = args.out_dir
    if out.exists() or out.is_symlink():
        raise FileExistsError('Choose a new output directory: '+str(out))
    if args.geometry:
        if any([args.gtf,args.short_bam,args.long_bam]):
            raise ValueError('--geometry cannot be combined with GTF/BAM inputs')
        opener = gzip.open if str(args.geometry).endswith('.gz') else open
        with opener(args.geometry,'rt') as f:
            data=json.load(f)
        inputs={'geometry':args.geometry}
    else:
        if not all([args.gtf,args.short_bam,args.long_bam]):
            raise ValueError('Supply --gtf, --short-bam and --long-bam, or --geometry')
        data=extract(args.gtf,args.short_bam,args.long_bam)
        inputs={k:getattr(args,k) for k in ('gtf','short_bam','long_bam')}
    validate_geometry(data)
    p=prepare(data);joint,sr,fits=quantify_prepared(p)
    support=np.asarray(p['A'].T@p['ns']+p['L'].T@p['nl']).ravel()>0
    summary=dict(version=__version__,model='geometry_MAP_joint',sample=args.sample,models=len(joint),
                 fits=fits,calibration=p['calibration'],exposure_clamps=p['exposure_clamps'],
                 unsupported_transcripts=int((~support).sum()),extraction=data.get('audit',{}),
                 input_sha256={k:digest(v) for k,v in inputs.items()},
                 settings=dict(mapq=20,anchor_nt=8,LR_terminal_slack_nt=50,SR_terminal_slack_nt=0,quadrature=256,
                               tolerance=1e-14,direction_gate=False),seconds=time.time()-started)
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=out.parent,prefix='.sw-quant-') as tmp:
        stage=Path(tmp)/'result';stage.mkdir()
        with (stage/'abundance.tsv').open('w',newline='') as f:
            w=csv.writer(f,delimiter='\t');w.writerow(['sample','transcript_id','gene_id','TPM','SR_TPM','has_input_support'])
            for i,m in enumerate(p['models']):w.writerow([args.sample,m['transcript'],m['gene'],float(joint[i]),float(sr[i]),int(support[i])])
        with gzip.open(stage/'geometry.json.gz','wt') as f:json.dump(data,f)
        (stage/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        if out.exists():raise FileExistsError(str(out))
        stage.rename(out)
    return summary
