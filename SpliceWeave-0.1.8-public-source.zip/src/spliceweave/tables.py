"""Read cohort designs and fixed-catalogue branch counts."""

import csv
import gzip
from collections import Counter
from dataclasses import dataclass, field

from .as_code import asta_paths
from .fragments import read_length_limit


def open_text(path):
    opener = gzip.open if path.suffix == ".gz" else open
    return opener(path, "rt", encoding="utf-8-sig", newline="")


def table_rows(path, required, allow_empty=()):
    with open_text(path) as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        fields = reader.fieldnames or []
        missing = set(required) - set(fields)
        if missing or len(set(fields)) != len(fields) or "" in fields:
            raise ValueError(f"{path}: missing {sorted(missing)} or invalid/duplicate TSV header")
        for row in reader:
            if None in row or None in row.values():
                raise ValueError(f"{path}:{reader.line_num}: wrong number of columns")
            if any(not row[k].strip() for k in required if k not in allow_empty):
                raise ValueError(f"{path}:{reader.line_num}: empty required field")
            yield row


MISSING = {"", ".", "na", "n/a", "nan", "unknown"}


def canonical_unit(unit):
    return {
        "RI": "IR",
        "IR": "IR",
        "SE": "ES",
        "ES": "ES",
        "MX": "MXE",
        "MXE": "MXE",
        "A3": "A3SS",
        "A3SS": "A3SS",
        "A5": "A5SS",
        "A5SS": "A5SS",
        "COMPLEX": "Complex",
    }.get(unit.upper(), unit)


def read_design(path, reference, comparison, bam_mode, pair_column=None):
    required = ["sample_id", "condition"]
    if bam_mode:
        required += ["sr_bam", "sr_strandedness"]
    rows = {}
    for row in table_rows(path, required, allow_empty=("sr_bam", "sr_strandedness")):
        sid = row["sample_id"]
        if sid in rows:
            raise ValueError(f"{path}: duplicate sample_id {sid!r}")
        rows[sid] = row
    sizes = Counter(r["condition"] for r in rows.values())
    if reference == comparison or min(sizes[reference], sizes[comparison]) < 2:
        raise ValueError("Choose two distinct conditions with at least two biological samples each")
    selected = [
        sid
        for label in (reference, comparison)
        for sid in sorted(rows)
        if rows[sid]["condition"] == label
    ]
    if pair_column:
        if pair_column in {"sample_id", "condition"}:
            raise ValueError("Select a separate subject/pair ID column")
        pairs = {}
        for sid in selected:
            pair = rows[sid].get(pair_column, "").strip()
            if pair.lower() in MISSING:
                raise ValueError(f"{sid}: missing pair ID in {pair_column}")
            group = rows[sid]["condition"]
            members = pairs.setdefault(pair, {})
            if group in members:
                raise ValueError(f"{pair}: multiple samples in condition {group}")
            members[group] = sid
        if any(len(members) != 2 for members in pairs.values()):
            raise ValueError("Each pair must have one sample in each selected condition")
        selected = [
            pairs[pair][group] for group in (reference, comparison) for pair in sorted(pairs)
        ]
    if bam_mode:
        for sid in selected:
            if not rows[sid]["sr_bam"].strip():
                raise ValueError(f"{sid}: missing sr_bam")
            if rows[sid]["sr_strandedness"] not in {
                "forward_stranded",
                "reverse_stranded",
                "unstranded",
            }:
                raise ValueError(f"{sid}: unknown sr_strandedness")
    return rows, selected, sizes[reference]


ANNOTATIONS = (
    "gene_names",
    "ensembl_gene_ids",
    "chrom",
    "strand",
    "start",
    "end",
    "AS_code",
    "flanks",
    "splice_chain",
    "branch_A_introns_1based",
    "branch_B_introns_1based",
)


@dataclass
class Event:
    unit: str
    annotations: dict = field(default_factory=dict)
    counts: dict = field(default_factory=dict)
    ir_geometry: dict = field(default_factory=dict)


def read_counts(path, design, selected, catalog=None, *, allow_empty=False):
    events = {}
    if catalog:
        for row in table_rows(catalog, ("event_id", "Unit")):
            eid = row["event_id"]
            if eid in events:
                raise ValueError(f"{catalog}: duplicate event_id {eid}")
            events[eid] = Event(
                canonical_unit(row["Unit"]), {k: row[k] for k in ANNOTATIONS if k in row}
            )
        if not events:
            raise ValueError(f"{catalog}: empty catalogue")
    chosen = set(selected)
    seen_samples = set()
    required = ("event_id", "sample_id", "Unit", "A_only_fragments", "B_only_fragments")
    for row in table_rows(path, required, allow_empty=required[-2:]):
        sid, eid, unit = row["sample_id"], row["event_id"], canonical_unit(row["Unit"])
        if sid not in design:
            raise ValueError(f"{path}: undeclared sample_id {sid}")
        if "condition" in row and row["condition"] != design[sid]["condition"]:
            raise ValueError(f"{eid}/{sid}: condition disagrees with samples file")
        if sid not in chosen:
            continue
        seen_samples.add(sid)
        if catalog and eid not in events:
            raise ValueError(f"{eid}: missing from supplied event catalogue")
        event = events.setdefault(eid, Event(unit))
        if event.unit != unit or sid in event.counts:
            raise ValueError(f"{eid}/{sid}: inconsistent Unit or duplicate event/sample")
        for k in ANNOTATIONS:
            if k in row and (row[k] or k.startswith("branch_")):
                old = event.annotations.get(k)
                if old not in (None, row[k]) and (old or k.startswith("branch_")):
                    raise ValueError(f"{eid}: inconsistent {k} across catalogue/count rows")
                event.annotations[k] = row[k]
        if unit == "IR":
            declared = read_length_limit(design[sid].get("max_mate_length"))
            counted = read_length_limit(row.get("max_mate_length"))
            if declared and counted and declared != counted:
                raise ValueError(f"{eid}/{sid}: conflicting maximum mate lengths")
            sample_rule = design[sid].get("ir_count_rule", "")
            if sample_rule and row.get("ir_count_rule") and row["ir_count_rule"] != sample_rule:
                raise ValueError(f"{eid}/{sid}: conflicting IR counting rules")
            rule = row.get("ir_count_rule") or sample_rule
            event.ir_geometry[sid] = (counted or declared, rule)
        try:
            if all(row[k].strip().lower() in MISSING for k in required[-2:]):
                if any(
                    row[k].strip().lower() not in MISSING
                    for k in ("informative_AB_fragments", "SR_informative_AB_fragments")
                    if k in row
                ):
                    raise ValueError
                event.counts[sid] = None
                continue
            a, b = int(row["A_only_fragments"]), int(row["B_only_fragments"])
            if min(a, b) < 0:
                raise ValueError
            for key in ("informative_AB_fragments", "SR_informative_AB_fragments"):
                if key in row and int(row[key]) != a + b:
                    raise ValueError
        except ValueError:
            raise ValueError(
                f"{eid}/{sid}: expected non-negative integer counts and informative = A+B"
            ) from None
        event.counts[sid] = (a, b)
    if chosen != seen_samples and not (allow_empty and not events):
        raise ValueError(f"Selected samples absent from counts: {sorted(chosen - seen_samples)}")
    for eid, event in events.items():
        annot = event.annotations
        coordinates = ("AS_code", "splice_chain", "flanks", "strand")
        if event.unit == "IR" and all(annot.get(k) for k in coordinates):
            unit, a, b = asta_paths(*(annot[k] for k in coordinates))
            if unit != "IR":
                raise ValueError(f"{eid}: IR label disagrees with AStalavista paths")
            for key, path in (("branch_A_introns_1based", a), ("branch_B_introns_1based", b)):
                if annot.setdefault(key, path) != path:
                    raise ValueError(f"{eid}: supplied branch differs from AStalavista coordinates")
    return events
