"""Release boundary checks: conservation, collisions and atomic output."""
from pathlib import Path
import sys,tempfile,unittest,gzip,csv,json
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import pysam
from spliceweave.assembly.runner import run_assembly
from spliceweave.cli import main
class AssemblyCLITests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.p=Path(self.tmp.name);ref=list('A'*200)
  for a,b in [(20,40),(60,80)]:ref[a:a+2]=list('GT');ref[b-2:b]=list('AG')
  (self.p/'ref.fa').write_text('>chr1\n'+''.join(ref)+'\n');pysam.faidx(str(self.p/'ref.fa'))
  self.header={'HD':{'VN':'1.6','SO':'coordinate'},'SQ':[{'SN':'chr1','LN':200}]};self.write_bam(['r1','r2'])
  with pysam.AlignmentFile(self.p/'short.bam','wb',header=self.header):pass
  (self.p/'ann.gtf').write_text(''.join(f'chr1\ttest\texon\t{a}\t{b}\t.\t+\t.\tgene_id "g"; transcript_id "t";\n' for a,b in [(1,20),(41,60),(81,100)]))
  (self.p/'corrected.bed').write_text(''.join(f'chr1\t0\t100\t{n}\t60\t+\t0\t100\t0\t3\t20,20,20,\t0,40,80,\n' for n in ['r1','r2']))
  self.args=SimpleNamespace(long_bam=self.p/'long.bam',short_bam=self.p/'short.bam',reference=self.p/'ref.fa',gtf=self.p/'ann.gtf',corrected_bed=self.p/'corrected.bed',mode='joint',out_dir=self.p/'out')
 def tearDown(self):self.tmp.cleanup()
 def write_bam(self,names):
  with pysam.AlignmentFile(self.p/'long.bam','wb',header=self.header) as f:
   for n in names:
    r=pysam.AlignedSegment();r.query_name=n;r.query_sequence='A'*60;r.flag=0;r.reference_id=0;r.reference_start=0;r.mapping_quality=60;r.cigartuples=[(0,20),(3,20),(0,20),(3,20),(0,20)];r.set_tag('XS','+');f.write(r)
 def test_default_cli_and_read_conservation(self):
  args=[]
  for k in ['long_bam','short_bam','reference','gtf','corrected_bed','out_dir']:args+=['--'+k.replace('_','-'),str(getattr(self.args,k))]
  main(['assemble-chains']+args);info=json.loads((self.args.out_dir/'summary.json').read_text());self.assertEqual(info['mode'],'joint');self.assertEqual(info['counts']['input_molecules'],2);self.assertEqual(info['counts']['output_molecules'],2)
  self.assertEqual(len((self.args.out_dir/'models.gtf').read_text().splitlines()),3)
  with gzip.open(self.args.out_dir/'read_evidence.tsv.gz','rt') as f:self.assertEqual(len(list(csv.DictReader(f,delimiter='\t'))),2)
  with self.assertRaises(FileExistsError):run_assembly(self.args)
 def test_duplicate_read_ids_fail(self):
  self.write_bam(['r1','r1'])
  with self.assertRaisesRegex(ValueError,'unique per contig'):run_assembly(self.args)
  self.assertFalse(self.args.out_dir.exists())
 def test_overlay_geometry_conflict_is_atomic(self):
  p=self.p/'corrected.bed';p.write_text(p.read_text().replace('\t+\t','\t-\t'))
  with self.assertRaisesRegex(ValueError,'preserve read ends'):run_assembly(self.args)
  self.assertFalse(self.args.out_dir.exists())
 def test_missing_overlay_retains_raw_and_is_counted(self):
  (self.p/'corrected.bed').write_text('');info=run_assembly(self.args);self.assertEqual(info['counts']['retained_without_overlay'],2)
 def test_baseline_control(self):
  self.args.mode='baseline';info=run_assembly(self.args);self.assertEqual(info['mode'],'baseline');self.assertEqual(info['counts']['status:accepted'],1)
if __name__=='__main__':unittest.main()
