from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from spliceweave.assembly.sequence_arbitration import *
from spliceweave.assembly.structure_evidence import annotation
assert distance('ACGT','ACGT')==0
assert distance('ACGT','AGT')==1
assert distance('ACGT','ACGA')==1
assert distance('','AAA')==3
assert compare_window('ACGT','AC','GT','AT','GT')==(0,1)
assert compare_window('ACGT','AC','GT','A','CGT')==(0,0)
assert compare_window('ACNT','AC','NT','A','CNT') is None
r=PathSpan(0,100,'-',((10,20),(30,40)));a={('x','+',r.chain):[(PathSpan(0,100,'+',r.chain),'tx')]}
assert direction(r,'x',{}, {}, lambda j:'+')[0]=='+'
assert direction(r,'x',{}, {}, lambda j:'+' if j[0]==10 else '-')[0] is None
assert direction(r,'x',a,{(10,20):{'-'}},lambda j:'+' if j[0]==10 else None)[0] is None
assert direction(r,'x',a,{(10,20):{'+'}},lambda j:None)[0]=='+'
assert direction(r,'x',{}, {},lambda j:None)[0] is None
assert direction(r,'x',a,{},lambda j:None,True)[0]=='+'
reads={('', 'r1'):r,('', 'r2'):r};res,ga,sa=arbitrate(reads,reads,reads,{},'x',a,{}, {},lambda j:'+', 'joint')
assert set(res)==set(reads) and all(x.chain==r.chain for x in res.values())
assert all(x.strand=='+' for x in res.values())
# Sequence ties must not force original geometry even when the original is accepted.
x=PathSpan(0,100,'+',((10,20),(30,40)));y=PathSpan(0,100,'+',((11,21),(30,40)))
raw={('', 'r1'):x,('', 'r2'):x};cor={k:y for k in raw};w={('x',k[1]):set(x.chain) for k in raw};feat={('x',k[0],k[1]):{(10,20):(0,0)} for k in raw}
res,ga,sa=arbitrate(raw,cor,cor,{},'x',{},w,feat,lambda j:'+', 'sequence_only');assert all(z.chain==y.chain for z in res.values())
feat={k:{(10,20):(0,1)} for k in feat};res,ga,sa=arbitrate(raw,cor,cor,{},'x',{},w,feat,lambda j:'+', 'sequence_only');assert all(z.chain==y.chain for z in res.values())
raw={('',str(i)):x for i in range(15)};cor={k:y for k in raw};w={('x',k[1]):set(x.chain) for k in raw};feat={('x',k[0],k[1]):{(10,20):(0,1)} for k in raw}
res,ga,sa=arbitrate(raw,cor,cor,{},'x',{},w,feat,lambda j:'+', 'sequence_only');assert all(z.chain==x.chain for z in res.values())
for i in range(30):
 k=('', 'competitor'+str(i));raw[k]=y;cor[k]=y;w['x',k[1]]=set(y.chain)
res,ga,sa=arbitrate(raw,cor,cor,{},'x',{},w,feat,lambda j:'+', 'sequence_only');assert all(z.chain==y.chain for z in res.values())
print('19 arbitration assertions passed')
