import csv
import json
from pathlib import Path
import pytest
from spliceweave.cli import main


def fixture_files(tmp_path, second_gene=True):
    samples=tmp_path/'samples.tsv';counts=tmp_path/'counts.tsv'
    samples.write_text('sample_id\tcondition\n'+''.join(f'{g}{i}\t{g}\n' for g in 'AB' for i in range(3)))
    rows=['event_id\tsample_id\tUnit\tgene_names\tA_only_fragments\tB_only_fragments']
    for e,g in [('e1','g1'),('e2','g2' if second_gene else 'g1')]:
        for group in 'AB':
            for i in range(3):
                b=(10+i if group=='A' else 80+i) if e=='e1' else 30+i
                rows.append(f'{e}\t{group}{i}\tES\t{g}\t{100-b}\t{b}')
    counts.write_text('\n'.join(rows)+'\n')
    return ['diff-splicing-counts','--samples',str(samples),'--counts',str(counts),'--reference','A','--comparison','B','--bootstrap-draws','199']


def test_cli_keeps_count_estimand_and_rejects_overwrite(tmp_path):
    args=fixture_files(tmp_path);out=tmp_path/'out'
    main(args+['--out-dir',str(out)])
    meta=json.loads((out/'summary.json').read_text())
    assert meta['tested']==2 and meta['molecular_PSI_significance'] is False
    rows=list(csv.DictReader((out/'count_differential_events.tsv').open(),delimiter='\t'))
    assert all(int(r['prior_genes'])==1 for r in rows)
    assert all(0<float(r['p_value'])<=1 for r in rows)
    assert rows[0]['estimand'].endswith('observed B/(A+B)')
    with pytest.raises(SystemExit):main(args+['--out-dir',str(out)])


def test_one_gene_has_no_self_trained_prior(tmp_path):
    args=fixture_files(tmp_path,False);out=tmp_path/'out';main(args+['--out-dir',str(out)])
    rows=list(csv.DictReader((out/'count_differential_events.tsv').open(),delimiter='\t'))
    assert all(r['status']=='insufficient_other_genes' and r['p_value']=='NA' for r in rows)
    assert json.loads((out/'summary.json').read_text())['tested']==0


def test_optional_molecular_rescue_uses_design_direction(tmp_path):
    args = fixture_files(tmp_path)
    counts = tmp_path / 'counts.tsv'
    data = counts.read_text().splitlines()
    for i, line in enumerate(data):
        if line.startswith('e1\tA'):
            data[i] = line.rsplit('\t', 2)[0] + '\t2\t0'
    counts.write_text('\n'.join(data) + '\n')
    usage = tmp_path / 'event_usage.tsv'
    usage.write_text('sample\tevent_id\tUnit\tstatus\tAB_abundance\tmolecular_B_fraction\n'
                     + ''.join(f'{g}{i}\t{e}\tES\testimated\t100\t{v}\n'
                               for e in ['e1', 'e2'] for g in 'AB' for i in range(3)
                               for v in [.7 if e == 'e1' and g == 'B' else .2]))
    default = tmp_path / 'default'
    main(args + ['--out-dir', str(default)])
    assert not (default / 'coverage_rescue.tsv').exists()
    assert json.loads((default / 'summary.json').read_text())['min_informative'] == 20
    for reference, comparison, sign in [('A','B',1), ('B','A',-1)]:
        run_args = args.copy()
        run_args[run_args.index('--reference')+1] = reference
        run_args[run_args.index('--comparison')+1] = comparison
        out = tmp_path / reference
        main(run_args + ['--coverage-rescue', str(usage), '--out-dir', str(out)])
        with (out / 'coverage_rescue.tsv').open() as stream:
            rows = {r['event_id']: r for r in csv.DictReader(stream, delimiter='\t')}
        assert rows['e1']['source'] == 'molecular'
        assert float(rows['e1']['delta']) == pytest.approx(sign * .5)
        assert rows['e2']['source'] == 'count'
