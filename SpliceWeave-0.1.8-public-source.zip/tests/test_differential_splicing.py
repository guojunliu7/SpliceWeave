"""Regression tests for count, paired-design and BAM entry points."""

import contextlib
import csv
import gzip
import io
import itertools
import json
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if (ROOT / "src/spliceweave").is_dir():
    sys.path.insert(0, str(ROOT / "src"))
from spliceweave.cli import main
from spliceweave.differential import adjust_bh, permutations
from spliceweave.fragments import classify_fragment
from spliceweave.event_bam import asta_paths

try:
    import pysam
except ImportError:
    pysam = None


def tsv(path, fields, rows):
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "wt", encoding="utf8", newline="") as out:
        w = csv.writer(out, delimiter="\t", lineterminator="\n")
        w.writerow(fields)
        w.writerows(rows)


def read(path):
    with path.open() as f:
        return list(csv.DictReader(f, delimiter="\t"))


class TestDiffSplicing(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.base = Path(temp.name)
        self.samples = self.base / "my cohort.tsv"
        self.counts = self.base / "counts.tsv.gz"
        self.design = [(s, "saline" if s in "ceg" else "drug") for s in "fcagdeb"]
        self.fields = ("event_id", "sample_id", "Unit", "A_only_fragments", "B_only_fragments")
        tsv(self.samples, ("sample_id", "condition"), self.design)

    def invoke(self, name, *flags):
        output = self.base / name
        with contextlib.redirect_stdout(io.StringIO()):
            main(
                [
                    "diff-splicing",
                    "--samples",
                    str(self.samples),
                    "--reference",
                    "saline",
                    "--comparison",
                    "drug",
                    "--out-dir",
                    str(output),
                    *map(str, flags),
                ]
            )
        return output

    def test_arbitrary_names_unequal_sizes_missing_zero_and_positive(self):
        rows = []
        for sid, group in self.design:
            a, b = (1, 19) if group == "drug" else (19, 1)
            rows.extend([("signal", sid, "SE", a, b), ("flat", sid, "RI", 3, 17)])
            if sid != "a":
                rows.append(("missing", sid, "ES", 5, 15))
            rows.append(("low", sid, "IR", 0 if sid == "g" else 10, 0 if sid == "g" else 10))
            rows.append(("na", sid, "ES", "NA" if sid == "g" else 10, "NA" if sid == "g" else 10))
        tsv(self.counts, self.fields, rows)
        out = self.invoke("out", "--counts", self.counts)
        events = {r["event_id"]: r for r in read(out / "differential_events.tsv")}
        self.assertAlmostEqual(float(events["signal"]["delta_B_fraction"]), 0.9)
        self.assertEqual(float(events["signal"]["p_value"]), 1 / 35)
        self.assertEqual(events["signal"]["significant"], "True")
        self.assertEqual(events["flat"]["test_family"], "IR")
        self.assertEqual(float(events["flat"]["BH_q"]), 1)
        self.assertEqual(events["missing"]["status"], "missing_sample")
        self.assertEqual(events["low"]["status"], "low_coverage")
        self.assertEqual(events["na"]["p_value"], "NA")
        self.assertEqual(len(read(out / "sample_usage.tsv")), 35)
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            self.invoke("out", "--counts", self.counts)

    def test_retention_geometry_limits_zero_and_missing_metadata(self):
        columns = self.fields + ("branch_A_introns_1based", "branch_B_introns_1based",
                                 "ir_count_rule", "max_mate_length")
        rows = []
        for sid, _ in self.design:
            for label, a, b, path_a, path_b, size in (
                ("retained_A", 0, 28, "", "101-236", 151),
                ("retained_B", 28, 0, "101-236", "", 151 if sid == "a" else 152),
                ("exact_fit", 28, 0, "101-235", "", 151),
                ("unknown", 28, 0, "101-235", "", ""),
            ):
                rows.append((label, sid, "RI", a, b, path_a, path_b, "single_mate_full_span", size))
        tsv(self.counts, columns, rows)
        out = self.invoke("geometry", "--counts", self.counts)
        events = {r["event_id"]: r for r in read(out / "differential_events.tsv")}
        for key in ("retained_A", "retained_B", "unknown"):
            self.assertEqual(events[key]["p_value"], "NA")
            self.assertEqual(events[key]["BH_q"], "NA")
        self.assertEqual(events["unknown"]["status"], "unknown_IR_observability")
        self.assertEqual(events["exact_fit"]["p_value"], "1.0")
        usage = {(r["event_id"],r["sample_id"]):r for r in read(out / "sample_usage.tsv")}
        self.assertEqual(usage["retained_A","a"]["ir_observability"], "unobservable_A")
        self.assertEqual(usage["retained_B","a"]["observed_B_fraction"], "NA")
        self.assertEqual(usage["retained_B","b"]["observed_B_fraction"], "0.0")
        rows[0] = (*rows[0][:3], 1, *rows[0][4:])
        tsv(self.counts, columns, rows)
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            self.invoke("contradiction", "--counts", self.counts)

    def test_bh_step_up_with_separate_families_and_untested(self):
        rows = [
            dict(test_family=f, p_value=p, BH_q=None)
            for f, p in [
                ("nonIR", 0.01),
                ("nonIR", 0.03),
                ("nonIR", 0.02),
                ("IR", 0.01),
                ("IR", None),
            ]
        ]
        adjust_bh(rows)
        self.assertEqual([r["BH_q"] for r in rows], [0.03, 0.03, 0.03, 0.01, None])

    def test_pair_mapping_stays_intact_after_sample_shuffle(self):
        design = [
            ("x7", "drug", "p3"),
            ("b9", "saline", "p1"),
            ("y6", "drug", "p2"),
            ("d2", "saline", "p3"),
            ("z1", "drug", "p1"),
            ("b4", "saline", "p2"),
        ]
        ref = {"p1": 1, "p2": 10, "p3": 17}
        alt = {"p1": 9, "p2": 8, "p3": 20}
        rows = []
        for sid, cond, pair in design:
            n = (alt if cond == "drug" else ref)[pair]
            rows.append(("E", sid, "ES", 20 - n, n))
        tsv(self.counts, self.fields, rows)
        tsv(self.samples, ("sample_id", "condition", "donor"), design)
        out = self.invoke("paired", "--counts", self.counts, "--pair-column", "donor")
        delta = [alt[p] - ref[p] for p in ref]
        extreme = sum(
            abs(sum(s * d for s, d in zip(signs, delta))) >= abs(sum(delta))
            for signs in itertools.product((-1, 1), repeat=3)
        )
        r = read(out / "differential_events.tsv")[0]
        self.assertAlmostEqual(float(r["delta_B_fraction"]), sum(delta) / 60)
        self.assertEqual(float(r["p_value"]), extreme / 8)
        self.assertEqual(json.loads((out / "summary.json").read_text())["possible_assignments"], 8)
        tsv(self.samples, ("sample_id", "condition", "donor"), design[:-1])
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            self.invoke("broken", "--counts", self.counts, "--pair-column", "donor")
        self.assertFalse((self.base / "broken").exists())

    def test_permutation_seed_and_exact_against_scalar_enumeration(self):
        v = np.random.default_rng(9).random((9, 8))
        expected = []
        for col in v.T:
            obs = abs(col[:4].mean() - col[4:].mean())
            extreme = 0
            for a in itertools.combinations(range(9), 4):
                b = [k for k in range(9) if k not in a]
                extreme += abs(col[list(a)].mean() - col[b].mean()) >= obs - 1e-12
            expected.append(extreme / 126)
        exact, meta = permutations(v, 4, 126, 511, 72)
        np.testing.assert_allclose(expected, exact)
        self.assertEqual(meta["method"], "exact")
        approx, meta = permutations(v, 4, 10, 511, 72)
        np.testing.assert_array_equal(approx, permutations(v, 4, 10, 511, 72)[0])
        self.assertTrue(np.all((approx >= 1 / 512) & (approx <= 1)))
        self.assertEqual(meta["method"], "monte_carlo")

    def test_invalid_counts_and_duplicate_rows_fail_atomically(self):
        rows = [("e", s, "ES", 12, 9) for s, _ in self.design]
        for variant in [
            rows + rows[:1],
            rows + [("z", "undeclared", "ES", 3, 3)],
            rows[:-1] + [("e", self.design[-1][0], "ES", 0.3, 8)],
            rows[:-1] + [("e", self.design[-1][0], "MXE", 20, 20)],
        ]:
            tsv(self.counts, self.fields, variant)
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                self.invoke("bad", "--counts", self.counts)
            self.assertFalse((self.base / "bad").exists())

    def test_ir_and_minus_strand(self):
        self.assertEqual(
            asta_paths("0,1-2^", ",250-220^", "350^,100-", "-"),
            ("ES", "101-349", "101-219;251-349"),
        )
        paths = ((), ((101, 150),), {(), ((101, 150),)})
        self.assertEqual(
            classify_fragment(
                [(((95, 115),), ()), (((135, 160),), ())], 80, 180, *paths, unit="IR"
            ),
            "IR_insufficient_full_span",
        )
        self.assertEqual(classify_fragment([(((92, 161),), ())], 80, 180, *paths, unit="IR"), "A")

    @unittest.skipIf(pysam is None, "BAM extra required")
    def test_indexed_bams_and_asta_catalog_to_differential_calls(self):
        models = self.base / "models.gtf"
        with models.open("w") as f:
            for tid, exons in (
                ("skip", [(100, 139), (300, 349)]),
                ("include", [(100, 139), (200, 239), (300, 349)]),
            ):
                for a, b in exons:
                    print(
                        "chrSynth",
                        "toy",
                        "exon",
                        a,
                        b,
                        ".",
                        "+",
                        ".",
                        f'gene_id "g"; transcript_id "{tid}";',
                        sep="\t",
                        file=f,
                    )
        events = self.base / "events.gtf"
        events.write_text(
            "chrSynth\ttest\tas_event\t139\t300\t.\t+\t.\t"
            'event_id "E"; structure "0,1-2^"; flanks "139^,300-"; '
            'splice_chain ",200-239^"; transcript_id "skip,include";\n'
            "chrSynth\ttest\tas_event\t139\t300\t.\t+\t.\t"
            'event_id "multi"; structure "1-,2-,3-"; flanks "139^,300-"; '
            'splice_chain "200-,210-,230-";\n'
        )
        samples = []
        header = {
            "HD": {"SO": "coordinate"},
            "SQ": [{"SN": "chrSynth", "LN": 500}],
            "RG": [{"ID": g, "SM": "test"} for g in ("a", "b")],
        }
        for sid, group in [
            ("one", "saline"),
            ("two", "drug"),
            ("three", "saline"),
            ("four", "drug"),
        ]:
            bam = self.base / (sid + ".bam")
            samples.append((sid, group, bam.name, "forward_stranded"))
            with pysam.AlignmentFile(str(bam), "wb", header=header) as f:
                records = []
                for rg in ("a", "b"):
                    for i in range(2):
                        # One skip and one inclusion in both references, all inclusion in drug.
                        first, other = (200, 239) if group == "drug" or i else (300, 339)
                        start0 = 119
                        for mate, start, cigar, flag in [
                            (1, start0, f"20M{first-140}N20M", 99),
                            (2, other - 19, "12M", 147),
                        ]:
                            r = pysam.AlignedSegment(f.header)
                            r.query_name = f"template{i}"
                            r.flag = flag
                            r.reference_id = 0
                            r.reference_start = start
                            r.mapping_quality = 60
                            r.cigarstring = cigar
                            r.query_sequence = "A" * r.infer_query_length()
                            r.next_reference_id = 0
                            r.next_reference_start = other - 19 if mate == 1 else start0
                            r.set_tag("RG", rg)
                            records.append(r)
                for r in sorted(records, key=lambda a: a.reference_start):
                    f.write(r)
            pysam.index(str(bam))
        tsv(self.samples, ("sample_id", "condition", "sr_bam", "sr_strandedness"), samples)
        out = self.invoke("bam", "--gtf", models, "--events", events, "--min-informative", 1)
        for row in read(out / "branch_counts.tsv"):
            self.assertEqual(
                (row["A_only_fragments"], row["B_only_fragments"]),
                ("0", "4") if row["condition"] == "drug" else ("2", "2"),
            )
        self.assertAlmostEqual(
            float(read(out / "differential_events.tsv")[0]["delta_B_fraction"]), 0.5
        )
        self.assertEqual(read(out / "excluded_events.tsv")[0]["reason"], "not_two_branches")
        counts_out = self.invoke(
            "counts_run", "--counts", out / "branch_counts.tsv", "--min-informative", 1
        )
        self.assertEqual(
            (out / "differential_events.tsv").read_bytes(),
            (counts_out / "differential_events.tsv").read_bytes(),
        )


if __name__ == "__main__":
    unittest.main()
