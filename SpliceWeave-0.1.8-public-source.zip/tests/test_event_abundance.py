import pytest
from spliceweave.event_abundance import project, read_abundance, partitions


def group():
    return {'e': dict(event={'Unit':'ES'}, A=['a1','a2'], B=['b'], other=['c'])}


def test_conditional_denominator_and_other_path_mass():
    r=project(group(), {'s':{'a1':1.,'a2':2.,'b':3.,'c':6.}})[0]
    assert r['molecular_B_fraction']==.5
    assert r['AB_fraction_of_local_abundance']==.5


def test_missing_model_is_not_zero():
    r=project(group(), {'s':{'a1':1.,'b':3.,'c':6.}})[0]
    assert r['status']=='missing_denominator'
    assert r['molecular_B_fraction'] is None
    assert r['missing_transcripts']=='a2'


def test_zero_abundance_and_unmeasured_other_path():
    r=project(group(), {'s':{'a1':0.,'a2':0.,'b':0.}})[0]
    assert r['status']=='zero_denominator'
    assert r['AB_fraction_of_local_abundance'] is None


def test_invariant_to_scale_and_within_branch_reallocation():
    values=[{'a1':1.,'a2':2.,'b':3.}, {'a1':30.,'a2':0.,'b':30.}]
    assert [project(group(),{'s':v})[0]['molecular_B_fraction'] for v in values]==[.5,.5]


@pytest.mark.parametrize('body',['s\ta\t-1\n','s\ta\tnan\n','s\ta\tinf\n','s\ta\t1\ns\ta\t2\n'])
def test_invalid_abundance(tmp_path,body):
    p=tmp_path/'x.tsv';p.write_text('sample\ttranscript_id\tTPM\n'+body)
    with pytest.raises(ValueError):read_abundance(p)


def test_geometry_defines_membership_not_recipe(tmp_path):
    gtf=tmp_path/'models.gtf'
    lines=[]
    for tid,exons in {'a':[(1,100),(301,400)],'b':[(1,100),(201,220),(301,400)],'c':[(1,100),(251,270),(301,400)]}.items():
        for x,y in exons:lines.append(f'chr1\tx\texon\t{x}\t{y}\t.\t+\t.\tgene_id "g"; transcript_id "{tid}";')
    gtf.write_text('\n'.join(lines)+'\n')
    events=tmp_path/'events.tsv'
    events.write_text('event_id\tchrom\tstrand\tstart\tend\tUnit\tbranch_A_introns_1based\tbranch_B_introns_1based\ne\tchr1\t+\t100\t301\tSE\t101-300\t101-200;221-300\n')
    groups,excluded=partitions(events,gtf)
    assert not excluded
    assert (groups['e']['A'],groups['e']['B'],groups['e']['other'])==(['a'],['b'],['c'])
