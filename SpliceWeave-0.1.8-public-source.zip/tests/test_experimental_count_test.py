import numpy as np
import pytest
from spliceweave.experimental_count_test import bootstrap_test, score


def test_identical_groups_are_not_significant():
    r=bootstrap_test([20,20,20,20,20,20],[100]*6,3,.02,draws=199)
    assert r['delta_observed']==0 and r['p_value']==1


def test_group_swap_preserves_statistic_and_reverses_effect():
    y=np.array([10,15,25,80,75,90]);n=np.array([100,120,150,100,120,150])
    a=score(y,n,3,.03);b=score(np.r_[y[3:],y[:3]],np.r_[n[3:],n[:3]],3,.03)
    assert np.allclose(a[0],b[0]) and np.allclose(a[1],-b[1])


def test_deeper_reads_do_not_create_biological_replicates():
    y=np.array([20,30,40,40,50,60]);n=np.full(6,100)
    a=score(y,n,3,.1)[0];b=score(y*1000,n*1000,3,.1)[0]
    assert b/a < 2  # Dispersion prevents a 1000-fold information increase.


def test_bootstrap_reproducible_and_never_zero():
    kw=dict(included=[5,6,4,95,96,94],total=[100]*6,n_ref=3,prior_rho=.02,draws=199,seed=3)
    a=bootstrap_test(**kw);assert a==bootstrap_test(**kw)
    assert 1/200<=a['p_value']<=1


def test_null_floor_changes_reference_not_observed_effect():
    kw=dict(included=[20,20,20,80,80,80],total=[100]*6,n_ref=3,prior_rho=.1,draws=199,seed=3)
    a=bootstrap_test(**kw);b=bootstrap_test(**kw,null_rho_floor=.1)
    assert a['statistic']==b['statistic'] and a['delta_observed']==b['delta_observed']
    assert b['null_rho']==.1 and b['null_rho']>=a['null_rho']


@pytest.mark.parametrize('y,n,k', [([1]*4,[0]*4,2),([1.5]*4,[10]*4,2),([11]*4,[10]*4,2),([1]*3,[10]*3,1)])
def test_invalid_or_unreplicated_inputs_rejected(y,n,k):
    with pytest.raises(ValueError):bootstrap_test(y,n,k,.02,draws=199)
