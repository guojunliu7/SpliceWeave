import numpy as np
import pandas as pd
import pytest

from spliceweave.experimental_coverage_rescue import abundance_matched_scores, choose_evidence


def _usage():
    # Target and a correlated event in the same gene change greatly; only
    # independent-gene within-group variation may define the target background.
    data=[]
    for eid,values in [('target',[0.1,0.1,0.9,0.9]),
                       ('same_gene',[0.0,1.0,0.0,1.0]),
                       ('other_gene',[0.2,0.21,0.2,0.21])]:
        for i,value in enumerate(values):
            data.append(dict(event_id=eid,sample=f's{i}',group='A' if i<2 else 'B',
                             molecular_B_fraction=value,AB_abundance=100))
    return pd.DataFrame(data)


def test_excludes_same_gene_background_and_preserves_sample_order():
    x=_usage();genes={'target':'G1','same_gene':'G1','other_gene':'G2'}
    a=abundance_matched_scores(x,genes,area=100).set_index('event_id').loc['target']
    b=abundance_matched_scores(x.sample(frac=1,random_state=10),genes,area=100).set_index('event_id').loc['target']
    assert a.reference_pairs==2
    assert a.delta==pytest.approx(.8)
    assert a.score==pytest.approx(1/3)
    assert b.score==a.score and b.delta==a.delta


def test_rescue_never_confirms_unobservable_ir_and_count_takes_priority():
    assert choose_evidence(.01,.4,True,.02,.5,ir_unobservable=True)['source']=='count'
    blocked=choose_evidence(np.nan,np.nan,False,.001,.9,ir_unobservable=True)
    assert blocked['source']=='unresolved_IR' and np.isnan(blocked['score'])
    assert choose_evidence(np.nan,np.nan,False,.02,.5)['source']=='molecular'


def test_requires_independent_samples_and_valid_fractions():
    x=_usage();genes={'target':'G1','same_gene':'G1','other_gene':'G2'}
    with pytest.raises(ValueError):
        abundance_matched_scores(pd.concat([x,x.iloc[[0]]]),genes)
    x.loc[0,'molecular_B_fraction']=1.1
    with pytest.raises(ValueError):
        abundance_matched_scores(x,genes)
