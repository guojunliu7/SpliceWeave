import csv
import itertools
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

from spliceweave.joint_differential import directional_permutations, joint_statistics, adjust, run_joint
from spliceweave.joint_event_bam import long_strand


def test_exact_against_enumeration():
    x=np.array([[.1,.8],[.2,.4],[.3,.1],[.8,.4],[.7,.1]])
    obs,p,info=directional_permutations(x,2)
    d=np.array([x[list(g)].mean(0)-x[[i for i in range(5) if i not in g]].mean(0)
                for g in itertools.combinations(range(5),3)])
    np.testing.assert_allclose(p[0],(abs(d)>=abs(obs)-1e-12).mean(0))
    np.testing.assert_allclose(p[1],(d>=obs-1e-12).mean(0))
    np.testing.assert_allclose(p[2],(d<=obs+1e-12).mean(0))
    assert info['possible_assignments']==10


def test_paired_matches_sign_flip_oracle():
    x=np.array([[.1],[.5],[.8],[.2],[.8],[.9]])
    obs,p,_=directional_permutations(x,3,paired=True)
    dif=x[3:,0]-x[:3,0]
    null=np.array([np.mean(dif*np.array(s)) for s in itertools.product((-1,1),repeat=3)])
    assert p[0,0]==pytest.approx(np.mean(abs(null)>=abs(obs[0])-1e-12))


def test_shared_and_opposed_and_constant_offset():
    x=np.array([.1,.15,.11,.13,.8,.82,.85,.83])[:,None]
    r,_=joint_statistics(x,x+.05,4)
    assert r['joint_p'][0]==pytest.approx(2/70)
    assert r['interaction_p'][0]==1
    assert r['concordance_p'][0]==pytest.approx(2/70)
    r,_=joint_statistics(x,1-x,4)
    assert r['joint_p'][0]==1
    assert r['concordance_p'][0]==1
    assert r['interaction_p'][0]==pytest.approx(2/70)


def test_one_platform_only_is_not_replicated():
    x=np.r_[np.repeat(.2,4),np.repeat(.8,4)][:,None]
    r,_=joint_statistics(x,np.full_like(x,.5),4)
    assert r['joint_p'][0]<.05
    assert r['concordance_p'][0]==1


def test_mc_repeatable_nonzero_and_invalid():
    x=np.arange(24).reshape(12,2)
    a=directional_permutations(x,6,exact_limit=1,draws=99,seed=8)
    b=directional_permutations(x,6,exact_limit=1,draws=99,seed=8)
    np.testing.assert_array_equal(a[1],b[1]); assert a[1].min()>=.01
    with pytest.raises(ValueError): directional_permutations(x,5,paired=True)
    with pytest.raises(ValueError): directional_permutations(np.array([[np.nan],[0]]),1)


def test_adjustment_known_values():
    np.testing.assert_allclose(adjust([.01,.04,.03], 'BH'),[.03,.04,.04])
    np.testing.assert_allclose(adjust([.01,.04,.03]),np.array([.03,.04,.04])*(1+1/2+1/3))
    assert np.isnan(adjust([np.nan])[0])


def write(path,rows):
    with path.open('w') as f:
        w=csv.DictWriter(f,list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)


def fixture(tmp_path,scale=1):
    samples=[dict(sample_id=f's{i}',condition='A' if i<4 else 'B') for i in range(8)]
    catalog=[dict(event_id=e,Unit='ES',chrom='1',strand='+',start=100,end=300,
                 branch_A_introns_1based='120-280',branch_B_introns_1based='120-150;200-280')
             for e in ('shared','opposed','missing')]
    write(tmp_path/'samples.tsv',samples);write(tmp_path/'catalog.tsv',catalog)
    for platform in ('short','long'):
        rows=[]
        for e in ('shared','opposed','missing'):
            for i,s in enumerate(samples):
                b=(20 if i<4 else 80)
                if e=='opposed' and platform=='long':b=100-b
                a=100-b
                if e=='missing' and platform=='long' and i==0:a,b='NA','NA'
                rows.append(dict(event_id=e,sample_id=s['sample_id'],Unit='ES',
                    A_only_fragments=a*scale if isinstance(a,int) else a,
                    B_only_fragments=b*scale if isinstance(b,int) else b))
        write(tmp_path/f'{platform}.tsv',rows)
    return SimpleNamespace(samples=tmp_path/'samples.tsv',catalog=tmp_path/'catalog.tsv',
        short_counts=tmp_path/'short.tsv',long_counts=tmp_path/'long.tsv',out_dir=tmp_path/'out',
        events=None,gtf=None,reference='A',comparison='B',pair_column=None,min_short=20,min_long=5,
        exact_limit=10000,permutations=999,seed=1,fdr=.1,adjustment='BH')


def test_integration_status_and_no_overwrite(tmp_path):
    args=fixture(tmp_path);info=run_joint(args)
    assert info['events']==3 and info['joint_tested']==2
    with (args.out_dir/'joint_differential_events.tsv').open() as f:
        r={x['event_id']:x for x in csv.DictReader(f,delimiter='\t')}
    assert r['shared']['status']=='cross_platform_supported'
    assert r['opposed']['status']=='platform_conflict'
    assert r['missing']['status']=='single_platform_only'
    assert r['missing']['joint_p']=='NA'
    with pytest.raises(FileExistsError):run_joint(args)


def test_depth_does_not_create_biological_replicates(tmp_path):
    a=fixture(tmp_path);run_joint(a)
    first=(a.out_dir/'joint_differential_events.tsv').read_text()
    a=fixture(tmp_path,100);a.out_dir=tmp_path/'out2';run_joint(a)
    assert first==(a.out_dir/'joint_differential_events.tsv').read_text()


def test_swapped_branch_rejected_atomically(tmp_path):
    a=fixture(tmp_path)
    with a.long_counts.open() as f:rows=list(csv.DictReader(f,delimiter='\t'))
    for r in rows:r['branch_A_introns_1based']='120-150;200-280'
    write(a.long_counts,rows)
    with pytest.raises(ValueError,match='inconsistent branch'):run_joint(a)
    assert not a.out_dir.exists()


def test_ir_not_joint_when_short_unobservable(tmp_path):
    a=fixture(tmp_path)
    for path in (a.catalog,a.short_counts,a.long_counts):
        with path.open() as f:rows=list(csv.DictReader(f,delimiter='\t'))
        rows=[r for r in rows if r['event_id']=='shared']
        for r in rows:
            r['Unit']='IR'
            if path==a.catalog:
                r['branch_A_introns_1based']='120-280';r['branch_B_introns_1based']=''
            else:
                r['ir_count_rule']='single_mate_full_span'
                r['max_mate_length']='100' if path==a.short_counts else '1000'
                if path==a.short_counts:r['A_only_fragments']='100';r['B_only_fragments']='0'
        write(path,rows)
    run_joint(a)
    with (a.out_dir/'joint_differential_events.tsv').open() as f:r=next(csv.DictReader(f,delimiter='\t'))
    assert r['short_status']=='unobservable_retained_branch'
    assert r['status']=='single_platform_only'


@pytest.mark.parametrize('reverse,ts,expected',[(False,'+','+'),(True,'+','-'),(False,'-','-'),(True,'-','+')])
def test_minimap_transcript_strand(reverse,ts,expected):
    class Read:
        is_reverse=reverse
        def has_tag(self,k):return k=='ts'
        def get_tag(self,k):return ts
    assert long_strand(Read(),'tag')==expected


def test_long_bam_counting_and_molecule_uniqueness(tmp_path):
    pysam=pytest.importorskip('pysam')
    from spliceweave.joint_event_bam import generate_long_counts
    bam=tmp_path/'long.bam'
    with pysam.AlignmentFile(str(bam),'wb',header={'HD':{'VN':'1.6','SO':'coordinate'},'SQ':[{'SN':'1','LN':1000}]}) as f:
        for name,cigar in [('spliced',[(0,20),(3,161),(0,20)]),('retained',[(0,201)])]:
            r=pysam.AlignedSegment();r.query_name=name;r.flag=0;r.reference_id=0;r.reference_start=99
            r.mapping_quality=60;r.cigartuples=cigar;r.query_sequence='A'*sum(n for op,n in cigar if op==0);f.write(r)
    pysam.index(str(bam))
    row=dict(event_id='ir',Unit='IR',chrom='1',strand='+',start=100,end=300,
             branch_A_introns_1based='120-280',branch_B_introns_1based='')
    paths=(((120,280),),(),{((120,280),),()})
    args=SimpleNamespace(samples=tmp_path/'samples.tsv')
    design={'s':dict(condition='A',lr_bam=str(bam),sr_bam='other.bam',lr_strand_rule='forward')}
    generate_long_counts(tmp_path/'counts.tsv',args,design,['s'],{'ir':(row,paths)})
    with (tmp_path/'counts.tsv').open() as f:r=next(csv.DictReader(f,delimiter='\t'))
    assert r['A_only_fragments']=='1' and r['B_only_fragments']=='1'
