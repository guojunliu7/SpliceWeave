"""Synthetic edge cases for the BED12 coordinate and uncertainty contract."""
import gzip
import json
import contextlib
import io
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from spliceweave.correct import Catalog, CorrectConfig, Read, correct_read, load_catalog, run_correct
from spliceweave.cli import main


def read(junctions, start=0, end=600, strand='+', name='r'):
    starts = [start] + [b for a, b in junctions]
    ends = [a for a, b in junctions] + [end]
    return Read.parse('\t'.join(map(str, ['chr1', start, end, name, 60, strand, start, end, 0,
        len(starts), ','.join(str(b-a) for a, b in zip(starts, ends)),
        ','.join(str(a-start) for a in starts)])))


def catalog(edges, strand='+'):
    c = Catalog()
    for a, b in edges:
        c.add('chr1', strand, a, b, 'test')
    c.finish()
    return c


class NativeCorrectTests(unittest.TestCase):
    def test_repeated_original_branch_does_not_enable_retired_guard(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            js=[(50,80),(102,202),(400,500)]
            (p/'reads.bed').write_text(''.join(read(js,name=str(i)).render(js) for i in range(3)))
            (p/'junctions.bed').write_text(''.join(f'chr1\t{a}\t{b}\t.\t1\t+\n' for a,b in [(50,80),(100,200),(400,500)]))
            result=run_correct(p/'reads.bed',p/'result',junction_bed=p/'junctions.bed')
            self.assertEqual(result['counts']['applied'],3)
            self.assertEqual(result['counts'].get('review',0),0)
            self.assertFalse(result['original_branch_guard'])
            self.assertEqual(result['algorithm_id'],'sw-correct-trusted-pair-local-v1')
            for ln in (p/'result/corrected.bed').read_text().splitlines():
                self.assertEqual(Read.parse(ln).junctions,[(50,80),(100,200),(400,500)])

    def test_retired_guard_argument_is_rejected_not_silently_ignored(self):
        with contextlib.redirect_stderr(io.StringIO()) as stderr:
            with self.assertRaises(SystemExit) as e:
                main(['correct','-q','unused.bed','--gtf','unused.gtf','--out-dir','unused','--original-support','2'])
        self.assertEqual(e.exception.code,2)
        self.assertIn('unrecognized arguments: --original-support 2',stderr.getvalue())

    def call(self, js, edges, **kw):
        return correct_read(read(js, **kw), catalog(edges), CorrectConfig())

    def test_trusted_pair_never_moves(self):
        final, ds = self.call([(100, 200)], [(100, 200), (101, 201)])
        self.assertEqual(final, [(100, 200)])
        self.assertEqual(ds[0]['action'], 'KEEP')

    def test_partial_read_correction_survives_unresolved_junction(self):
        final, ds = self.call([(102, 202), (400, 500)], [(100, 200)])
        self.assertEqual(final, [(100, 200), (400, 500)])
        self.assertEqual([d['action'] for d in ds], ['APPLY', 'REVIEW'])

    def test_no_chimeric_pair_from_independent_nearest_sites(self):
        final, ds = self.call([(102, 298)], [(100, 200), (200, 300)])
        self.assertEqual(final, [(102, 298)])
        self.assertEqual(ds[0]['reason'], 'no_compatible_trusted_pair')

    def test_equal_distance_tie_is_preserved(self):
        final, ds = self.call([(100, 200)], [(99, 199), (101, 201)])
        self.assertEqual(final, [(100, 200)])
        self.assertEqual(ds[0]['reason'], 'equal_distance_ambiguity')

    def test_never_move_trusted_original_boundary(self):
        final, ds = self.call([(100, 200)], [(100, 209), (101, 200)])
        self.assertEqual(final, [(100, 200)])
        self.assertEqual(ds[0]['reason'], 'trusted_boundaries_unpaired')
        final, ds = self.call([(100, 200)], [(100, 208), (101, 199)])
        self.assertEqual(final, [(100, 208)])

    def test_strand_and_boundary_type_separated(self):
        r = read([(102, 202)], strand='-')
        final, ds = correct_read(r, catalog([(100, 200)]), CorrectConfig())
        self.assertEqual(ds[0]['action'], 'REVIEW')
        final, ds = correct_read(r, catalog([(100, 200)], '-'), CorrectConfig())
        self.assertEqual(final, [(100, 200)])
        self.assertEqual(r.fields[5], '-')

    def test_unknown_strand_and_terminal_span(self):
        final, ds = self.call([(102, 202)], [(100, 200)], strand='.')
        self.assertEqual(ds[0]['reason'], 'unknown_transcript_strand')
        final, ds = self.call([(102, 202)], [(100, 200)], start=95)
        self.assertEqual(ds[0]['reason'], 'insufficient_terminal_anchor')

    def test_geometry_conflict_reverts_both_proposals(self):
        r = read([(100, 200), (205, 300)])
        final, ds = correct_read(r, catalog([(101, 209), (201, 301)]), CorrectConfig())
        self.assertEqual(final, r.junctions)
        self.assertTrue(all(d['reason'] == 'chain_geometry_conflict' for d in ds))

    def test_ten_base_window_inclusive_and_zero_disables_moves(self):
        r = read([(100, 200)])
        c = catalog([(110, 210)])
        self.assertEqual(correct_read(r, c, CorrectConfig())[0], [(110, 210)])
        self.assertEqual(correct_read(r, c, CorrectConfig(window=9))[0], r.junctions)
        self.assertEqual(correct_read(r, c, CorrectConfig(window=0))[0], r.junctions)

    def test_gtf_and_star_coordinate_conversion_and_support(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)
            (p/'a.gtf').write_text('chr1\tx\texon\t1\t100\t.\t-\t.\ttranscript_id "tx";\n'
                                   'chr1\tx\texon\t201\t600\t.\t-\t.\ttranscript_id "tx";\n')
            (p/'sj').write_text('chr1\t301\t400\t1\t1\t0\t3\t4\t20\n'
                                'chr1\t401\t500\t0\t1\t0\t8\t0\t20\n')
            c = load_catalog(gtf=p/'a.gtf', junction_tab=p/'sj', min_support=3)
            self.assertEqual(c.edges['chr1', '-'], {(100, 200)})
            self.assertEqual(c.edges['chr1', '+'], {(300, 400)})

    def test_cli_atomic_outputs_and_duplicate_ids_fail(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)
            (p/'q.bed').write_text(read([(102, 202), (400, 500)]).render([(102, 202), (400, 500)]))
            (p/'j.bed').write_text('chr1\t100\t200\t.\t2\t+\n')
            main(['correct', '-q', str(p/'q.bed'), '--junction-bed', str(p/'j.bed'), '--out-dir', str(p/'out')])
            result = json.loads((p/'out/summary.json').read_text())
            self.assertEqual(result['counts']['applied'], 1)
            self.assertFalse((p/'out/confident.bed').read_text())
            self.assertEqual(Read.parse((p/'out/corrected.bed').read_text()).junctions, [(100, 200), (400, 500)])
            with self.assertRaises(FileExistsError):
                run_correct(p/'q.bed', p/'out', junction_bed=p/'j.bed')
            with (p/'q.bed').open('a') as f:
                f.write(read([]).render([]))
            with self.assertRaisesRegex(ValueError, 'Duplicate read'):
                run_correct(p/'q.bed', p/'failed', junction_bed=p/'j.bed')
            self.assertFalse((p/'failed').exists())

    def test_bad_geometry_and_bed12_junction_guidance_rejected(self):
        with self.assertRaises(ValueError):
            Read.parse('chr1\t0\t200\tr\t60\t+\t0\t200\t0\t2\t120,100\t0,100')
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'j.bed'
            p.write_text(read([(100, 200)]).render([(100, 200)]))
            with self.assertRaisesRegex(ValueError, 'BED6'):
                load_catalog(junction_bed=p)


if __name__ == '__main__':
    unittest.main()
