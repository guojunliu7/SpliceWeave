import unittest
import tempfile
from pathlib import Path
from types import SimpleNamespace
import gzip,json
import numpy as np
from scipy.sparse import csr_matrix
from scipy.optimize import check_grad
from spliceweave.quantification.native import valid_starts, objective, fit, prepare
from spliceweave.quantification.runner import read_catalog, run_quantify, validate_geometry

class NativeQuantification(unittest.TestCase):
    def example(self):
        return dict(models=[dict(transcript='t1',gene='g1',contig='chr1',strand='+',start=0,end=200,chain=[],length=200),dict(transcript='t2',gene='g1',contig='chr1',strand='+',start=300,end=500,chain=[],length=200)], observations=[dict(kind=[1,50],members=[0],fragments=[50],count=80),dict(kind=[1,50],members=[1],fragments=[50],count=20)],calibration={},LR=[dict(members=[0],count=8),dict(members=[1],count=2)])
    def test_anchor_counts_against_enumeration(self):
        for L,js,reads in [(100,[20,45,80],[12,15]),(50,[3,20,45],[10])]:
            fs=np.arange(1,110);truth=[]
            for F in fs:
                count=0
                for start in range(max(0,L-F+1)):
                    if F<max(reads):continue
                    offs=[0] if len(reads)==1 else [0,F-reads[1]]
                    count+=all(not (start+off<j<start+off+r) or min(j-start-off,start+off+r-j)>=8 for off,r in zip(offs,reads) for j in js)
                truth.append(count)
            np.testing.assert_array_equal(valid_starts(L,js,fs,reads),truth)
    def test_joint_gradient(self):
        p=prepare(self.example());args=[p[k] for k in ['A','E','ns','groups','L','nl']]+[2.]
        err=check_grad(lambda z:objective(z,*args)[0],lambda z:objective(z,*args)[1],np.array([.3,-.5]));self.assertLess(err,1e-4)
    def test_known_identifiable_mixture(self):
        p=prepare(self.example());v,d=fit(p,shrink=False);self.assertTrue(d['success']);self.assertAlmostEqual(v[0]/v.sum(),.8,places=5)
    def test_replay_outputs_and_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);inp=td/'geometry.json.gz'
            with gzip.open(inp,'wt') as f:json.dump(self.example(),f)
            args=SimpleNamespace(geometry=inp,gtf=None,short_bam=None,long_bam=None,out_dir=td/'out',sample='test')
            r=run_quantify(args);self.assertEqual(r['model'],'geometry_MAP_joint');self.assertTrue((args.out_dir/'abundance.tsv').exists())
            self.assertRaises(FileExistsError,run_quantify,args)
    def test_bam_extraction_and_geometry_replay(self):
        import pysam
        from spliceweave.quantification.runner import extract
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);gtf=td/'catalog.gtf'
            gtf.write_text('chr1\tx\texon\t1\t200\t.\t+\t.\tgene_id "g1"; transcript_id "t1";\nchr1\tx\texon\t301\t500\t.\t+\t.\tgene_id "g1"; transcript_id "t2";\n')
            header={'HD':{'VN':'1.6','SO':'coordinate'},'SQ':[{'SN':'chr1','LN':1000}]}
            for name,counts,length in [('sr',[80,20],50),('lr',[8,2],150)]:
                with pysam.AlignmentFile(td/(name+'.bam'),'wb',header=header) as f:
                    for offset,n in zip([10,310],counts):
                        for i in range(n):
                            r=pysam.AlignedSegment();r.query_name=f'{name}_{offset}_{i}';r.query_sequence='A'*length;r.flag=0;r.reference_id=0;r.reference_start=offset;r.mapping_quality=60;r.cigartuples=[(0,length)];r.set_tag('XS','+');f.write(r)
            data=extract(gtf,td/'sr.bam',td/'lr.bam');self.assertEqual(data['audit']['assigned_SR'],100);self.assertEqual(data['audit']['assigned_LR'],10)
            args=SimpleNamespace(gtf=gtf,short_bam=td/'sr.bam',long_bam=td/'lr.bam',geometry=None,out_dir=td/'bam_run',sample='test')
            run_quantify(args)
            first=args.out_dir/'abundance.tsv';args.geometry=args.out_dir/'geometry.json.gz';args.gtf=args.short_bam=args.long_bam=None;args.out_dir=td/'replay'
            run_quantify(args);self.assertEqual(first.read_text(),(args.out_dir/'abundance.tsv').read_text())
    def test_validation_rejects_bad_membership(self):
        d=self.example();d['LR'][0]['members']=[2];self.assertRaises(ValueError,validate_geometry,d)
    def test_gtf_conflicts_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a.gtf';p.write_text('chr1\tx\texon\t1\t100\t.\t+\t.\tgene_id "g"; transcript_id "t";\nchr1\tx\texon\t90\t200\t.\t+\t.\tgene_id "g"; transcript_id "t";\n')
            self.assertRaises(ValueError,read_catalog,p)
if __name__=='__main__':unittest.main()
